import tkinter as tk
from pathlib import Path
from tkinter import ttk

import cv2
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageTk
from rich import print as pprint
from scipy.ndimage import label
from tktooltip import ToolTip

from curveclaw.utils import delete_files

from .base import BaseFrame
from .settings import MSG_COLOR, RESET, VAR_COLOR, get_settings
from .utils import build_frame

"""
COPYRIGHT
2-clause BSD License
Copyright 2024 STFC
Author: Dr. Felix Rummel
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


#########################################################
##DEFINE APP
#########################################################
class AutoCleaner(BaseFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.integer_value = None
        self.data_dir = Path(get_settings().data_dir)

        if hasattr(self.controller, "preview_image_path"):
            self.setup_ui()

    def setup_ui(self):
        # Initialise window depending on screen
        if self.controller.orientation == "landscape":  # Landscape orientation
            # Set the preview image frame
            self.frame_height = int(self.controller.height / 2) - 50
            self.frame_width = int(self.controller.width * 2 / 3) - 50
            self.control_frame_width = int(self.controller.width * 1 / 3) - 50

            self.in_img_frame = build_frame(
                parent=self, height=self.frame_height, width=self.frame_width, text="Input Image", coords=(0, 0)
            )

            # Create a grid layout spanning two column and one row
            self.control_frame = ttk.LabelFrame(
                self, height=self.controller.height, width=self.control_frame_width, text="Cleaning Options"
            )
            self.control_frame.grid(padx=(20, 10), pady=(20, 10), row=0, column=1, rowspan=2, sticky="nsew")

            # Set the output image frame
            self.out_img_frame = build_frame(
                parent=self, height=self.frame_height, width=self.frame_width, text="Output Image", coords=(1, 0)
            )
        else:  # Portrait orientation
            # Set the preview image frame
            self.frame_height = int(self.controller.height / 2) - 50
            self.frame_width = int(self.controller.width * 2 / 3) - 50
            self.control_frame_width = int(self.controller.width * 1 / 3) - 50

            self.in_img_frame = build_frame(
                parent=self, height=self.frame_height, width=self.frame_width, text="Input Image", coords=(0, 0)
            )

            # Create a grid layout spanning two column and one row
            self.control_frame = ttk.LabelFrame(
                self, height=self.controller.height, width=self.control_frame_width, text="Cleaning Options"
            )
            self.control_frame.grid(padx=(20, 10), pady=(20, 10), row=0, column=1, rowspan=2, sticky="nsew")

            # Set the output image frame
            self.out_img_frame = build_frame(
                parent=self, height=self.frame_height, width=self.frame_width, text="Output Image", coords=(1, 0)
            )

        self.parent_frames = [self.in_img_frame, self.control_frame, self.out_img_frame]

    def on_show_page(self):
        self.create_widgets()
        # Load the input image
        self.resize_display(self.controller.preview_image_path, self.in_img_frame)
        self.input_image_path = self.controller.preview_image_path

        # Load the image as a grayscale array
        self.input_array = np.asarray(Image.open(self.input_image_path).convert("L"))

        # Create the inverse binary array based on the threshold
        threshold = 127
        self.inv_array = np.where(self.input_array > threshold, 0, 1)

        # Label the inverse array
        self.labeled_array, self.num_labels = label(self.inv_array)

        # Count the occurence of each labeled value
        self.area_counts = np.bincount(self.labeled_array.ravel())[1:]

    #########################################################
    ##DEFINE BUTTONS
    #########################################################
    def create_widgets(self):
        # feature selection
        coarse_clean_frame = build_frame(
            parent=self.control_frame,
            height=150,
            width=self.control_frame_width,
            text="Feature Selection",
            coords=(0, 0),
        )

        self.clean = ttk.Button(
            coarse_clean_frame,
            text="Isolate Features",
            command=self.clean_fun,
        )
        ToolTip(self.clean, msg="Isolates the n largest features from the input image", delay=0.5)
        self.clean.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")
        self.input_label = ttk.Label(
            coarse_clean_frame,
            text="Features to keep:",
        )
        self.input_label.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")
        self.integer_entry = ttk.Entry(coarse_clean_frame, width=5)
        self.integer_entry.grid(row=1, column=2, padx=5, pady=5, sticky="nsew")
        self.integer_entry.insert(0, "2")
        self.show_histogram = ttk.Button(
            coarse_clean_frame,
            text="Feature Size Histogram",
            command=self.show_histogram_fun,
        )
        ToolTip(self.show_histogram, msg="Show a Histogram of the features in the input image", delay=0.5)
        self.show_histogram.grid(row=2, column=0, padx=5, pady=5, sticky="nsew", rowspan=3)

        # feature manipulation
        line_ctrl_frame = build_frame(
            parent=self.control_frame,
            height=230,
            width=self.control_frame_width,
            text="Feature Manipulation",
            coords=(2, 0),
        )
        self.thin_in = ttk.Button(
            line_ctrl_frame,
            text="Thin Input Features",
            command=self.thin_in_fun,
        )
        self.thin_in.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")
        ToolTip(
            self.thin_in,
            msg="Erodes all features in the input image. Can be used repeatedly to destroy them also",
            delay=0.5,
        )

        self.thin_out = ttk.Button(
            line_ctrl_frame,
            text="Thin Output Features",
            command=self.thin_out_fun,
            state=tk.DISABLED,
        )
        self.thin_out.grid(row=0, column=1, padx=5, pady=5, sticky="nsew")
        ToolTip(
            self.thin_out,
            msg="Erodes all features in the output image. Can be used repeatedly to destroy them also",
            delay=0.5,
        )

        self.thick_out = ttk.Button(
            line_ctrl_frame,
            text="Thicken Output Features",
            command=self.thick_out_fun,
            state=tk.DISABLED,
        )
        self.thick_out.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")
        ToolTip(self.thick_out, msg="Thickens all features in the output image. Can be used repeatedly", delay=0.5)

        self.thick_in = ttk.Button(
            line_ctrl_frame,
            text="Thicken Input Features",
            command=self.thick_in_fun,
        )
        self.thick_in.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")
        ToolTip(
            self.thick_in,
            msg="Thickens all features in the input image. Can be used repeatedly",
            delay=0.5,
        )

        # Reload Input
        self.reload_input = ttk.Button(
            line_ctrl_frame,
            text="Reload Input Image",
            command=self.reload_input_fun,
        )
        self.reload_input.grid(row=2, column=0, columnspan=2, padx=5, pady=20, sticky="nsew")
        ToolTip(self.reload_input, msg="Resets the Input Image", delay=0.5)

        # Fill tool
        area_fill_frame = build_frame(
            parent=self.control_frame, height=100, width=self.control_frame_width, text="Area Filling", coords=(3, 0)
        )
        self.fill_small_areas = ttk.Button(
            area_fill_frame,
            text="Fill Areas",
            command=self.fill_small_areas_fun,
            state=tk.DISABLED,
        )
        self.fill_small_areas.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")
        ToolTip(
            self.fill_small_areas,
            msg="Fills all areas in the output image which are of a size below the specified area size. Area size is "
            "the number of pixels in the area relative to the total number of pixels in the image.",
            delay=0.5,
        )
        self.area_cutoff_lbl = ttk.Label(area_fill_frame, text="Area Size% cutoff")
        self.area_cutoff_lbl.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")
        self.area_cutoff_entry = tk.Entry(area_fill_frame, width=5)
        self.area_cutoff_entry.insert(0, "0.01")
        self.area_cutoff_entry.grid(row=1, column=2, padx=5, pady=5, sticky="nsew")

        #Fix connectivity
        con_fix_frame = build_frame(
            parent=self.control_frame,
            height=100,
            width=self.control_frame_width,
            text="Connectivity Fixing",
            coords=(4, 0),
        )
        self.con_fix_in = ttk.Button(
            con_fix_frame,
            text="Fix Input Connectivity",
            command=self.con_fix_in_fun,
        )
        self.con_fix_in.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")
        ToolTip(
            self.con_fix_in,
            msg="Attempts to correct connectivity issues between diagonally placed pixels with "
            "white horizontal adjacency. Operates on input image.",
            delay=0.5,
        )
        self.con_fix_out = ttk.Button(
            con_fix_frame,
            text="Fix Output Connectivity",
            command=self.con_fix_out_fun,
            state=tk.DISABLED,
        )
        self.con_fix_out.grid(row=0, column=1, padx=5, pady=5, sticky="nsew")
        ToolTip(
            self.con_fix_out,
            msg="Attempts to correct connectivity issues between diagonally placed pixels with "
            "white horizontal adjacency. Operates on output image.",
            delay=0.5,
        )

        # Save Buttons
        self.save_output = ttk.Button(
            self.control_frame,
            text="Save & Exit",
            command=self.save_output_fun,
            state=tk.DISABLED,
        )
        self.save_output.grid(row=5, column=0, padx=10, pady=10, sticky="nsew")
        ToolTip(self.save_output, msg="Save the output image and exit", delay=0.5)
        self.exit_app = ttk.Button(
            self.control_frame,
            text="Discard & Exit",
            command=self.exit_application,
        )
        self.exit_app.grid(row=6, column=0, padx=10, pady=10, sticky="nsew")
        ToolTip(self.exit_app, msg="Discard the output image and exit", delay=0.5)

    #########################################################
    ##DEFINE FUNCTIONS
    #########################################################
    def con_fix_in_fun(self):
        self.con_fix_fun("in")
    def con_fix_out_fun(self):
        self.con_fix_fun("out")

    def con_fix_fun(self,in_img):
        def is_valid_move(i,j,i1,j1,max_i,max_j):
            new_i = i + i1
            new_j = j + j1
            if new_i in range(0,max_i) and new_j in range(0, max_j):
                return True
            else:
                return False

        def fix_as_needed(i,j,array,dir_dict):
            out_array = array.copy()
            i1 = i + dir_dict["check"][0][0]
            i2 = i + dir_dict["check"][1][0]
            j1 = j + dir_dict["check"][0][1]
            j2 = j + dir_dict["check"][1][1]
            #if both horizontals are white
            if array[i1,j1] != 0 and array[i2,j2] != 0:
                # if the diagonal is black
                i3 = i + dir_dict["ref"][0]
                j3 = j + dir_dict["ref"][1]
                if array[i3,j3] == 0:
                    # set the specfied pixel to black
                    i4 = i + dir_dict["change"][0]
                    j4 = j + dir_dict["change"][1]
                    out_array[i4,j4] = 0
            return out_array

        # define directions to check and fix
        checks = {
            "ul":{
                "ref":(-1,-1),
                "check":[(-1,0),(0,-1)],
                "change":(0,-1)
                },
            "ur":{
                "ref":(-1,1),
                "check":[(-1,0),(0,1)],
                "change":(-1,0)
                },
            "dr":{
                "ref":(1,1),
                "check":[(1,0),(0,1)],
                "change":(0,1)
                },
            "dl":{
                "ref":(1,-1),
                "check":[(1,0),(0,-1)],
                "change":(1,0)
                }
            }
        # determine which input array to use
        if in_img == "in":
            binary_array = self.input_array
        elif in_img == "out":
            binary_array = np.array(self.binary_image)
        # determine the test pixels
        size = (binary_array.shape[0], binary_array.shape[1])
        for i in range(size[0]):
            for j in range(size[1]):  # For each pixel
                if binary_array[i, j] == 0:  # If the pixel is black
                    for direction in checks.keys():
                        # check if the direction is within the image bounds
                        i1 = checks[direction]["ref"][0]
                        j1 = checks[direction]["ref"][1]
                        if is_valid_move(i,j,i1,j1,size[0],size[1]):
                            binary_array = fix_as_needed(i,
                                                            j,
                                                            binary_array,
                                                            checks[direction]
                                                            )
                        else:
                            continue
        # update the image and relevant array variable
        if in_img == "out":
            self.binary_image = Image.fromarray(binary_array)
            self.resize_display(self.binary_image, self.out_img_frame)
        elif in_img == "in":
            input_image = Image.fromarray(binary_array)
            output_path = self.data_dir.joinpath("preview", "preview_1.png")
            input_image.save(output_path)

            # Display the output image
            self.resize_display(output_path, self.in_img_frame)

            # Redo analysis
            self.input_array = binary_array

            # Create the inverse binary array based on the threshold
            threshold = 127
            self.inv_array = np.where(self.input_array > threshold, 0, 1)

            # Label the inverse array
            self.labeled_array, self.num_labels = label(self.inv_array)

            # Count the occurence of each labeled value
            self.area_counts = np.bincount(self.labeled_array.ravel())[1:]

    def thin_lines_fun(self):
        binary_image_array = np.array(self.binary_image)
        binary_array = (binary_image_array > 0).astype(np.uint8)
        self.binary_image = self.thinning_fun(binary_array)
        # Update the image
        self.resize_display(self.binary_image, self.out_img_frame)

    def thinning_fun(self, inp_arr):
        def neighbours(img, x, y):
            # Returns the 8 neighbor values at position [x, y] for an image as well as the value at [x,y]
            neighbors = []
            for i in range(x - 1, x + 2):
                for j in range(y - 1, y + 2):
                    # Check if indices are within bounds
                    if 0 <= i < img.shape[0] and 0 <= j < img.shape[1]:
                        neighbors.append(img[i][j])
                    else:
                        # Indices are out of bounds, set neighbor value to 0
                        neighbors.append(0)
            return neighbors

        # Function which will thin all black features to a minimum while ensuring the area count remains constant
        # Label the overlayed curves to identify all white areas
        labeled_array, num_labels = label(inp_arr)

        # Flag to determine if the thinning process is done
        finish_flag = False

        # Create a new array to store the thinned image
        out_arr = inp_arr

        while not finish_flag:
            changes = 0
            for i in range(inp_arr.shape[0]):
                for j in range(inp_arr.shape[1]):  # For each pixel
                    if inp_arr[i, j] == 0:  # If the pixel is black
                        nbrs = neighbours(labeled_array, i, j)  # Fetch neighbours of the i, j pixel
                        # If a pixel is sourrounded by exactly 2 areas, it can be removed
                        if len(set(nbrs)) == 2:
                            out_arr[i, j] = 1  # Set the pixel to be white
                            changes += 1
                            # Update the input
                            inp_arr = out_arr
                            # Sets the adjacency matrix of the removed pixel to be that of the adjacent area
                            labeled_array[i, j] = max(set(nbrs))

            if changes == 0:
                finish_flag = True

        # Convert the array to a black/white image
        binary_image = Image.fromarray((inp_arr * 255).astype("uint8"), mode="L")

        return binary_image

    def fill_small_areas_fun(self):
        # Convert PIL Image to NumPy array
        binary_array = (np.array(self.binary_image) > 220).astype(np.uint8)

        # Label the image
        labeled_array, num_labels = label(binary_array)

        # Determine the size (no of Pixels) for each area
        area_counts = np.bincount(labeled_array.ravel())

        # Determine the size of the images
        (cols, rows) = labeled_array.shape
        img_size = cols * rows

        # Create a new array to store the filled image
        filled_array = np.ones_like(labeled_array, dtype=np.uint8)
        filled_array[binary_array == 0] = 0

        # Get the value from the entry field
        Entry_float = float(self.area_cutoff_entry.get())
        cutoff_pixels = Entry_float / 100 * img_size

        # Check each area size
        to_fill = [idx for idx, area in enumerate(area_counts) if idx != 0 and area < cutoff_pixels]
        pprint(f"{MSG_COLOR}Filling area/s:{RESET} {VAR_COLOR}{to_fill}{RESET}")

        # Fill these area
        filled_array = self.fill_area(labeled_array, filled_array, to_fill)

        self.binary_image = Image.fromarray(np.where(filled_array > 0, 255, 0).astype(np.uint8), mode="L")
        # Update the image
        self.resize_display(self.binary_image, self.out_img_frame)

    def fill_area(self, array_in, array_out, idx):
         mask = np.isin(array_in, idx)
         array_out[mask] = 0
         return array_out

    def reload_input_fun(self):
        self.resize_display(self.input_image_path, self.in_img_frame)
        # Load the image as a grayscale array
        self.input_array = np.asarray(Image.open(self.input_image_path).convert("L"))

        # Create the inverse binary array based on the threshold
        threshold = 127
        self.inv_array = np.where(self.input_array > threshold, 0, 1)

        # Label the inverse array
        self.labeled_array, self.num_labels = label(self.inv_array)

        # Count the occurence of each labeled value
        self.area_counts = np.bincount(self.labeled_array.ravel())[1:]

    def clean_fun(self):
        # Get the integer value from the entry field
        integer_value_str = self.integer_entry.get()
        try:
            integer_value = int(integer_value_str)
        except ValueError:
            # Handle the case when the input is not a valid integer
            pprint(f"{MSG_COLOR}⚠️ Please enter a valid integer.{RESET}")
            return

        # Find the indices of the k largest elements in area_counts
        largest_area_indices = np.argpartition(-self.area_counts, integer_value)[:integer_value]

        largest_area_indices = [item + 1 for item in largest_area_indices]

        # Create a new array to store the cleaned image
        cleaned_array = np.ones_like(self.labeled_array)

        # Iterate through the rows and columns of labeled_array
        for i in range(self.labeled_array.shape[0]):
            for j in range(self.labeled_array.shape[1]):
                # Check if the label of the current pixel is one of the largest area indices
                if self.labeled_array[i, j] in largest_area_indices:
                    # Set the corresponding pixel in the cleaned array to 1
                    cleaned_array[i, j] = 0

        # Convert the array to a black/white image
        self.binary_image = Image.fromarray((cleaned_array * 255).astype("uint8"), mode="L")

        # Display the output image
        self.resize_display(self.binary_image, self.out_img_frame)

        # Enable the save button after cleaning
        self.save_output.config(state=tk.NORMAL)
        self.thin_out.config(state=tk.NORMAL)
        self.thick_out.config(state=tk.NORMAL)
        self.fill_small_areas.config(state=tk.NORMAL)
        self.con_fix_out.config(state=tk.NORMAL)

    def show_histogram_fun(self):
        # Define logarithmic bins
        bins = np.logspace(np.log10(1), np.log10(np.max(self.area_counts)), 50)

        # Calculate the histogram of area counts with logarithmic bins
        hist, _ = np.histogram(self.area_counts, bins=bins)

        plt.bar(bins[:-1], hist, width=np.diff(bins), align="edge", edgecolor="black")
        plt.xlabel("Number of Pixels (log scale)")
        plt.ylabel("Number of Areas (log scale)")
        plt.title("Histogram of Number of Pixels per Area (Log Scale for X and Y axes)")
        plt.xscale("log")  # Set x-axis to log scale
        plt.yscale("log")  # Set y-axis to log scale
        plt.show()

    def delete_curve_files(self):
        patterns = [
            "curve_*.png",  # Matches all files starting with 'curve_' and ending with '.png'
            "hold.png",  # Matches exactly 'hold.png'
            "overlayed_curves.png",  # Matches exactly 'overlayed_curves.png'
        ]

        curves_path = self.data_dir.joinpath("curves")
        delete_files(curves_path, patterns)

    def save_output_fun(self):
        self.destroy_widgets()
        output_path = self.data_dir.joinpath("preview", "preview.png")
        out_array = np.array(self.binary_image)
        out_array = np.where(out_array > 180, 255, 0).astype(np.uint8)
        self.binary_image = Image.fromarray(out_array, mode = "L")
        self.binary_image.save(output_path)
        self.delete_curve_files()
        self.controller.show_page(get_settings().controller_page)

    def resize_display(self, image_path: Path | Image.Image, image_widget: ttk.LabelFrame):
        if hasattr(self, "input_image_label"):
            self.input_image_label.destroy()

        if not isinstance(image_path, Image.Image):
            image = Image.open(image_path)
        else:
            image = image_path

        image.thumbnail((self.frame_width - 50, self.frame_height - 50))  # Resize image for display
        photo = ImageTk.PhotoImage(image)

        # Check if image label already exists inside the frame
        if not hasattr(image_widget, "image_label") or not image_widget.image_label.winfo_exists():
            image_widget.image_label = tk.Label(image_widget)
            image_widget.image_label.pack_propagate(False)
            image_widget.image_label.pack(expand=False)

        # Update image
        image_widget.image_label.configure(width=self.frame_width - 50, height=self.frame_height - 50, image=photo)
        image_widget.image_label.image = photo

    def thick_out_fun(self):
        # Convert PIL Image to NumPy array
        binary_array = np.array(self.binary_image)

        # Define the structuring element for dilation
        kernel = np.ones((2, 2), np.uint8)

        # Apply dilation to thicken the black features
        thickened_image = cv2.erode(binary_array, kernel, iterations=1)

        self.binary_image = Image.fromarray(thickened_image)

        # Display the output image
        self.resize_display(self.binary_image, self.out_img_frame)

    def thin_out_fun(self):
        # Convert PIL Image to NumPy array
        binary_array = np.array(self.binary_image)

        # Define the structuring element for dilation
        kernel = np.ones((2, 2), np.uint8)

        # Apply dilation to thicken the black features
        thickened_image = cv2.dilate(binary_array, kernel, iterations=1)

        self.binary_image = Image.fromarray(thickened_image)

        # Display the output image
        self.resize_display(self.binary_image, self.out_img_frame)

    def thick_in_fun(self):
        # Convert PIL Image to NumPy array
        binary_array = self.input_array

        # Define the structuring element for dilation
        kernel = np.ones((2, 2), np.uint8)

        # Apply dilation to thicken the black features
        thickened_image = cv2.erode(binary_array, kernel, iterations=1)

        input_image = Image.fromarray(thickened_image)

        output_path = self.data_dir.joinpath("preview", "preview_1.png")
        input_image.save(output_path)

        # Display the output image
        self.resize_display(output_path, self.in_img_frame)

        # Redo analysis
        self.input_array = thickened_image

        # Create the inverse binary array based on the threshold
        threshold = 127
        self.inv_array = np.where(self.input_array > threshold, 0, 1)

        # Label the inverse array
        self.labeled_array, self.num_labels = label(self.inv_array)

        # Count the occurence of each labeled value
        self.area_counts = np.bincount(self.labeled_array.ravel())[1:]

    def thin_in_fun(self):
        # Convert PIL Image to NumPy array
        binary_array = self.input_array

        # Define the structuring element for dilation
        kernel = np.ones((2, 2), np.uint8)

        # Apply dilation to thicken the black features
        thickened_image = cv2.dilate(binary_array, kernel, iterations=1)

        input_image = Image.fromarray(thickened_image)

        output_path = self.data_dir.joinpath("preview", "preview_1.png")

        input_image.save(output_path)

        # Display the output image
        self.resize_display(output_path, self.in_img_frame)

        # Redo analysis
        self.input_array = thickened_image

        # Create the inverse binary array based on the threshold
        threshold = 127
        self.inv_array = np.where(self.input_array > threshold, 0, 1)

        # Label the inverse array
        self.labeled_array, self.num_labels = label(self.inv_array)

        # Count the occurence of each labeled value
        self.area_counts = np.bincount(self.labeled_array.ravel())[1:]
