import math
from pathlib import Path

import numpy as np
from PIL import Image
from rich import print as pprint

from curveclaw.methods.utils import interpret_string
from curveclaw.settings import FILE_COLOR, MSG_COLOR, RESET, get_settings
from curveclaw.utils import create_directory

### COPYRIGHT ###
# 2-clause BSD License
# Copyright 2024 STFC
# Author: Dr. Felix Rummel

"""
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


#########################################################
##MAIN SCRIPT INITILISATION
#########################################################
def line_extraction(name, axis_lengths, step_size, log_scales, path_img):
    # Helper function to search for a pixel with value 1 starting from the center
    def search_from_center(inv_array, x_center, y_center, x_start, x_end, y_start, y_end):
        max_distance = max(cell_width, cell_height)
        for dist in range(max_distance):
            for dx in range(-dist, dist + 1):
                for dy in range(-dist, dist + 1):
                    x = x_center + dx
                    y = y_center + dy
                    if x_start <= x < x_end and y_start <= y < y_end:
                        if inv_array[y, x] == 1:
                            return x, y
        return None

    # Get the directory of the current script
    current_dir = Path(get_settings().data_dir)

    # Go one directory back and specify the 'output' folder
    output_dir = current_dir.joinpath("output")  # noqa

    # Load the image and convert to an array
    input_array = np.asarray(Image.open(current_dir.joinpath("curves", path_img)).convert("L"))

    # Create the inverse binary array based on the threshold
    threshold = 127
    inv_array = np.where(input_array > threshold, 0, 1)

    # Create arrays to store the x and y coordinates for each pixel
    x_values = np.zeros(inv_array.shape[1])
    y_values = np.zeros(inv_array.shape[0])

    # Determine the axis bounds
    min_x, max_x = axis_lengths[0]
    min_y, max_y = axis_lengths[1]

    # Determine which axis are log scales
    axis_log = [False, False]  # x scale and y scale log scale
    for idx, item in enumerate(log_scales):
        if idx < 2:
            if interpret_string(item) is True:
                axis_log[idx] = True

    # if a log scale exists all values must be positive integers,
    # sometimes the axis minima are 0, so make them very small instead
    if axis_log[0] is True and min_x == 0:
        min_x = 1e-10
    if axis_log[1] is True and min_y == 0:
        min_y = 1e-10

    # Calculate the x values
    for j in range(inv_array.shape[1]):  # x axis
        r_x = j / (inv_array.shape[1] - 1)
        if axis_log[0]:  # If x axis is log scale
            x_coord = math.pow(10, r_x * (math.log10(max_x) - math.log10(min_x)) + math.log10(min_x))
        else:  # If x axis is linear scale
            x_coord = r_x * (max_x - min_x) + min_x
        x_values[j] = x_coord

    # Calculate the y values
    for i in range(inv_array.shape[0]):  # y axis
        r_y = i / (inv_array.shape[0] - 1)
        if axis_log[1]:  # If y axis is log scale
            y_coord = math.pow(10, math.log10(max_y) - r_y * (math.log10(max_y) - math.log10(min_y)))
        else:  # If y axis is linear scale
            y_coord = max_y - (r_y * (max_y - min_y))
        y_values[i] = y_coord

    # Create a list to store the coordinates of pixels where inv_array value is 1
    coordinates = []

    # Iterate through each pixel in the image
    for i in range(inv_array.shape[0]):  # y axis
        for j in range(inv_array.shape[1]):  # x axis
            if inv_array[i, j] == 1:
                x = x_values[j]
                y = y_values[i]
                coordinates.append((x, y))

    # Create a grid of boxes to filter coordinates
    x_grid = int(step_size[0])
    y_grid = int(step_size[1])

    # Calculate the size of each grid cell
    cell_width = int(inv_array.shape[1] / x_grid)
    cell_height = int(inv_array.shape[0] / y_grid)

    # List to store the central coordinates
    central_coordinates = []

    # Iterate through each grid cell
    for grid_y in range(y_grid):
        for grid_x in range(x_grid):
            # Define the bounds of the current grid cell
            x_start = grid_x * cell_width
            x_end = (grid_x + 1) * cell_width if grid_x != x_grid - 1 else inv_array.shape[1]
            y_start = grid_y * cell_height
            y_end = (grid_y + 1) * cell_height if grid_y != y_grid - 1 else inv_array.shape[0]

            # Determine the center of the grid cell
            x_center = (x_start + x_end) // 2
            y_center = (y_start + y_end) // 2

            # Search for the nearest pixel with value 1 starting from the center
            result = search_from_center(inv_array, x_center, y_center, x_start, x_end, y_start, y_end)
            if result:
                x, y = result
                central_coordinates.append((x_values[x], y_values[y]))

    return coordinates, central_coordinates


def write_to_file(output_name, save_string_full, save_string_partial):
    # Define the directory and filename

    output_dir = Path(get_settings().data_dir).joinpath("output")
    # Replace this with your desired directory
    filename_full = f"full_curve_data_{output_name}.txt"  # Replace this with your desired filename
    filename_partial = f"partial_curve_data_{output_name}.txt"  # Replace this with your desired filename

    # Create the full path
    output_dir.joinpath(filename_full)
    output_dir.joinpath(filename_partial)
    file_path_full = output_dir.joinpath(filename_full)
    file_path_partial = output_dir.joinpath(filename_partial)

    # Ensure the directory exists
    create_directory(output_dir)

    # Write the string to the file
    with open(file_path_full, "w") as file:
        file.write(save_string_full)
    with open(file_path_partial, "w") as file:
        file.write(save_string_partial)

    pprint(f"{MSG_COLOR}Files saved at:{RESET} {FILE_COLOR}{output_dir}{RESET}")


def extract_line_data(
    filename: str, filepaths: list[str], axis_lengths: list[float], step_size: list[float], log_scales
):
    # Determine which axis are log scales
    axis_log = [False, False]  # x scale and y scale log scale
    for idx, item in enumerate(log_scales):
        if idx < 2:
            if interpret_string(item) is True:
                axis_log[idx] = True

    # Store the line coordinates
    full_coordinates = []
    sparse_coordinates = []
    # for each curve
    for path in filepaths:
        filepath = Path(path)
        # extract the curve coordinates
        coordinates, central_coordinates = line_extraction(
            filename,
            axis_lengths,
            step_size,
            log_scales,
            filepath.name,
        )
        full_coordinates.append((filepath.name, coordinates))
        sparse_coordinates.append((filepath.name, central_coordinates))

    # Comments to append at the start of the data files
    comments = (
        f"#Name of original image: {filename}\n"
        f"#X axis defined as: {axis_lengths[0][0]} to {axis_lengths[0][1]}\n"
        f"#Y axis defined as: {axis_lengths[1][0]} to {axis_lengths[1][1]}\n"
        f"#X grid set to: {step_size[0]}\n"
        f"#Y grid set to: {step_size[1]}\n"
        f"#X axis log property is: {axis_log[0]}\n"
        f"#Y axis log property is: {axis_log[1]}\n"
    )

    # Save the full and partial data
    save_string_full = "#Full Coordinate data for each curve\n"
    save_string_full += comments
    for group in full_coordinates:
        # obtain the tuple of curve name and coordinate list of tuples
        name = group[0]
        coords = group[1]
        save_string_full += f"#{name}\n#X_axis Y_axis\n"
        for coord in coords:
            x = coord[0]
            y = coord[1]
            save_string_full += f"{round(x, 4)} {round(y, 4)}\n"
        save_string_full += "\n"

    save_string_partial = "#Filtered Coordinate data for each curve\n"
    save_string_partial += comments
    for group in sparse_coordinates:
        # obtain the tuple of curve name and coordinate list of tuples
        name = group[0]
        coords = group[1]
        save_string_partial += f"#{name}\n#X_axis Y_axis\n"
        for coord in coords:
            x = coord[0]
            y = coord[1]
            save_string_partial += f"{round(x, 4)} {round(y, 4)}\n"
        save_string_partial += "\n"

    write_to_file(filename, save_string_full, save_string_partial)
