import tkinter as tk
from pathlib import Path
from tkinter import PhotoImage

from rich import print as pprint

from .auto_cleaner import AutoCleaner
from .controller import Controller
from .curve_selection import CurveSelection
from .data_extractor import DataExtractor
from .draw_lines import PaintApp
from .figure_extractor import FigureExtractionApp
from .hash_connector import HashCon
from .settings import FILE_COLOR, MSG_COLOR, RESET, WARN_COLOR, get_settings
from .utils import create_directory

"""
COPYRIGHT
2-clause BSD License
Copyright 2024 STFC
Author: Dr. Felix Rummel
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


class CurveClaw(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CurveClaw")

        # Fetch the screen dimensions to initilise the window
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        icon_path = Path.joinpath(Path(__file__).parent, "icon.png")
        if icon_path.exists():
            try:
                icon_png = PhotoImage(file=icon_path)
                self.iconphoto(True, icon_png)
            except tk.TclError:
                pprint(f"{WARN_COLOR}Warning: could not set iconphoto, running headless?{RESET}")

        self.width = round(screen_width * 0.95)
        self.height = round(screen_height * 0.9)
        x_position = (screen_width - self.width) // 2
        y_position = 0
        self.dimensions = (self.width, self.height)
        if self.width > self.height:
            self.orientation = "landscape"
        else:
            self.orientation = "portrait"
        self.geometry(f"{self.width}x{self.height}+{x_position}+{y_position}")

        # Folder and File checks
        self.script_dir = Path(get_settings().data_dir)
        self.preview_image_path = self.script_dir.joinpath("preview", "preview.png")
        self.curves_folder = self.script_dir.joinpath("curves")
        self.preview_folder = self.script_dir.joinpath("preview")
        self.output_folder = self.script_dir.joinpath("output")

        pprint(f"""
            {MSG_COLOR}Script directory:{RESET} {FILE_COLOR}{self.script_dir}{RESET}

            {MSG_COLOR}Creating folders:{RESET}
            {FILE_COLOR}• {self.curves_folder}{RESET}
            {FILE_COLOR}• {self.preview_folder}{RESET}
            {FILE_COLOR}• {self.output_folder}{RESET}
            """)

        create_directory(self.curves_folder)
        create_directory(self.preview_folder)
        create_directory(self.output_folder)

        # GUI startup
        self.container = tk.Frame(self)
        self.container.pack(fill="both", expand=True)

        # Page management
        self.pages = {}

        all_pages = {
            get_settings().controller_page: Controller,
            get_settings().image_cleaner_page: AutoCleaner,
            get_settings().curve_claw_page: CurveSelection,
            get_settings().data_extraction_page: DataExtractor,
            get_settings().draw_lines_page: PaintApp,
            get_settings().extract_graph_page: FigureExtractionApp,
            get_settings().hash_connector_page: HashCon,
        }

        preview_image_path = self.preview_folder.joinpath("preview.png")
        if preview_image_path.exists():
            self.input_name = preview_image_path.stem

        for page_name, page_class in all_pages.items():
            page_instance = page_class(self.container, self)

            self.pages[page_name] = page_instance
            page_instance.grid(row=0, column=0, sticky="nsew")

        self.show_page(Controller.__name__)

    def show_page(self, page_name, opt_args = None):
        """Show a page by name."""
        page = self.pages.get(page_name)
        if page:
            if hasattr(page, "on_show_page"):
                if opt_args is None:
                    page.on_show_page()
                else:
                    page.on_show_page(opt_args)
            page.tkraise()
