import tkinter as tk
from pathlib import Path
from tkinter import Label, filedialog
from unittest.mock import patch

import pytest
from PIL import Image, ImageChops

from curveclaw.auto_cleaner import AutoCleaner
from curveclaw.controller import Controller
from curveclaw.curve_selection import CurveSelection
from curveclaw.data_extractor import DataExtractor
from curveclaw.figure_extractor import FigureExtractionApp
from curveclaw.hash_connector import HashCon
from curveclaw.meta_entry import AxisApp

from .utils import TestParent


class TestCurveClaw(TestParent):
    def test_file_paths_initialization(self):
        """Test that file paths and directories are initialized correctly."""
        assert str(self.main_app.curves_folder) == self.expected_curves_folder
        assert str(self.main_app.preview_folder) == self.expected_preview_folder
        assert str(self.main_app.output_folder) == self.expected_output_folder

        # Verify folders are created

        assert Path(self.expected_curves_folder).exists()
        assert Path(self.expected_preview_folder).exists()
        assert Path(self.expected_output_folder).exists()

    # Patch display_input_image because we arent actually displaying for tests
    @patch.object(CurveSelection, "display_input_image")
    def test_curve_selection_file_path(self, mock_display_input_image):
        app = CurveSelection(self.main_app.container, self.main_app)

        # Verify app is using correct folders
        assert str(app.curves_folder) == self.expected_curves_folder
        assert self.expected_curves_folder in str(app.hold_image_path)

    def test_controller_file_path(self):
        app = Controller(self.main_app.container, self.main_app)

        # Verify app is using correct folders
        assert str(app.data_dir) == self.temp_dir.name

        app.save_preview(self.test_image_path)
        preview_image_path = Path(f"{self.expected_preview_folder}/preview.png")

        # Verify that controller saved image in preview folder
        assert preview_image_path.is_file()

    # Patch resize_display because we arent actually displaying for tests
    @patch.object(AutoCleaner, "resize_display")
    def test_auto_cleaner_file_path(self, mock_display_input):
        app = AutoCleaner(self.main_app.container, self.main_app)

        assert str(app.data_dir) == self.temp_dir.name

        # Create file to be deleted
        deleted_file_path = Path(self.create_test_image(f"{self.expected_curves_folder}/curve_to_delete.png"))
        app.delete_curve_files()

        # Verify that file does not exist
        assert not deleted_file_path.is_file()

    # Patch displays because we arent actually displaying for tests
    @patch.object(FigureExtractionApp, "resize_display")
    def test_fig_extraction_file_path(self, mock_display_output_image):
        def verify_image_change(action_function, image_path):
            self.create_test_image(image_path)
            initial_image = Image.open(image_path)
            action_function()
            modified_image = Image.open(image_path)
            diff = ImageChops.difference(initial_image, modified_image.convert("RGB"))
            assert diff.getbbox()

        # Verify if the app uses the correct dir
        app = FigureExtractionApp(self.main_app.container, self.main_app)
        app.on_show_page()
        assert str(app.data_dir) == self.temp_dir.name

        image_path = f"{self.expected_preview_folder}/extraction_preview.png"

        # Verify if the image changes when running the thicken function
        verify_image_change(app.thicken, image_path)

        # Verify if the image changes when running the flip function
        verify_image_change(app.flip, image_path)

        # Verify if the image changes when running the rotate function
        verify_image_change(app.rotate, image_path)

        # Verify if the image changes when running the straighten function
        verify_image_change(app.straighten, image_path)

        # Verify if the image file name is changed after running the finish function
        app.ternary = tk.BooleanVar(value=True)
        image_path = self.create_test_image(f"{self.expected_preview_folder}/extraction_preview.png")
        app.finish()
        preview_image_path = f"{self.expected_preview_folder}/preview.png"
        assert Path(preview_image_path).exists()

        # Verify if the detect function generates an extraction preview image
        Path(image_path).unlink()
        assert not Path(image_path).exists()
        app.detect()
        assert Path(image_path).exists()

        # Verify if the detect function generates an extraction preview image when ternary is set to false
        preview_image_path = self.create_test_image(f"{self.expected_preview_folder}/preview.png")
        Path(image_path).unlink()
        assert not Path(image_path).exists()
        app.ternary.set(False)
        app.detect()
        assert Path(image_path).exists()

    # Patch display, label bind and label destory because we arent actually displaying for tests
    @patch.object(HashCon, "display_image")
    @patch.object(Label, "bind")
    @patch.object(Label, "destroy")
    @patch.object(Image.Image, "resize")
    def test_hash_connector_file_path(self, mock_resize, mock_destroy, mock_bind, mock_display_image):
        def mock_page_show(*args, **kwargs):
            return None

        mock_resize.return_value = Image.new("RGB", (100, 100))

        app = HashCon(self.main_app.container, self.main_app)

        app.input_image_path = self.create_test_image(f"{self.expected_preview_folder}/preview.png")
        app.on_show_page()
        app.image_frame.image_label = Label
        app.to_connect = []
        app.disp_image_label = Label

        hold_path = f"{self.expected_preview_folder}/hold.png"
        app.draw_path(save=False)
        assert Path(hold_path).exists()

        preview_path = f"{self.expected_preview_folder}/preview.png"
        app.draw_path(save=True)
        assert Path(preview_path).exists()

        image_to_delete_path = self.create_test_image(f"{self.expected_preview_folder}/hold.png")
        with patch.object(app.controller, "show_page", side_effect=mock_page_show):
            app.exit_save_fun()
        assert not Path(image_to_delete_path).exists()

    def test_axis_app_file_path(self):
        app = AxisApp(self.mock_tk, self.test_image_path)
        app.save_string_to_file("test")
        meta_file_path = f"{self.expected_preview_folder}/meta_data.txt"
        assert Path(meta_file_path).exists()

    @patch.object(DataExtractor, "display_output")
    def test_data_extractor_file_path(self, mock_display_output):
        def mock_file_open(*args, **kwargs):
            initial_dir = kwargs.get("initialdir", None)
            if initial_dir:
                dir_path = Path(initial_dir)
                return [str(dir_path.joinpath(file)) for file in dir_path.iterdir()]
            else:
                return None

        def mock_page_show(*args, **kwargs):
            return None

        self.main_app.input_name = "test"
        app = DataExtractor(self.main_app.container, self.main_app)
        app.on_show_page()

        # Verify that selecting files adds them to the file path of the app
        test_image = self.create_test_image(f"{self.expected_curves_folder}/test.png")
        with patch.object(filedialog, "askopenfilenames", side_effect=mock_file_open):
            app.select_files_fun()
            assert test_image in app.file_paths

        # Verify that auto select picks up files that start with curve from curve folder
        curve_image = Path(self.create_test_image(f"{self.expected_curves_folder}/curve_1.png"))
        app.auto_select_fun()
        assert curve_image in app.file_paths

        # Verify that auto select picks up preview files if curve files do not exist
        Path(curve_image).unlink()
        preview_image = Path(self.create_test_image(f"{self.expected_preview_folder}/preview.png"))
        app.auto_select_fun()
        assert preview_image in app.file_paths

        # Verify that drawing on overlay generates a overlayed curves file
        with patch.object(app.controller, "show_page", side_effect=mock_page_show):
            overlayed_curves_path = f"{self.expected_curves_folder}/overlayed_curves.png"
            app.draw_on_overlay_fun()
            assert Path(overlayed_curves_path).exists()

        # Verify that an overlayed curve path file has to exist before closing the draw function
        Path(overlayed_curves_path).unlink()
        with pytest.raises(FileNotFoundError):
            app.close_function_draw()

        # Verify that the app processes the overlayed curve omage
        self.create_test_image(overlayed_curves_path)
        app.overlayed_curves_image = None
        app.close_function_draw()

        generated_image = Image.open(overlayed_curves_path)
        diff = ImageChops.difference(app.overlayed_curves_image, generated_image.convert("L"))
        assert not diff.getbbox()

        # Verify that meta data gets added to output file
        meta_text = "test me"
        meta_data_file_path = Path(f"{self.expected_preview_folder}/meta_data.txt")
        meta_data_file_path.write_text(meta_text)

        area_data_file_path = Path(f"{self.expected_preview_folder}/area_data.txt")
        area_data_file_path.write_text("")

        output_file_path = Path(f"{self.expected_output_folder}/{app.output_name}.txt")
        output_file_path.write_text("")

        app.add_meta_area_data()

        with open(output_file_path) as file:
            output = file.read()
            assert output == meta_text

        # Verify that area data gets saved in the right place
        Path(area_data_file_path).unlink()
        app.save_area_dictionary()
        assert Path(area_data_file_path).exists()

        # Verify that curve data gets saved in the right place
        curve_file_path = f"{self.expected_preview_folder}/curve_data.txt"
        app.curve_dictionary = {}
        app.save_curve_dictionary()
        assert Path(curve_file_path).exists()
