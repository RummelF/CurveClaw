import glob
import logging
from functools import cache
from pathlib import Path
from tkinter import ttk

from rich.logging import RichHandler

LOG_LEVEL = logging.INFO


@cache
def package() -> str:
    """Get the name of the top-level package"""
    return __name__.split(".")[0]


def create_directory(path_name: str) -> None:
    """Create a directory if it doesn't exist already"""
    new_dir = Path(path_name)
    new_dir.mkdir(parents=True, exist_ok=True)


def build_frame(parent: ttk.Frame, height: int, width: int, text: str, coords: tuple[int, int]) -> ttk.LabelFrame:
    if text:
        frame_instance = ttk.LabelFrame(
            parent,
            text=text,
            width=width,
            height=height,
            padding=(20, 10),
        )
    else:
        frame_instance = ttk.Frame(
            parent,
            width=width,
            height=height,
            padding=(20, 10),
        )

    row, col = coords

    frame_instance.grid(row=row, column=col, padx=(20, 10), pady=(20, 10), sticky="nswe")
    frame_instance.grid_propagate(False)

    return frame_instance


def delete_files(path, patterns):
    # Iterate over each pattern
    for pattern in patterns:
        files_to_delete = glob.glob(str(path.joinpath(pattern)))

        # Delete each file found by the pattern
        for file_path in files_to_delete:
            try:
                Path(file_path).unlink()
                print(f"Deleted: {file_path}")
            except OSError as e:
                print(f"Error deleting {file_path}: {e}")


logger = logging.getLogger()

user_flow_handler = RichHandler()
user_flow_handler.setLevel(logging.INFO)

debug_handler = RichHandler()
debug_handler.setLevel(logging.DEBUG)

user_flow_formatter = logging.Formatter("%(message)s")
debug_formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s", datefmt="[%X]"
)

user_flow_handler.setFormatter(user_flow_formatter)
debug_handler.setFormatter(debug_formatter)

# Add both handlers to the logger
logger.addHandler(user_flow_handler)
logger.addHandler(debug_handler)

logger.setLevel(LOG_LEVEL)

# Disable Pillow (PIL) debug logs
logging.getLogger("PIL").setLevel(logging.WARNING)
