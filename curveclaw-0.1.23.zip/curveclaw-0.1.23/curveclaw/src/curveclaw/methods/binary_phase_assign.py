from pathlib import Path

import numpy as np
from PIL import Image
from rich import print as pprint
from rich.progress import track
from scipy.ndimage import label

from curveclaw.methods.utils import create_binary_image_from_array, interpret_string
from curveclaw.settings import MSG_COLOR, RESET, get_settings

### COPYRIGHT ###
# 2-clause BSD License
# Copyright 2024 STFC
# Author: Dr. Felix Rummel

"""
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


#########################################################
##MAIN SCRIPT INITILISATION
#########################################################


def assign_phases_fun(filename, axis_lengths, step_size, log_scales):
    # Get the directory of the current script
    current_dir = Path(get_settings().data_dir)

    # Go one directory back and specify the 'output' folder
    output_dir = current_dir.joinpath("output")

    # Load the input image as a black and white array
    input_array = np.asarray(Image.open(output_dir.joinpath(f"{filename}_out.png")).convert("L"))

    # Get the size of the image
    rows, columns = input_array.shape
    min_x, max_x = axis_lengths[0]
    min_y, max_y = axis_lengths[1]

    # Determine which axis are log scales
    axis_log = [False, False]  # x scale and y scale log scale
    for idx, item in enumerate(log_scales):
        if idx < 2:
            if interpret_string(item) is True:
                axis_log[idx] = True

    # Generate coordinates
    if axis_log[0] is True or axis_log[1] is True:  # Check if either axis is log scale
        if axis_log[0] is True and axis_log[1] is True:
            # Both axes are log scale
            if min_x == 0:
                min_x = 1e-10
            if min_y == 0:
                min_y = 1e-10
            x = np.logspace(np.log10(min_x), np.log10(max_x), int(step_size[0]))
            y = np.logspace(np.log10(min_y), np.log10(max_y), int(step_size[1]))
        elif axis_log[0] is True and axis_log[1] is False:
            # Only x-axis is log scale
            if min_x == 0:
                min_x = 1e-10
            x = np.logspace(np.log10(min_x), np.log10(max_x), int(step_size[0]))
            y = np.linspace(min_y, max_y, int(step_size[1]))
        elif axis_log[1] is True and axis_log[0] is False:
            # Only y-axis is log scale
            if min_y == 0:
                min_y = 1e-10
            x = np.linspace(min_x, max_x, int(step_size[0]))
            y = np.logspace(np.log10(min_y), np.log10(max_y), int(step_size[1]))
    else:
        # No log scales
        x = np.linspace(min_x, max_x, int(step_size[0]))
        y = np.linspace(min_y, max_y, int(step_size[1]))

    # Generate meshgrid
    X, Y = np.meshgrid(x, y)

    # create the pixel coordinates of test points
    x_s, y_s = np.meshgrid(
        np.linspace(0, columns - 1, int(step_size[0])),
        np.linspace(rows - 1, 0, int(step_size[1])),
    )

    # Reshape the grid to obtain Points
    Points = np.column_stack((X.ravel(), Y.ravel()))

    # Convert to list of tuples
    coordinate_list = [tuple(point) for point in Points]

    # Reshape the grid to obtain Points scaled to the image
    Points = np.column_stack((x_s.ravel(), y_s.ravel()))

    # Convert to list of tuples
    scaled_coordinate_list = [tuple(point) for point in Points]
    pprint(f"{MSG_COLOR}Created coordinate grids{RESET}")

    # Label the image
    labeled_array, _ = label(input_array)

    # Create an array to store the phase of each point
    phases = [0] * len(coordinate_list)

    # Iterate through the array to obtain each phase
    for c_idx, coord in track(enumerate(scaled_coordinate_list), description="[cyan]Extracting phases..."):
        if c_idx % 1000 == 0:  # Print progress every 1000 iterations
            pprint(f"Iteration {c_idx + 1} out of {len(scaled_coordinate_list)} phases")

        col = int(coord[0])
        row = int(coord[1])
        phases[c_idx] = labeled_array[row, col]

    pprint(f"{MSG_COLOR}Determined phases for each point{RESET}")

    # Create the output matrix
    output = (
        f"#Name of original image: {filename} \n"
        f"#X axis defined as: {min_x} to {max_x} \n"
        f"#Y axis defined as: {min_y} to {max_y} \n"
        f"#X grid set to: {step_size[0]} \n"
        f"#Y grid set to: {step_size[1]} \n"
        f"#X axis log property is: {axis_log[0]} \n"
        f"#Y axis log property is: {axis_log[1]} \n"
    )
    output += "Name X_axis Y_axis Phase\n"
    for idx, phase in enumerate(phases):
        if phase != 0:
            output += f"{filename} {coordinate_list[idx][0]}" + \
            f" {coordinate_list[idx][1]} area_{phase}\n"
    # Save the output as a txt file

    with open(output_dir.joinpath(f"{filename}.txt"), "w") as file:
        file.write(output)

    # Create an image with the labeled areas and also save it.
    create_binary_image_from_array(labeled_array, output_dir.joinpath(f"{filename}.png"))
