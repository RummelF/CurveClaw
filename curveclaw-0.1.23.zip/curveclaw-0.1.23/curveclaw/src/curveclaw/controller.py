import re
import shutil
import tkinter as tk
from functools import partial
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageTk
from tktooltip import ToolTip

from .settings import get_settings
from .utils import build_frame

"""
COPYRIGHT
2-clause BSD License
Copyright 2024 STFC
Author: Dr. Felix Rummel
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


class Controller(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.data_dir = Path(get_settings().data_dir)
        self.setup_ui()

    def setup_ui(self):
        if self.controller.orientation == "landscape":  # Landscape orientation
            self.input_image_frame = build_frame(
                parent=self,
                height=self.controller.height - 100,
                width=self.controller.width / 2,
                text="Working Image",
                coords=(0, 0),
            )

            # Create a grid layout with two columns and one row
            self.buttons_frame = ttk.Frame(self, width=self.controller.width / 2, height=self.controller.height)
            self.buttons_frame.grid(row=0, column=1, sticky="nwes", rowspan=1)  # Place in the first row

        else:  # Portrait orientation
            # Set the preview image frame
            self.input_image_frame = build_frame(
                parent=self,
                height=self.controller.height * 0.5 - 45,
                width=self.controller.width,
                text="Working Image",
                coords=(0, 0),
            )

            # Create a grid layout with one column and two rows
            self.buttons_frame = ttk.Frame(self, width=self.controller.width, height=self.controller.height * 0.5)
            self.buttons_frame.grid(row=2, column=0, sticky="nwes")  # Place in the first column

        # Add all the widgets
        self.create_widgets()

    ### Define buttons and such ###
    def create_widgets(self):
        def build_frame_buttons(frame, page_buttons):
            for button_text, button_info in page_buttons.items():
                page_command = partial(self.change_page, button_info["page_name"])

                button_instance = ttk.Button(frame, text=button_text, command=page_command, width=16)
                ToolTip(button_instance, msg=button_info["tooltip"], delay=0.5)

                row, col = button_info["grid_coords"]
                button_instance.grid(row=row, column=col, padx=5, pady=5)

        # File Selection
        image_frame = build_frame(parent=self.buttons_frame, height=90, width=400, text="Image Loading", coords=(0, 0))
        # Select file button
        select_file = ttk.Button(image_frame, text="Select Image", command=self.select_file_fun, width=16)
        ToolTip(select_file, msg="Load your Image file: *.png, *.jpeg, *.jpg", delay=0.5)
        select_file.grid(row=1, column=0, padx=5, pady=5, sticky="w")

        # Image Cleaning
        cleaning_frame = build_frame(
            parent=self.buttons_frame, height=135, width=400, text="Image Cleaning", coords=(1, 0)
        )
        cleaning_frame_buttons = {
            "Draw Lines": {
                "page_name": get_settings().draw_lines_page,
                "tooltip": "Draw lines on the working image, may help with extraction or data selection.",
                "grid_coords": (1, 1),
            },
            "Extract Graph": {
                "page_name": get_settings().extract_graph_page,
                "tooltip": "Extract the graph's content. Select an image first. If border detection fails, draw lines "
                "to reinforce the border.",
                "grid_coords": (1, 0),
            },
            "Image Cleaner": {
                "page_name": get_settings().image_cleaner_page,
                "tooltip": "Clean the graph area of annotations, grid lines, and other features (optional), which may "
                "make subsequent stages easier.",
                "grid_coords": (2, 0),
            },
            "Line Connector": {
                "page_name": get_settings().hash_connector_page,
                "tooltip": "Tool to connect together hashed lines in the image.",
                "grid_coords": (2, 1),
            },
        }
        build_frame_buttons(cleaning_frame, cleaning_frame_buttons)

        # Data Selection
        data_selection_frame = build_frame(
            parent=self.buttons_frame, height=90, width=400, text="Data Selection", coords=(2, 0)
        )
        data_selection_frame_buttons = {
            "Curve Selection": {
                "page_name": get_settings().curve_claw_page,
                "tooltip": "Tool to extract individual lines/connected features to define parts of an image to keep",
                "grid_coords": (1, 0),
            },
        }
        build_frame_buttons(data_selection_frame, data_selection_frame_buttons)

        # Data Extraction
        data_extraction_frame = build_frame(
            parent=self.buttons_frame, height=90, width=400, text="Data Extraction", coords=(3, 0)
        )
        data_extraction_frame_buttons = {
            "Data Extraction": {
                "page_name": get_settings().data_extraction_page,
                "tooltip": "Extracts numerical data from the working image or extracted features taken from curveclaw",
                "grid_coords": (1, 0),
            },
        }
        build_frame_buttons(data_extraction_frame, data_extraction_frame_buttons)

        # change working directory button
        change_workdir = ttk.Button(self.buttons_frame, text="Change Working Directory", command=self.change_dir)
        ToolTip(change_workdir,
                msg="Change where CurevClaw saves and reads data to and from, requires restarting CurveClaw!",
                delay=0.5)
        change_workdir.grid(row=4, column=0, columnspan=2, padx=5, pady=5)

        # Exit button
        exit_app = ttk.Button(self.buttons_frame, text="Exit", command=self.exit_app_fun, width=16)
        exit_app.grid(row=5, column=0, columnspan=2, padx=5, pady=5)




    #########################################################
    ##DEFINE ALL BUTTON FUNCTIONS HERE
    #########################################################
    def change_dir(self):
        # Open a directory selection dialog
        selected_dir = filedialog.askdirectory(title="Select Working Directory")

        if selected_dir:
            new_path = Path(selected_dir)

            # Optional: check if the path exists and is a directory
            if new_path.exists() and new_path.is_dir():
                # Save the new path to working_dir.txt file
                working_dir_file = Path(get_settings().default_data_dir) / get_settings().working_dir_file
                working_dir_file.write_text(str(new_path), encoding="utf-8")
                self.data_dir = new_path
                message = f"The new working directory will be {new_path}.\n\n" + \
                    "Please restart CurveClaw for changes to take effect."
                messagebox.showinfo("Restart required", message)
            else:
                message = "The selected path does not exist/is not a directory, please try again."
                messagebox.showinfo("Error", message)

    def select_file_fun(self):
        file_types = [
            ("Image files", "*.jpg"),
            ("Image files", "*.jpeg"),
            ("Image files", "*.png"),
            ("Image files", "*.gif"),
        ]

        file_paths = filedialog.askopenfilenames(filetypes=file_types)

        if file_paths:
            selected_file = file_paths[0]  # Display only the first selected file
            # Update the image preview
            self.load_image_preview(file_paths[0])
            # Save a copy of the selected image as "preview.png"
            self.save_preview(file_paths[0])
            # Delete files in the "curves" directory matching the pattern "curve_n.png" and "hold.png"
            curves_dir = self.data_dir.joinpath("curves")
            if curves_dir.exists() and curves_dir.is_dir():
                pattern = re.compile(r"curve_\d+\.png")  # Match filenames like "curve_n.png"
                for file_name in curves_dir.iterdir():
                    file_path = curves_dir.joinpath(file_name)
                    if file_path.is_file() and pattern.match(str(file_name)):
                        file_path.unlink()
                pattern = re.compile("hold.png")  # Match filenames like "curve_n.png"
                for file_name in curves_dir.iterdir():
                    file_path = curves_dir.joinpath(file_name)
                    if file_path.is_file() and pattern.match(str(file_name)):
                        file_path.unlink()
        self.controller.input_name = Path(selected_file).stem
        self.preview_image_label_txt = f"Working Image: {self.controller.input_name}"

    def change_page(self, name):
        self.controller.show_page(name)
        self.update_preview_image()

    def exit_app_fun(self):
        self.controller.quit()

    #########################################################
    ##DEFINE ALL OTHER FUNCTIONS HERE
    #########################################################
    def load_image_preview(self, file_path):
        if hasattr(self, "input_image_label"):
            self.input_image_label.destroy()
        image = Image.open(file_path)
        # resize emsuring the correct aspect ratio
        width, height = image.size

        # determine the maximum dimensions
        max_width = int(self.controller.width / 2)
        max_height = int(self.controller.height / 2)

        # Calculate the aspect ratio of the original image
        aspect_ratio = width / height

        # Calculate the new dimensions while maintaining the aspect ratio
        if (width / max_width) > (height / max_height):
            new_width = max_width
            new_height = int(max_width / aspect_ratio)
        else:
            new_height = max_height
            new_width = int(max_height * aspect_ratio)

        # resize accordingly
        image = image.resize((new_width, new_height), Image.LANCZOS)  # Resize the image for preview
        image = ImageTk.PhotoImage(image)
        self.input_image_label = ttk.Label(self.input_image_frame, image=image)
        self.input_image_label.image = image
        self.input_image_label.pack()

    def save_preview(self, file_path):
        # Get the directory of the main script
        preview_image_path = self.data_dir.joinpath("preview", "preview.png")

        # Copy the selected image to the preview directory and rename it to "preview.png"
        shutil.copy(file_path, preview_image_path)

    def update_preview_image(self):
        # Load the preview image
        preview_image_path = self.data_dir.joinpath("preview", "preview.png")

        if preview_image_path.exists():
            # Update the image preview
            self.load_image_preview(preview_image_path)

    def on_show_page(self):
        self.create_widgets()
        self.update_preview_image()
