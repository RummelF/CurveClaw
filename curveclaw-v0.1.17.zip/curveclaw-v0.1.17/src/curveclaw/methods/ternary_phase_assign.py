from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from rich import print as pprint
from rich.progress import track
from scipy.ndimage import label

from curveclaw.methods.utils import (
    bary_to_cart,
    bary_to_real,
    create_ternary_image_from_array,
    find_closest_nonzero_pixel,
    interpret_string,
)
from curveclaw.settings import FILE_COLOR, MSG_COLOR, RESET, VAR_COLOR, get_settings

### COPYRIGHT ###
# 2-clause BSD License
# Copyright 2024 STFC
# Author: Dr. Felix Rummel

"""
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


#########################################################
##MAIN SCRIPT INITILISATION
#########################################################


def area_assign_fun(filename, axis_lengths, step_size, log_scales):
    # Get the directory of the current script
    current_dir = Path(get_settings().data_dir)

    # Go one directory back and specify the 'output' folder
    output_dir = current_dir.joinpath("output")

    # Load the input image as a black and white array
    input_array = np.asarray(Image.open(output_dir.joinpath(f"{filename}_out.png")).convert("L"))

    # Label the image
    labeled_array, num_labels = label(input_array)

    # Get the size of the image
    rows, columns = input_array.shape

    # Determine which axis are log scales
    axis_log = [False, False, False]  # x scale y and z scale log scale
    for idx, item in enumerate(log_scales):
        if idx < 3:
            if interpret_string(item) is True:
                axis_log[idx] = True

    # Locate the corners of the triangle
    # Load black and white image
    bw_image = cv2.imread(output_dir.joinpath(f"{filename}_out.png"), cv2.IMREAD_GRAYSCALE)

    # Invert the image if the triangle is black on a white background
    inverted_image = cv2.bitwise_not(bw_image)

    # Ensure the image is binary (black and white)
    _, binary_image = cv2.threshold(inverted_image, 127, 255, cv2.THRESH_BINARY)

    # Find contours of shapes in the binary image
    contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Filter out the largest triangle based on its shape
    largest_triangle = None
    largest_area = 0
    for contour in contours:
        perimeter = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.04 * perimeter, True)  # Approximate the polygon

        if len(approx) == 3:  # Check if the contour is a triangle
            area = cv2.contourArea(contour)
            if area > largest_area:  # Find the largest triangle by area
                largest_triangle = approx
                largest_area = area

    # Check if a triangle was found
    if largest_triangle is not None:
        corners = []
        labels = ["A", "B", "C"]

        # Create a copy of the original image to overlay the points
        image_with_points = cv2.cvtColor(bw_image, cv2.COLOR_GRAY2BGR)  # noqa

        # Save the vertices of the triangles
        for idx, vertex in enumerate(largest_triangle):
            x, y = vertex[0]
            corners.append((labels[idx], (x, y)))

        # Define the corners
        A = np.array([corners[0][1][0], corners[0][1][1]])
        B = np.array([corners[1][1][0], corners[1][1][1]])
        C = np.array([corners[2][1][0], corners[2][1][1]])
        pprint(f"""
            {MSG_COLOR}Triangle located with the corners:{RESET}
            • {MSG_COLOR}A:{RESET} {VAR_COLOR}{corners[0][1][0]}, {corners[0][1][1]}{RESET}
            • {MSG_COLOR}B:{RESET} {VAR_COLOR}{corners[1][1][0]}, {corners[1][1][1]}{RESET}
            • {MSG_COLOR}C:{RESET} {VAR_COLOR}{corners[2][1][0]}, {corners[2][1][1]}{RESET}
        """)

        # Create the test points in barycentric space
        a_linspace = np.linspace(1, 0, int(step_size[0]))  # start close to A and move to C
        b_linspace = np.linspace(1, 0, int(step_size[1]))  # start close to B and move to A
        c_linspace = np.linspace(1, 0, int(step_size[2]))  # start close to C and move to B
        a, b, c = np.meshgrid(a_linspace, b_linspace, c_linspace)
        test_points = np.column_stack((a.ravel(), b.ravel(), c.ravel()))
        # keep only points where alpha + beta + gamme = 1
        test_points = [
            [round(point[0], 4), round(point[1], 4), round(point[2], 4)]
            for point in test_points
            if round(sum(point), 3) == 1
        ]

        # Assign Each test point to its phase.
        Areas = [0] * len(test_points)

        # Create a progress bar

        for idx, (alpha, beta, gamma) in track(
            enumerate(test_points), description=f"{MSG_COLOR}Processing points...{RESET}", total=len(test_points)
        ):
            if idx % 1000 == 0:  # Print every 1000 iterations
                pprint(f"{MSG_COLOR}Iteration {VAR_COLOR}{idx + 1}{RESET} / {VAR_COLOR}{len(test_points)}{RESET}")

            # Determine the col and row of the current point
            (col, row) = bary_to_cart(A, B, C, alpha, beta, gamma)

            # Handle edge cases
            if labeled_array[row, col] < 2:
                (row_n, col_n) = find_closest_nonzero_pixel(labeled_array, row, col)
                Areas[idx] = labeled_array[row_n, col_n]
            else:
                Areas[idx] = labeled_array[row, col]

        # Create the output matrix
        output = (
            f"#Name of original image: {filename} \n"
            f"#X axis defined as: {axis_lengths[0][0]} to {axis_lengths[0][1]} \n"
            f"#Y axis defined as: {axis_lengths[1][0]} to {axis_lengths[1][1]} \n"
            f"#Z axis defined as: {axis_lengths[2][0]} to {axis_lengths[2][1]} \n"
            f"#X grid set to: {step_size[0]} \n"
            f"#Y grid set to: {step_size[1]} \n"
            f"#Z grid set to: {step_size[2]} \n"
            f"#X axis log property is: {axis_log[0]} \n"
            f"#Y axis log property is: {axis_log[1]} \n"
            f"#Z axis log property is: {axis_log[2]} \n"
            f"#Triangle corners A, B C found at [row, col] {A}, {B}, {C} \n"
        )
        output += "Name X_axis Y_axis Z_axis Area\n"
        for idx, area in enumerate(Areas):
            point = bary_to_real(test_points[idx], axis_lengths, axis_log)
            output += f"{filename} {point[0]} {point[1]} {point[2]} Area_{area - 1} \n"

        # Save the output as a txt file
        file_name = output_dir.joinpath(f"{filename}.txt")

        pprint(f"{FILE_COLOR}{file_name}{RESET}")
        with open(file_name, "w") as file:
            file.write(output)

        # Create an image with the labeled areas and also save it.
        create_ternary_image_from_array(labeled_array, output_dir.joinpath(f"{filename}.png"), A, B, C)
    else:
        pprint(f"{MSG_COLOR}No triangle found in the image.{RESET}")
