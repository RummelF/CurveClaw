import json
import re
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError, field_serializer
from pydantic_core import PydanticSerializationError

# The InputValidator Classes are used to validate and transform any input provided
# by the user. If adding a new method file a new class must be created for its input


class DataInputValidator(BaseModel):
    filename: str = Field(min_length=1, description="Name of the output file")
    axis_lengths: str = Field(pattern=r"\(?-?\d+(?:\.\d+)?,\-?\d+(?:\.\d+)?\)?", count=2)
    step_size: str = Field(pattern=r"\d+", count=2)
    log_scales: str = Field()

    @field_serializer("axis_lengths")
    def transform_data_range_entry(self, value, info):
        fields = self.model_json_schema().get("properties")
        pattern = fields.get(info.field_name).get("pattern")
        axis_count = fields.get(info.field_name).get("count")

        matches = re.findall(pattern, value)
        if len(matches) != axis_count:
            raise ValueError("Invalid axis_lengths format")

        return [tuple(map(float, match.strip("()").split(","))) for match in matches]

    @field_serializer("step_size")
    def transform_step_entry(self, value, info):
        fields = self.model_json_schema().get("properties")
        pattern = fields.get(info.field_name).get("pattern")
        step_count = fields.get(info.field_name).get("count")

        matches = re.findall(pattern, value)

        if len(matches) != step_count:
            raise ValueError("Incorrect step count.")

        return [float(value) for value in matches]


class LineDataInput(DataInputValidator):
    filepaths: list[Path] = Field(description="A list of valid file paths")
    extraction_mode: Literal["Line"]

    @field_serializer("filepaths")
    def transform_filepaths(self, value):
        filepaths = [Path(path) for path in value]

        for filepath in filepaths:
            if not filepath.exists():
                raise ValueError("File path does not exist.")

        return filepaths


class BinaryPhaseAssignInput(DataInputValidator):
    extraction_mode: Literal["Binary"]


class BinaryProbabilityInput(BinaryPhaseAssignInput): ...


class TernaryPhaseAssignInput(DataInputValidator):
    axis_lengths: str = Field(pattern=r"\(-?\d+,-?\d+\)", count=3)
    step_size: str = Field(pattern=r"\d+", count=3)
    extraction_mode: Literal["Ternary"]


class TernaryProbabilityInput(TernaryPhaseAssignInput): ...


def process_input(cls: type[DataInputValidator], data: dict[str, Any]) -> dict[str, Any]:
    try:
        return json.loads(cls(**data).model_dump_json())
    except (PydanticSerializationError, ValidationError) as err:
        return {"status": "error", "errors": err}
