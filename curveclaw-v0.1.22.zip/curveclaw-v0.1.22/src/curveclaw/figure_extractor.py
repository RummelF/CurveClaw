import shutil
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

import cv2
import numpy as np
from PIL import Image, ImageTk
from tktooltip import ToolTip

from .base import BaseFrame
from .settings import get_settings
from .utils import build_frame, create_directory

"""
COPYRIGHT
2-clause BSD License
Copyright 2024 STFC
Author: Dr. Felix Rummel
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


class FigureExtractionApp(BaseFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        if hasattr(self.controller, "preview_image_path"):
            self.setup_ui()

    def setup_ui(self):
        self.data_dir = Path(get_settings().data_dir)
        self.input_image_path = self.controller.preview_image_path
        # Initialize rotation angle
        self.rotation_angle = 0

        # Initialize straightened flag
        self.is_straightened = False
        self.output_image_path = None

        # Initialise window depending on screen
        if self.controller.orientation == "landscape":  # Landscape orientation
            self.frame_height = int(self.controller.height / 2) - 50
            self.frame_width = int(self.controller.width / 2)

            # Set the preview image frame
            self.in_img_frame = build_frame(
                parent=self, height=self.frame_height, width=self.frame_width, text="Input Image", coords=(0, 0)
            )

            # Create a grid layout spanning two column and one row
            self.control_frame = ttk.LabelFrame(
                self, height=self.frame_height, width=self.frame_width, text="Processing Options"
            )
            self.control_frame.grid(padx=(20, 10), pady=(20, 10), row=1, column=0, columnspan=2, sticky="nsew")

            # Set the output image frame
            self.out_img_frame = build_frame(
                parent=self, height=self.frame_height, width=self.frame_width, text="Output Image", coords=(0, 1)
            )
        else:  # Portrait orientation
            self.frame_height = int(self.controller.height / 2)
            self.frame_width = int(self.controller.width / 2) - 50

            # Set the preview image frame
            self.in_img_frame = build_frame(
                parent=self, height=self.frame_height, width=self.frame_width, text="Input Image", coords=(0, 0)
            )

            # Create a grid layout spanning two column and one row
            self.control_frame = ttk.LabelFrame(
                self, height=self.frame_height, width=self.frame_width, text="Processing Options"
            )
            self.control_frame.grid(padx=(20, 10), pady=(20, 10), row=0, column=1, rowspan=2, sticky="nsew")

            # Set the output image frame
            self.out_img_frame = build_frame(
                parent=self, height=self.frame_height, width=self.frame_width, text="Output Image", coords=(0, 1)
            )

        self.parent_frames = [self.in_img_frame, self.control_frame, self.out_img_frame]

    def create_widgets(self):
        # detection frame
        self.detect_frame = build_frame(
            parent=self.control_frame,
            height=int(self.control_frame.winfo_height() - 75),
            width=int(self.control_frame.winfo_width() / 2),
            text="Detection Options",
            coords=(0, 0),
        )
        self.detect_frame.grid_propagate(False)

        # Ternary TickBox stuff
        self.ternary = tk.BooleanVar()
        self.ternary_box = ttk.Checkbutton(self.detect_frame, text="Ternary / Barycentric", variable=self.ternary)
        self.ternary_box.grid(padx=(20, 10), pady=(20, 10), row=1, column=0)

        # Cutoff value label
        cutoff_value_lbl = ttk.Label(self.detect_frame, text="Binarisation Cutoff (0-255)")
        cutoff_value_lbl.grid(padx=5, pady=5, row=0, column=0)

        # Frame to hold entry and slider
        cutoff_container = ttk.Frame(self.detect_frame)
        cutoff_container.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        # Cutoff value entry
        self.cutoff_value_entry = ttk.Entry(cutoff_container, width=10)
        self.cutoff_value_entry.insert(0, "127")
        self.cutoff_value_entry.pack(side=tk.LEFT, padx=(0, 10))

        # Slider for cutoff value
        self.cutoff_slider = ttk.Scale(cutoff_container, from_=0, to=255, orient=tk.HORIZONTAL, length=200)
        self.cutoff_slider.set(127)
        self.cutoff_slider.pack(side=tk.LEFT)

        # Sync entry and slider
        self.cutoff_value_entry.bind("<FocusOut>", self.validate_and_sync)
        self.cutoff_slider.config(command=self.update_entry)
        ToolTip(
            self.cutoff_value_entry,
            msg="Enter an integer pixel value which is used as a cutoff on a greyscale: 0 <= x =< 255.",
            delay=0.5,
        )

        self.automate_cutoff = tk.BooleanVar()
        self.automate_cutoff_box = ttk.Checkbutton(
            self.detect_frame, text="Automate Cutoff", variable=self.automate_cutoff
        )
        self.automate_cutoff_box.grid(padx=(20, 10), pady=(20, 10), row=1, column=1)

        # detect Button
        self.detect_button = ttk.Button(self.detect_frame, text="Detect Graph", command=self.detect)
        ToolTip(
            self.detect_button,
            msg="Attempts to detect the graph by looking for an enlosed area with the correct shape, may fail if the "
            "area is not fully enclosed.",
            delay=0.5,
        )
        self.detect_button.grid(padx=(20, 10), pady=(20, 10), row=2, column=0, columnspan=2)

        # orientation options
        self.orientation_frame = build_frame(
            parent=self.control_frame,
            height=int(self.control_frame.winfo_height() / 2),
            width=int(self.control_frame.winfo_width() / 2) - 100,
            text="Image Orientation Options",
            coords=(0, 1),
        )
        self.detect_frame.grid_propagate(True)

        # First, configure the grid to make columns and rows expand equally
        self.orientation_frame.columnconfigure(0, weight=1)
        self.orientation_frame.columnconfigure(1, weight=1)
        self.orientation_frame.rowconfigure(0, weight=1)
        self.orientation_frame.rowconfigure(1, weight=1)
        self.orientation_frame.rowconfigure(2, weight=1)

        # Straighten Button
        self.straighten_button = ttk.Button(
            self.orientation_frame,
            text="Straighten",
            command=self.straighten,
            state=tk.DISABLED,
        )
        self.straighten_button.grid(padx=5, pady=10, row=0, column=0, sticky="")
        ToolTip(
            self.straighten_button,
            msg="Straightens the graph by rotating clockwise to move the detected corners onto a rectangle. This is "
            "not needed for barycentric graphs.",
            delay=0.5,
        )
        # rotate Button
        self.rotate_button = ttk.Button(
            self.orientation_frame, text="Rotate 90", command=self.rotate, state=tk.DISABLED
        )
        self.rotate_button.grid(padx=5, pady=10, row=0, column=1, sticky="")
        ToolTip(self.rotate_button, msg="Rotate the image clockwise by 90 degrees.", delay=0.5)
        # flip dimensions Button
        self.flip_button = ttk.Button(
            self.orientation_frame,
            text="Flip Dimensions",
            command=self.flip,
            state=tk.DISABLED,
        )
        ToolTip(
            self.flip_button, msg="Transforms the image pixels from the x onto the y axis and vice versa.", delay=0.5
        )
        self.flip_button.grid(padx=5, pady=10, row=1, column=0, sticky="")

        # Thicken Button
        self.thicken_button = ttk.Button(
            self.orientation_frame,
            text="Thicken Lines",
            command=self.thicken,
            state=tk.DISABLED,
        )
        ToolTip(self.thicken_button, msg="Thickens features consisting of black pixels.", delay=0.5)
        self.thicken_button.grid(padx=5, pady=10, row=1, column=1, sticky="")

        # Finish Button
        self.finish_button = ttk.Button(self.orientation_frame, text="Extract", command=self.finish, state=tk.DISABLED)
        ToolTip(
            self.finish_button,
            msg="Crops the output image to the graph content. Removes features outside the graph in the barycentric "
            "case.",
        )
        self.finish_button.grid(padx=5, pady=10, row=2, column=0, columnspan=2, sticky="")

        # exit Button
        self.cancel_button = ttk.Button(self.control_frame, text="Exit", command=self.exit_application)
        self.cancel_button.grid(padx=5, pady=5, row=2, column=0, sticky="nsew")

        # save & exit Button
        self.save_button = ttk.Button(self.control_frame, text="Save & Exit", command=self.save_exit_fun)
        self.save_button.grid(padx=5, pady=5, row=2, column=1, sticky="nsew")

        # Display Input Image
        self.resize_display(self.input_image_path, self.in_img_frame)

    def on_show_page(self):
        self.create_widgets()

    def validate_and_sync(self, event=None):
        """
        Validate entry and sync with slider
        """
        try:
            value = int(self.cutoff_value_entry.get())
            # Clamp value between 0 and 255
            value = max(0, min(value, 255))

            # Update entry and slider
            self.cutoff_value_entry.delete(0, tk.END)
            self.cutoff_value_entry.insert(0, str(value))
            self.cutoff_slider.set(value)
        except ValueError:
            # Reset to previous value if invalid
            self.cutoff_value_entry.delete(0, tk.END)
            self.cutoff_value_entry.insert(0, "127")
            self.cutoff_slider.set(127)

    def update_entry(self, value):
        """
        Update entry when slider moves
        """
        rounded = int(round(float(value)))
        self.cutoff_value_entry.delete(0, tk.END)
        self.cutoff_value_entry.insert(0, rounded)

    def resize_display(self, image_path: Path, image_widget: ttk.LabelFrame):
        image = Image.open(image_path)
        min_size = min(self.frame_width, self.frame_height)

        image.thumbnail((min_size, min_size))  # Resize image for display
        photo = ImageTk.PhotoImage(image)

        # Check if image label already exists inside the frame
        if not hasattr(image_widget, "image_label") or not image_widget.image_label.winfo_exists():
            image_widget.image_label = tk.Label(image_widget)
            image_widget.image_label.pack(expand=False)

        # Update image
        image_widget.image_label.configure(image=photo)
        image_widget.image_label.image = photo

    def threshold_image(self, image, threshold=None):
        if threshold is None:
            threshold = self.cutoff_value_entry.get()
            try:
                int(threshold)
            except Exception as e:
                print(f"Error in passing threshold value entry, not an int.\n{e}")
                return None

        if self.automate_cutoff:
            # Apply Otsu's thresholding
            _, out_image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        else:
            _, out_image = cv2.threshold(image, threshold, 255, cv2.THRESH_BINARY_INV)
        return out_image

    def thicken(self):
        output_image_path = self.data_dir.joinpath("preview", "extraction_preview.png")

        if output_image_path.is_file():
            # Read the output image
            output_image = cv2.imread(output_image_path, cv2.IMREAD_GRAYSCALE)

            # Threshold the image to create a binary image
            _, binary_image = cv2.threshold(output_image, 0, 255, cv2.THRESH_BINARY)

            # Define the structuring element for dilation
            kernel = np.ones((2, 2), np.uint8)

            # Apply dilation to thicken the black features
            thickened_image = cv2.erode(binary_image, kernel, iterations=1)

            # Save the thickened image
            thickened_image_path = self.data_dir.joinpath("preview", "extraction_preview.png")
            cv2.imwrite(thickened_image_path, thickened_image)

            # Update the GUI to display the thickened image
            self.resize_display(output_image_path, self.out_img_frame)
        else:
            messagebox.showwarning("Warning", "Output image not found.")

    def flip(self):
        output_image_path = self.data_dir.joinpath("preview", "extraction_preview.png")

        if output_image_path.is_file():
            # Read the output image
            output_image = cv2.imread(output_image_path)

            # Get the height and width of the image
            height, width = output_image.shape[:2]

            # Define the corner points of the original image
            src_pts = np.float32([[0, 0], [width - 1, 0], [0, height - 1], [width - 1, height - 1]])

            # Define the corner points of the transformed image (rotated by 90 degrees)
            dst_pts = np.float32([[width - 1, 0], [width - 1, height - 1], [0, 0], [0, height - 1]])

            # Calculate the perspective transform matrix
            M = cv2.getPerspectiveTransform(src_pts, dst_pts)

            # Apply the perspective transform to rotate the image
            rotated_image = cv2.warpPerspective(output_image, M, (width, height))

            # Save the result to the output image path
            cv2.imwrite(output_image_path, rotated_image)
            self.resize_display(output_image_path, self.out_img_frame)
        else:
            messagebox.showwarning("Warning", "Output image not found.")

    def rotate(self):
        # Load the image
        output_image_path = self.data_dir.joinpath("preview", "extraction_preview.png")

        if output_image_path.is_file():
            # Read the image
            output_image = cv2.imread(output_image_path, cv2.IMREAD_GRAYSCALE)

            # Rotate the image by 90 degrees counterclockwise
            rotated_image = cv2.rotate(output_image, cv2.ROTATE_90_COUNTERCLOCKWISE)
            _, rotated_image = cv2.threshold(rotated_image, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

            # Save the result to the output image path
            cv2.imwrite(output_image_path, rotated_image)
            self.resize_display(output_image_path, self.out_img_frame)
        else:
            messagebox.showwarning("Warning", "Output image not found.")

    def straighten(self):
        if self.ternary.get() is False or self.ternary.get() is None:
            # Update straightened flag
            self.is_straightened = True

            # Load the image
            output_image_path = self.data_dir.joinpath("preview", "extraction_preview.png")

            if output_image_path.is_file():
                # Read the output image
                output_image = cv2.imread(output_image_path, cv2.IMREAD_GRAYSCALE)

                # Find contours in the binary image
                contours, _ = cv2.findContours(output_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                if contours:
                    # Combine all contours into a single array
                    all_contours = np.concatenate(contours)

                    # Find the convex hull of all contours
                    hull = cv2.convexHull(all_contours)

                    # Approximate the convex hull to a polygon with 4 vertices
                    epsilon = 0.02 * cv2.arcLength(hull, True)
                    approx_poly = cv2.approxPolyDP(hull, epsilon, True)

                    # Ensure the polygon has exactly 4 vertices
                    if len(approx_poly) == 4:
                        # Extract the 4 corner points of the polygon
                        corner_points = np.float32(approx_poly[:, 0])

                        # Calculate the minimum and maximum x and y coordinates of the corner points
                        min_x = min(corner_points[:, 0])
                        max_x = max(corner_points[:, 0])
                        min_y = min(corner_points[:, 1])
                        max_y = max(corner_points[:, 1])

                        # Calculate the width and height of the bounding rectangle
                        bounding_width = int(max_x - min_x)
                        bounding_height = int(max_y - min_y)

                        # Calculate the aspect ratio of the original image
                        original_aspect_ratio = output_image.shape[1] / output_image.shape[0]

                        # Calculate the target width and height based on the aspect ratio
                        if bounding_width / bounding_height > original_aspect_ratio:
                            target_width = bounding_width
                            target_height = int(target_width / original_aspect_ratio)
                        else:
                            target_height = bounding_height
                            target_width = int(target_height * original_aspect_ratio)

                        # Define the target rectangle corners
                        target_corners = np.float32(
                            [
                                [0, 0],
                                [target_width - 1, 0],
                                [target_width - 1, target_height - 1],
                                [0, target_height - 1],
                            ]
                        )

                        # Calculate the perspective transform matrix
                        M = cv2.getPerspectiveTransform(corner_points, target_corners)

                        # Apply the perspective transform to extract the region of interest
                        roi = cv2.warpPerspective(output_image, M, (target_width, target_height))
                        _, roi = cv2.threshold(roi, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

                        # Save the result to the output image path
                        cv2.imwrite(output_image_path, roi)
                        self.resize_display(output_image_path, self.out_img_frame)

                        # Enable rotate and flip button
                        self.rotate_button.config(state=tk.NORMAL)
                        self.flip_button.config(state=tk.NORMAL)

                    else:
                        messagebox.showwarning(
                            "Warning",
                            "Could not approximate the convex hull to a polygon with 4 vertices.",
                        )
                else:
                    messagebox.showwarning("Warning", "No contours found in the binary image.")
            else:
                messagebox.showwarning("Warning", "Output image not found.")
        else:
            messagebox.showwarning("Warning", "Ternary diagrams cannot be straightened")

    def finish(self):
        if self.ternary.get() is False or self.ternary.get() is None:
            output_image_path = self.data_dir.joinpath("preview", "extraction_preview.png")

            if output_image_path.is_file():
                # Read the output image
                output_image = cv2.imread(output_image_path, cv2.IMREAD_GRAYSCALE)

                # Find the dimensions of the output image
                height, width = output_image.shape

                # Initialize variables to store the coordinates of the bounding box
                top_row, bottom_row, left_column, right_column = (
                    0,
                    height - 1,
                    0,
                    width - 1,
                )

                # Find the top row where at least 40% of pixels are white
                for i in range(height):
                    if np.count_nonzero(output_image[i, :]) >= 0.5 * width:
                        top_row = i
                        break

                # Find the bottom row where at least 40% of pixels are white
                for i in range(height - 1, -1, -1):
                    if np.count_nonzero(output_image[i, :]) >= 0.5 * width:
                        bottom_row = i
                        break

                # Find the leftmost column where at least 40% of pixels are white
                for j in range(width):
                    if np.count_nonzero(output_image[:, j]) >= 0.5 * height:
                        left_column = j
                        break

                # Find the rightmost column where at least 40% of pixels are white
                for j in range(width - 1, -1, -1):
                    if np.count_nonzero(output_image[:, j]) >= 0.5 * height:
                        right_column = j
                        break

                # Calculate the dimensions of the new image without black frame
                new_height = bottom_row - top_row + 1  # noqa
                new_width = right_column - left_column + 1  # noqa

                # Create the final output image without the black frame
                final_output_image = output_image[top_row : bottom_row + 1, left_column : right_column + 1]

                # Threshold the final output image to obtain a binary image
                _, binary_image = cv2.threshold(final_output_image, 127, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

                # Save the final output image as a binary image
                final_output_path = self.data_dir.joinpath("preview", "extraction_preview.png")
                cv2.imwrite(final_output_path, binary_image)
                self.resize_display(final_output_path, self.out_img_frame)
            else:
                messagebox.showwarning("Warning", "Output image not found.")
        else:
            # have to extract the ternary diagram
            output_image_path = self.data_dir.joinpath("preview", "extraction_preview.png")
            if output_image_path.is_file():
                # source to old image
                src_path = self.data_dir.joinpath("preview", "extraction_preview.png")

                # Destination file path (including new name)
                dest_path = self.data_dir.joinpath("preview", "preview.png")

                # Copy the file
                shutil.copy(src_path, dest_path)

                # New name for the file
                new_name = "preview.png"

                # Construct the new path
                new_path = dest_path.parent.joinpath(new_name)

                # Rename the file
                dest_path.rename(new_path)
                self.resize_display(new_path, self.out_img_frame)
            else:
                messagebox.showwarning("Warning", "Output image not found.")

    def save_exit_fun(self):
        self.destroy_widgets()
        try:
            output_image_path = self.data_dir.joinpath("preview", "extraction_preview.png")
            output_image = cv2.imread(output_image_path, cv2.IMREAD_GRAYSCALE)
            final_output_path = self.data_dir.joinpath("preview", "preview.png")
            cv2.imwrite(final_output_path, output_image)
        except Exception as e:
            print(f"Failed to save the output\n{e}")
        self.controller.show_page(get_settings().controller_page)

    def detect(self):
        if self.ternary.get() is False or self.ternary.get() is None:
            if self.input_image_path:
                # Read the input image
                input_image = cv2.imread(self.input_image_path)

                # Convert the image to grayscale
                gray_image = cv2.cvtColor(input_image, cv2.COLOR_BGR2GRAY)

                # Apply thresholding
                binary_image = self.threshold_image(gray_image)

                # Find contours in the binary image
                contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                # Find the largest contour (area-wise)
                largest_contour = max(contours, key=cv2.contourArea)

                # Create a mask for the largest contour
                mask = np.zeros_like(gray_image)
                cv2.drawContours(mask, [largest_contour], -1, 255, thickness=cv2.FILLED)

                # Set all pixels outside the largest contour to white
                output_image = np.zeros_like(gray_image)
                output_image[mask == 255] = gray_image[mask == 255]
                _, output_image = cv2.threshold(output_image, 127, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

                if output_image is not None:
                    # Save the output image in the "preview" folder
                    preview_folder = self.data_dir.joinpath("preview")
                    create_directory(preview_folder)
                    output_image_path = preview_folder.joinpath("extraction_preview.png")

                    cv2.imwrite(output_image_path, output_image)

                    # Update the GUI to display the output image
                    self.resize_display(output_image_path, self.out_img_frame)
                    self.straighten_button.config(state=tk.NORMAL)
                    self.finish_button.config(state=tk.NORMAL)
                    self.thicken_button.config(state=tk.NORMAL)
            else:
                messagebox.showwarning("Warning", "No input image selected.")
                # have to extract the ternary diagram
        else:
            output_image_path = self.data_dir.joinpath("preview", "preview.png")

            if output_image_path.is_file():
                # Read the output image
                image = cv2.imread(output_image_path, cv2.IMREAD_GRAYSCALE)

                # Threshold the image to get binary image
                binary = self.threshold_image(image)

                # Find contours
                contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                # Find the largest contour which should be the triangle
                triangle_contour = max(contours, key=cv2.contourArea)

                # Create a mask for the triangle
                mask = np.zeros_like(image)
                cv2.drawContours(mask, [triangle_contour], -1, (255), thickness=cv2.FILLED)

                # Extract the triangle region from the original image
                triangle_region = cv2.bitwise_and(image, image, mask=mask)

                # Create a new white image with the same size
                new_image = np.ones_like(image) * 255

                # Copy the contents of the triangle to the new image
                new_image[mask == 255] = triangle_region[mask == 255]
                _, new_image = cv2.threshold(new_image, 127, 255, cv2.THRESH_BINARY)
                # Save the output image in the "preview" folder
                preview_folder = self.data_dir.joinpath("preview")
                create_directory(preview_folder)
                output_image_path = preview_folder.joinpath("extraction_preview.png")

                cv2.imwrite(output_image_path, new_image)

                # Update the GUI to display the output image
                self.resize_display(output_image_path, self.out_img_frame)
                self.finish_button.config(state=tk.NORMAL)
