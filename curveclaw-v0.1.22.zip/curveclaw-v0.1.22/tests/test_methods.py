from pathlib import Path
from unittest.mock import patch

import pytest

from curveclaw.method_validation import (
    BinaryPhaseAssignInput,
    BinaryProbabilityInput,
    LineDataInput,
    TernaryPhaseAssignInput,
    TernaryProbabilityInput,
    process_input,
)
from curveclaw.methods.binary_phase_assign import assign_phases_fun
from curveclaw.methods.binary_probability import probability_fun as bin_probability_fun
from curveclaw.methods.line_data import write_to_file
from curveclaw.methods.ternary_phase_assign import area_assign_fun
from curveclaw.methods.ternary_probability import probability_fun as tern_probability_fun

from .utils import TestParent


class TestMethods(TestParent):
    @pytest.fixture(autouse=True)
    def data(self):
        self.filename = "test"
        self.axis_length = [(0, 100)] * 2
        self.step_size = [1] * 2
        self.log_scales = ["a"]
        self.binary_input_validator_data = {
            "filename": "output.txt",
            "log_scales": "",
            "axis_lengths": "(10,20)(30,40)",
            "step_size": "1,2",
            "extraction_mode": "Binary",
        }
        self.ternary_input_validator_data = {
            "filename": "output.txt",
            "log_scales": "",
            "axis_lengths": "(10,20)(30,40)(50,60)",
            "step_size": "1,2,3",
            "extraction_mode": "Ternary",
        }

    def test_binary_phase_assign(self):
        self.create_test_image(f"{self.expected_output_folder}/{self.filename}_out.png")
        assign_phases_fun(self.filename, self.axis_length, self.step_size, self.log_scales)

        # Verify that the expected image is generated
        assert Path(f"{self.expected_output_folder}/{self.filename}.png").exists()

    @patch("curveclaw.methods.binary_probability.min_dist_fun", return_value=None)
    def test_binary_probability(self, mock_min_dist_fun):
        self.create_test_image(f"{self.expected_output_folder}/{self.filename}_out.png")
        meta_data_file_path = Path(f"{self.expected_output_folder}/{self.filename}.txt")
        meta_data_file_path.write_text("test")

        bin_probability_fun(self.filename, self.axis_length, self.step_size, self.log_scales)

        # Verify that the expected images are generated
        assert Path(f"{self.expected_output_folder}/{self.filename}.png").exists()
        assert Path(f"{self.expected_output_folder}/area_1.png").exists()

    @patch("cv2.approxPolyDP", return_value=[[(1, 1)], [(2, 2)], [(3, 3)]])
    @patch("cv2.contourArea", return_value=1)
    @patch("cv2.findContours", return_value=([1], [1]))
    @patch("cv2.arcLength", return_value=1)
    def test_ternary_phase_assign(self, mock_arc_length, mock_find_contours, mock_contour_area, mock_approx_polydp):
        self.axis_length = [(0, 100)] * 3
        self.step_size = [1] * 3
        self.create_test_image(f"{self.expected_output_folder}/{self.filename}_out.png")

        area_assign_fun(self.filename, self.axis_length, self.step_size, self.log_scales)

        # Verify that the expected image and metadata file are generated
        assert Path(f"{self.expected_output_folder}/{self.filename}.png").exists()
        assert Path(f"{self.expected_output_folder}/{self.filename}.txt").exists()

    @patch("cv2.approxPolyDP", return_value=[[(1, 1)], [(2, 2)], [(3, 3)]])
    @patch("cv2.contourArea", return_value=1)
    @patch("cv2.findContours", return_value=([1], [1]))
    @patch("cv2.arcLength", return_value=1)
    @patch("numpy.hstack", return_value=[])
    def test_ternary_probability(
        self,
        mock_hstack,
        mock_arc_length,
        mock_find_contours,
        mock_contour_area,
        mock_approx_polydp,
    ):
        self.axis_length = [(0, 100)] * 3
        self.step_size = [1] * 3
        self.create_test_image(f"{self.expected_output_folder}/{self.filename}_out.png")
        meta_data_file_path = Path(f"{self.expected_output_folder}/{self.filename}.txt")
        meta_data_file_path.write_text("test")

        tern_probability_fun(self.filename, self.axis_length, self.step_size, self.log_scales)

        # Verify that the expected image is generated
        assert Path(f"{self.expected_output_folder}/{self.filename}.png").exists()

    def test_line_data(self):
        self.create_test_image(f"{self.expected_output_folder}/{self.filename}_out.png")
        write_to_file(self.filename, "test", "test")

        # Verify that the expected text files are generated
        assert Path(f"{self.expected_output_folder}/partial_curve_data_{self.filename}.txt").exists()
        assert Path(f"{self.expected_output_folder}/full_curve_data_{self.filename}.txt").exists()

    def test_valid_input_for_line_data_method(self):
        file1 = self.create_test_image(f"{self.filename}_1.png")
        file2 = self.create_test_image(f"{self.filename}_2.png")
        data = self.binary_input_validator_data
        data.update({"filepaths": [Path(file1), Path(file2)], "extraction_mode": "Line"})

        result = process_input(LineDataInput, data)
        assert result.get("filename") == "output.txt"
        assert result.get("axis_lengths") == [[10.0, 20.0], [30.0, 40.0]]
        assert result.get("step_size") == [1.0, 2.0]
        assert result.get("filepaths") == [file1, file2]

    def test_invalid_path_for_line_data_method(self):
        data = self.binary_input_validator_data
        data.update({"filepaths": [Path("I don't exist"), Path("I don't exist")], "extraction_mode": "Line"})

        result = process_input(LineDataInput, data)
        assert result.get("status") == "error"

    def test_invalid_mode_for_line_data_method(self):
        file1 = self.create_test_image(f"{self.filename}_1.png")
        file2 = self.create_test_image(f"{self.filename}_2.png")
        data = self.binary_input_validator_data
        data.update({"filepaths": [Path(file1), Path(file2)], "extraction_mode": "Not Line"})

        result = process_input(LineDataInput, data)
        assert result.get("status") == "error"

    def test_valid_input_for_binary_methods(self):
        data = self.binary_input_validator_data
        binary_methods = [BinaryPhaseAssignInput, BinaryProbabilityInput]

        for binary_method in binary_methods:
            result = process_input(binary_method, data)
            assert result.get("filename") == "output.txt"
            assert result.get("axis_lengths") == [[10.0, 20.0], [30.0, 40.0]]
            assert result.get("step_size") == [1.0, 2.0]

    # Invalid input for BinaryPhaseAssignInput (wrong count for axis lengths)
    def test_invalid_axis_length_for_binary_methods(self):
        data = self.binary_input_validator_data
        data["axis_lengths"] = "0"
        binary_methods = [BinaryPhaseAssignInput, BinaryProbabilityInput]

        for binary_method in binary_methods:
            result = process_input(binary_method, data)
            assert result.get("status") == "error"

    # Invalid input for BinaryPhaseAssignInput (wrong count for steps)
    def test_invalid_step_size_for_binary_methods(self):
        data = self.binary_input_validator_data
        data["step_size"] = "0"
        binary_methods = [BinaryPhaseAssignInput, BinaryProbabilityInput]

        for binary_method in binary_methods:
            result = process_input(binary_method, data)
            assert result.get("status") == "error"

    def test_invalid_mode_for_binary_methods(self):
        data = self.binary_input_validator_data
        data["extraction_mode"] = "Not Binary"
        binary_methods = [BinaryPhaseAssignInput, BinaryProbabilityInput]

        for binary_method in binary_methods:
            result = process_input(binary_method, data)
            assert result.get("status") == "error"

    def test_valid_input_for_ternary_methods(self):
        data = self.ternary_input_validator_data
        ternary_methods = [TernaryPhaseAssignInput, TernaryProbabilityInput]

        for ternary_method in ternary_methods:
            result = process_input(ternary_method, data)
            assert result.get("filename") == "output.txt"
            assert result.get("axis_lengths") == [[10.0, 20.0], [30.0, 40.0], [50.0, 60.0]]
            assert result.get("step_size") == [1.0, 2.0, 3.0]

    # Invalid input for TernaryPhaseAssignInput (wrong count for axis lengths)
    def test_invalid_axis_length_for_ternary_methods(self):
        data = self.ternary_input_validator_data
        data.update(
            {
                "axis_lengths": "(10,20)(30,40)",
            }
        )
        ternary_methods = [TernaryPhaseAssignInput, TernaryProbabilityInput]

        for ternary_method in ternary_methods:
            result = process_input(ternary_method, data)
            assert result.get("status") == "error"

    # Invalid input for TernaryPhaseAssignInput (wrong count for steps)
    def test_invalid_step_size_for_ternary_methods(self):
        data = self.ternary_input_validator_data
        data.update(
            {
                "step_size": "1,2",
            }
        )
        ternary_methods = [TernaryPhaseAssignInput, TernaryProbabilityInput]

        for ternary_method in ternary_methods:
            result = process_input(ternary_method, data)
            assert result.get("status") == "error"

    def test_invalid_mode_for_ternary_methods(self):
        data = self.ternary_input_validator_data
        data["extraction_mode"] = "Not Ternary"
        ternary_methods = [TernaryPhaseAssignInput, TernaryProbabilityInput]

        for ternary_method in ternary_methods:
            result = process_input(ternary_method, data)
            assert result.get("status") == "error"
