import tkinter as tk
from pathlib import Path
from tkinter import colorchooser, ttk

from PIL import Image, ImageDraw, ImageTk

from .base import BaseFrame
from .settings import get_settings
from .utils import build_frame

### COPYRIGHT ###
# 2-clause BSD License
# Copyright 2024 STFC
# Author: Dr. Felix Rummel

"""
COPYRIGHT
2-clause BSD License
Copyright 2024 STFC
Author: Dr. Felix Rummel
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


class PaintApp(BaseFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        self.output_path = self.controller.preview_image_path
        self.data_dir = Path(get_settings().data_dir)

        self.setup_ui()

    def setup_ui(self):
        self.canvas_width = (self.controller.width * 3 / 4) - 150
        self.frame_height = self.controller.height - 100
        # Create a frame for the canvas and scrollbars
        self.pic_frame = build_frame(self, width=self.canvas_width, height=self.frame_height, text="", coords=(0, 0))

        # Create a frame for buttons
        self.but_frame = build_frame(
            self, width=self.controller.width / 4, height=self.frame_height, text="Drawing Options", coords=(0, 1)
        )

        # Create horizontal and vertical scrollbars
        self.x_scrollbar = ttk.Scrollbar(self.pic_frame, orient=tk.HORIZONTAL)
        self.y_scrollbar = ttk.Scrollbar(self.pic_frame, orient=tk.VERTICAL)
        self.x_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        self.y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Create the canvas with scrollbars attached
        self.canvas = tk.Canvas(
            self.pic_frame,
            bg="white",
            xscrollcommand=self.x_scrollbar.set,
            yscrollcommand=self.y_scrollbar.set,
        )
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.x_scrollbar.config(command=self.canvas.xview)
        self.y_scrollbar.config(command=self.canvas.yview)

        self.parent_frames = [self.pic_frame, self.but_frame, self.x_scrollbar, self.y_scrollbar, self.canvas]

    def on_show_page(self, opt_args=None):
        # Load the image
        if opt_args is not None:
            self.image = Image.open(opt_args["input"])
            self.output_path = opt_args["output"]
            self.origin_pg = opt_args["origin"]
        else:
            self.image = Image.open(self.output_path)
            self.origin_pg = "controller"
        self.draw = ImageDraw.Draw(self.image)
        
        # Display the image on the canvas
        self.image_tk = ImageTk.PhotoImage(self.image)
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.image_tk)

        # Set the scroll region of the canvas
        self.canvas.config(scrollregion=self.canvas.bbox("all"), width=self.canvas_width)

        # Initialize zoom and pan parameters
        self.zoom_factor = 1.0
        self.offset_x = 0
        self.offset_y = 0

        self.lines = []  # Store drawn lines
        self.line_thickness = tk.IntVar(value=1)  # Default line thickness
        self.line_color = "black"  # Default line color
       
        self.setup_buttons()
        self.setup_bindings()
        
    def setup_buttons(self):
        self.thickness_label = ttk.Label(self.but_frame, text="Line Thickness:")
        self.thickness_label.grid(padx=(20, 10), pady=(20, 10), row=0, column=0)

        self.thickness_entry = ttk.Entry(self.but_frame, textvariable=self.line_thickness, width=5)
        self.thickness_entry.grid(padx=(20, 10), pady=(20, 10), row=0, column=1)

        self.color_button = ttk.Button(self.but_frame, text="Select Color", command=self.select_color)
        self.color_button.grid(padx=(20, 10), pady=(20, 10), row=1, column=0)

        self.undo_button = ttk.Button(self.but_frame, text="Undo", command=self.undo)
        self.undo_button.grid(padx=(20, 10), pady=(20, 10), row=1, column=1)

        self.save_button = ttk.Button(self.but_frame, text="Save Image", command=self.save_image)
        self.save_button.grid(padx=(20, 10), pady=(20, 10), row=2, column=0)

        self.exit_button = ttk.Button(self.but_frame, text="Exit", command=self.exit_application)
        self.exit_button.grid(padx=(20, 10), pady=(20, 10), row=2, column=1)

    def setup_bindings(self):
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_line)
        self.canvas.bind("<ButtonRelease-1>", self.stop_draw)

    def start_draw(self, event):
        # Adjust coordinates based on scroll position
        self.start_x = event.x + self.canvas.canvasx(0)
        self.start_y = event.y + self.canvas.canvasy(0)

    def draw_line(self, event):
        current_x = event.x + self.canvas.canvasx(0)
        current_y = event.y + self.canvas.canvasy(0)
        self.canvas.delete("line")  # Clear previous lines
        for line in self.lines:
            if len(line) == 3:  # Check if scroll positions are present
                line_coords, line_thickness, line_color = line
                scroll_x = scroll_y = 0  # Default scroll positions
            else:
                line_coords, line_thickness, line_color, scroll_x, scroll_y = line  # Unpack the scroll positions
            x1, y1, x2, y2 = line_coords
            # Adjust coordinates based on scroll position
            x1 += scroll_x
            y1 += scroll_y
            x2 += scroll_x
            y2 += scroll_y
            self.canvas.create_line(x1, y1, x2, y2, fill=line_color, width=line_thickness, tags="line")
        self.canvas.create_line(
            self.start_x,
            self.start_y,
            current_x,
            current_y,
            fill=self.line_color,
            width=self.line_thickness.get(),
            tags="line",
        )

    def stop_draw(self, event):
        current_x = event.x + self.canvas.canvasx(0)
        current_y = event.y + self.canvas.canvasy(0)
        line_coords = (self.start_x, self.start_y, current_x, current_y)
        if self.x_scrollbar.get() and self.y_scrollbar.get():  # Check if scrollbars are present
            scroll_x = self.canvas.xview()[0]
            scroll_y = self.canvas.yview()[0]
        else:
            scroll_x = scroll_y = 0  # Default scroll positions
        self.lines.append(
            (
                line_coords,
                self.line_thickness.get(),
                self.line_color,
                scroll_x,
                scroll_y,
            )
        )

    def undo(self):
        if self.lines:
            self.lines.pop()  # Remove the last drawn line
            self.refresh_canvas()

    def save_image(self):
        filename = self.data_dir.joinpath(self.output_path)
        # Create a copy of the original image
        modified_image = self.image.copy()
        draw = ImageDraw.Draw(modified_image)
        # Draw all the lines stored in self.lines
        for line in self.lines:
            if len(line) == 3:  # Check if scroll positions are present
                line_coords, line_thickness, line_color = line
                scroll_x = scroll_y = 0  # Default scroll positions
            else:
                line_coords, line_thickness, line_color, scroll_x, scroll_y = line  # Unpack the scroll positions
            x1, y1, x2, y2 = line_coords
            # Adjust coordinates based on scroll position
            x1 -= scroll_x
            y1 -= scroll_y
            x2 -= scroll_x
            y2 -= scroll_y
            draw.line([(x1, y1), (x2, y2)], fill=line_color, width=line_thickness)
        # Save the modified image

        modified_image.save(filename)

    def refresh_canvas(self):
        self.canvas.delete("line")
        for line in self.lines:
            if len(line) == 3:  # Check if scroll positions are present
                line_coords, line_thickness, line_color = line
                scroll_x = scroll_y = 0  # Default scroll positions
            else:
                line_coords, line_thickness, line_color, scroll_x, scroll_y = line  # Unpack the scroll positions
            x1, y1, x2, y2 = line_coords
            # Adjust coordinates based on scroll position
            x1 -= scroll_x
            y1 -= scroll_y
            x2 -= scroll_x
            y2 -= scroll_y
            self.canvas.create_line(x1, y1, x2, y2, fill=line_color, width=line_thickness, tags="line")

    def select_color(self):
        color = colorchooser.askcolor(title="Choose Color", initialcolor=self.line_color)[1]
        if color:
            self.line_color = color
