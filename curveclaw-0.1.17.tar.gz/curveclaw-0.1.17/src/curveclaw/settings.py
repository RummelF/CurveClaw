from functools import cache

from appdirs import user_data_dir
from pydantic_settings import BaseSettings

from .utils import package

# Rich style tags
VAR_COLOR = "[bright_yellow]"  # For variable values, like numbers or inputs
MSG_COLOR = "[bold cyan]"  # For general labels and messages
FILE_COLOR = "[bright_green]"  # For file/folder paths or names
WARN_COLOR = "[bold red]"  # For warnings or errors
RESET = "[/]"  # Ends styling


class Settings(BaseSettings):
    data_dir: str = user_data_dir(appname=package(), appauthor="Felix")

    # Define each page name as a separate attribute
    draw_lines_page: str = "PaintApp"
    extract_graph_page: str = "FigureExtractionApp"
    image_cleaner_page: str = "AutoCleaner"
    hash_connector_page: str = "HashCon"
    curve_claw_page: str = "CurveSelection"
    data_extraction_page: str = "DataExtractor"
    controller_page: str = "Controller"


@cache
def get_settings():
    return Settings()  # type: ignore
