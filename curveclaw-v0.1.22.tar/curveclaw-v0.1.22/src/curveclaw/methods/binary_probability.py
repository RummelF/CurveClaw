from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from rich import print as pprint
from rich.progress import track
from scipy.ndimage import label

from curveclaw.methods.utils import (
    create_binary_image_from_array,
    dist_to_prob_fun,
    interpret_string,
    prob_to_dist_fun,
)
from curveclaw.settings import FILE_COLOR, MSG_COLOR, RESET, VAR_COLOR, get_settings
from curveclaw.utils import delete_files

### COPYRIGHT ###
# 2-clause BSD License
# Copyright 2024 STFC
# Author: Dr. Felix Rummel

"""
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


#########################################################
##MAIN SCRIPT INITILISATION
#########################################################

# Define the cutoff value for probability
truncate = 1e-3


def probability_fun(filename, axis_lengths, step_size, log_scales):
    # Get the directory of the current script
    current_dir = Path(get_settings().data_dir)

    # Go one directory back and specify the 'output' folder
    output_dir = current_dir.joinpath("output")

    # Load the input image as a black and white array
    input_array = np.asarray(Image.open(output_dir.joinpath(f"{filename}_out.png")).convert("L"))

    # Get the size of the image
    rows, columns = input_array.shape
    min_x, max_x = axis_lengths[0]
    min_y, max_y = axis_lengths[1]
    # print(f"min, max x: ({min_x},{max_x}) y: ({min_y},{max_y})")

    # Determine which axis are log scales
    axis_log = [False, False]  # x scale and y scale log scale
    for idx, item in enumerate(log_scales):
        if idx < 2:
            if interpret_string(item) is True:
                axis_log[idx] = True

    # Generate coordinates
    if axis_log[0] is True or axis_log[1] is True:  # Check if either axis is log scale
        if axis_log[0] is True and axis_log[1] is True:
            # Both axes are log scale
            if min_x == 0:
                min_x = 1e-10
            if min_y == 0:
                min_y = 1e-10
            x = np.logspace(np.log10(min_x), np.log10(max_x), int(step_size[0]))
            y = np.logspace(np.log10(min_y), np.log10(max_y), int(step_size[1]))
        elif axis_log[0] is True and axis_log[1] is False:
            # Only x-axis is log scale
            if min_x == 0:
                min_x = 1e-10
            x = np.logspace(np.log10(min_x), np.log10(max_x), int(step_size[0]))
            y = np.linspace(min_y, max_y, int(step_size[1]))
        elif axis_log[1] is True and axis_log[0] is False:
            # Only y-axis is log scale
            if min_y == 0:
                min_y = 1e-10
            x = np.linspace(min_x, max_x, int(step_size[0]))
            y = np.logspace(np.log10(min_y), np.log10(max_y), int(step_size[1]))
    else:
        # No log scales
        x = np.linspace(min_x, max_x, int(step_size[0]))
        y = np.linspace(min_y, max_y, int(step_size[1]))

    # Generate meshgrid
    X, Y = np.meshgrid(x, y)

    # Reshape the grid to obtain Points
    Points = np.column_stack((X.ravel(), Y.ravel()))

    # Convert to list of tuples
    coordinate_list = [tuple(point) for point in Points]

    # create the pixel coordinates of test points
    x_s, y_s = np.meshgrid(
        np.linspace(0, columns - 1, int(step_size[0])),
        np.linspace(rows - 1, 0, int(step_size[1])),
    )

    # Reshape the grid to obtain Points scaled to the image
    Points = np.column_stack((x_s.ravel(), y_s.ravel()))

    # Convert to list of tuples
    scaled_coordinate_list = [tuple(point) for point in Points]
    pprint(f"{MSG_COLOR}Created coordinate grids{RESET}")

    # Label the image
    labeled_array, num_labels = label(input_array)

    # Create an array to store the distance to each phase
    distances = np.zeros((len(coordinate_list), num_labels))

    coord_count = 0
    # determine maximum to consider
    max_distance = prob_to_dist_fun(truncate)  # *4
    yRatio = labeled_array.shape[0] / abs(axis_lengths[1][1] - axis_lengths[1][0])
    xRatio = labeled_array.shape[1] / abs(axis_lengths[0][1] - axis_lengths[0][0])
    di = min(int(yRatio * max_distance + 1), labeled_array.shape[0])
    dj = min(int(xRatio * max_distance + 1), labeled_array.shape[1])

    # Determine pixel scale
    yRatio = labeled_array.shape[0] / abs(axis_lengths[1][1] - axis_lengths[1][0])
    xRatio = labeled_array.shape[1] / abs(axis_lengths[0][1] - axis_lengths[0][0])

    # Iterate through the array to obtain the distance of each point to each phase
    for coord_count, coord in enumerate(track(scaled_coordinate_list, description="Calculating distances")):
        if coord_count % 1000 == 0:  # Print progress every 1000 iterations
            pprint(f"Iteration {coord_count + 1} out of {len(scaled_coordinate_list)} coordinates")

        col = int(coord[0])
        row = int(coord[1])
        row_range = (max(0, row - di), min(labeled_array.shape[0], row + di))
        col_range = (max(0, col - dj), min(labeled_array.shape[1], col + dj))

        # create a new array
        new_array = labeled_array[row_range[0] : row_range[1] + 1, col_range[0] : col_range[1] + 1]
        new_row = row - row_range[0]
        new_col = col - col_range[0]

        # print(f"max distance: {max_distance}, di={di}, dj={dj}", row_range, col_range)
        for phs in range(num_labels):
            md = min_dist_fun(new_array, axis_lengths, new_col, new_row, phs + 1, max_distance, (xRatio, yRatio))
            distances[coord_count, phs] = md

    pprint(f"{MSG_COLOR}Created distance matrix{RESET}")

    # Create an array to store the probability to each phase
    probabilities = np.zeros((len(coordinate_list), num_labels))
    # Iterate through the array to obtain the probability of each point to be in a phase
    for c_idx, coord in enumerate(scaled_coordinate_list):
        for phs in range(num_labels):
            prob = dist_to_prob_fun(distances[c_idx, phs])
            if prob < truncate:  # Check the threshold
                probabilities[c_idx, phs] = 0
            else:
                probabilities[c_idx, phs] = prob
    pprint(f"{MSG_COLOR}Created probability matrix{RESET}")

    # Normalising each row to 1
    for i in range(probabilities.shape[0]):
        S = np.sum(probabilities[i, :])
        N = 1 / S
        for j in range(probabilities.shape[1]):
            probabilities[i, j] = round(probabilities[i, j] * N, 4)
    pprint(f"{MSG_COLOR}Normalized output{RESET}")

    # Create the name array
    name_array = np.full((probabilities.shape[0], 1), filename)
    # Create temp comp array
    coords = [tuple((item[0], item[1])) for item in coordinate_list]
    combined_array = np.hstack((name_array, np.array(coords)))

    # Combine point and Probability array
    combined_array = np.hstack((combined_array, probabilities))

    # List of headers for each column
    headers = ["surfactant", "X_axis", "Y_axis"]
    for col in range(probabilities.shape[1]):
        headers.append(f"area_{col + 1}")
    headers.append(" ")

    # Delete previous phase pictures
    delete_files(output_dir, ["area_*.png"])

    # Save the output
    out_name = filename + ".txt"
    comment_text = (
        f"#Name of original image: {filename} \n"
        f"#X axis defined as: {min_x} to {max_x} \n"
        f"#Y axis defined as: {min_y} to {max_y} \n"
        f"#X grid set to: {step_size[0]} \n"
        f"#Y grid set to: {step_size[1]} \n"
        f"#X axis log property is: {axis_log[0]} \n"
        f"#Y axis log property is: {axis_log[1]} \n"
    )
    np.savetxt(
        output_dir.joinpath(out_name),
        combined_array,
        fmt="%s",
        delimiter=" ",
        header=" ".join(headers),
        comments=comment_text,
    )
    pprint(f"{MSG_COLOR}Finished extraction, output saved in output folder as:{RESET} {FILE_COLOR}{out_name}{RESET}")

    # Visualise
    radius = min((labeled_array.shape[0] / (2 * step_size[1]) + labeled_array.shape[1] / (2 * step_size[0])) / 2, 2)
    visualise(probabilities, scaled_coordinate_list, rows, columns, radius, output_dir)

    # Create an image with the labeled areas and also save it.

    create_binary_image_from_array(labeled_array, output_dir.joinpath(f"{filename}.png"))


def visualise(probabilities, coord, rows, columns, radius, output_dir):
    def value_to_color(value):
        if np.isnan(value):
            return (0, 0, 0)  # Default to black for NaN values
        # Interpolate between red (255, 0, 0) and blue (0, 0, 255) based on the input value
        r = int(value * 255)  # Red component decreases as value increases
        b = int((1 - value) * 255)  # Blue component increases as value increases
        return (r, 0, b)  # Green component is kept at 0 to maintain the red/blue scale

    # Plot the probability heatmaps of each phase.
    for phs in range(probabilities.shape[1]):
        phs_array = Image.new("RGB", (columns + 1, rows + 1), (255, 255, 255))
        draw = ImageDraw.Draw(phs_array)  # Create a drawing object
        for idx in range(probabilities.shape[0]):
            col = int(coord[idx][0])
            row = int(coord[idx][1])

            if 0 <= col <= columns and 0 <= row <= rows:
                colour = value_to_color(probabilities[idx][phs])

                # Draw a filled circle
                left_up_point = (col - radius, row - radius)
                right_down_point = (col + radius, row + radius)
                draw.ellipse([left_up_point, right_down_point], fill=colour)
            else:
                pprint(
                    f"{MSG_COLOR}Skipping pixel at{RESET} "
                    f"({VAR_COLOR}{col}{RESET}, {VAR_COLOR}{row}{RESET}) "
                    f"{MSG_COLOR}- out of bounds{RESET}"
                )

        # Save the image in the output path
        save_path = f"{output_dir}/area_{phs + 1}.png"
        phs_array.save(save_path)
        pprint(f"{MSG_COLOR}Image saved to{RESET} {FILE_COLOR}{save_path}{RESET}")


def min_dist_fun(bwLIm, Scales, x_p, y_p, phase, max_distance, pixel_scale):
    # bwLIm should be the bw labeled image, Scales should be in form [min_x
    # max_x min_y max_y], point the (x,y)of the test point and phase the
    # target phase. Will calculate the min distance between test point and
    # target phase

    # Find coordinates of all pixels that match the target phase
    target_indices = np.argwhere(bwLIm == phase)

    if target_indices.size == 0:
        # If no matching pixels are found, return a very large number
        return 1e20

    # Compute the distance from (x_p, y_p) to each target pixel
    y_coords = target_indices[:, 0]
    x_coords = target_indices[:, 1]

    y_diffs = (y_coords - y_p) / pixel_scale[1]
    x_diffs = (x_coords - x_p) / pixel_scale[0]

    distances = np.sqrt(y_diffs**2 + x_diffs**2)

    # Return the minimum distance
    min_distance = np.min(distances)

    return min_distance
