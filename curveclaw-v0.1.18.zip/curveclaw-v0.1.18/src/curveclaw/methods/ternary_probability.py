import math
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw
from rich import print as pprint
from rich.progress import track
from scipy.ndimage import label

from curveclaw.methods.utils import (
    bary_to_cart,
    bary_to_real,
    create_ternary_image_from_array,
    dist_to_prob_fun,
    find_closest_nonzero_pixel,
    interpret_string,
    prob_to_dist_fun,
)
from curveclaw.settings import FILE_COLOR, MSG_COLOR, RESET, VAR_COLOR, WARN_COLOR, get_settings
from curveclaw.utils import delete_files, logger

### COPYRIGHT ###
# 2-clause BSD License
# Copyright 2024 STFC
# Author: Dr. Felix Rummel

"""
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


#########################################################
##MAIN SCRIPT INITILISATION
#########################################################

# Define the cutoff value for probability
truncate = 1e-3


def probability_fun(filename, axis_lengths, step_size, log_scales):
    # Get the directory of the current script
    current_dir = Path(get_settings().data_dir)

    # Go one directory back and specify the 'output' folder
    output_dir = current_dir.joinpath("output")

    # Load the input image as a black and white array
    input_array = np.asarray(Image.open(output_dir.joinpath(f"{filename}_out.png")).convert("L"))

    # Label the image
    labeled_array, num_labels = label(input_array)

    # Get the size of the image
    rows, columns = input_array.shape

    # Determine which axis are log scales
    axis_log = [False, False, False]  # x scale y and z scale log scale
    for idx, item in enumerate(log_scales):
        if idx < 3:
            if interpret_string(item) is True:
                axis_log[idx] = True

    # Locate the corners of the triangle
    # Load black and white image
    bw_image = cv2.imread(output_dir.joinpath(f"{filename}_out.png"), cv2.IMREAD_GRAYSCALE)

    # Invert the image if the triangle is black on a white background
    inverted_image = cv2.bitwise_not(bw_image)

    # Ensure the image is binary (black and white)
    _, binary_image = cv2.threshold(inverted_image, 127, 255, cv2.THRESH_BINARY)

    # Find contours of shapes in the binary image
    contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Filter out the largest triangle based on its shape
    largest_triangle = None
    largest_area = 0
    for contour in contours:
        perimeter = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.04 * perimeter, True)  # Approximate the polygon

        if len(approx) == 3:  # Check if the contour is a triangle
            area = cv2.contourArea(contour)
            if area > largest_area:  # Find the largest triangle by area
                largest_triangle = approx
                largest_area = area

    # Check if a triangle was found
    if largest_triangle is not None:
        corners = []
        labels = ["X", "Y", "Z"]

        # Create a copy of the original image to overlay the points
        image_with_points = cv2.cvtColor(bw_image, cv2.COLOR_GRAY2BGR)  # noqa

        # Save the vertices of the triangles
        for idx, vertex in enumerate(largest_triangle):
            x, y = vertex[0]
            corners.append((labels[idx], (x, y)))

        # Define the corners
        A = np.array([corners[0][1][0], corners[0][1][1]])
        B = np.array([corners[1][1][0], corners[1][1][1]])
        C = np.array([corners[2][1][0], corners[2][1][1]])
        pprint(f"""{MSG_COLOR}Triangle located with the corners:{RESET}
        {VAR_COLOR}A:{RESET} {corners[0][1][0]}, {corners[0][1][1]}
        {VAR_COLOR}B:{RESET} {corners[1][1][0]}, {corners[1][1][1]}
        {VAR_COLOR}C:{RESET} {corners[2][1][0]}, {corners[2][1][1]}
        """)

        # Area of the tenary diagram
        area_ABC = area_of_triangle(A, B, C)

        # Create the test points in barycentric space
        a_linspace = np.linspace(1, 0, int(step_size[0]))  # start close to A and move to C
        b_linspace = np.linspace(1, 0, int(step_size[1]))  # start close to B and move to A
        c_linspace = np.linspace(1, 0, int(step_size[2]))  # start close to C and move to B

        a, b, c = np.meshgrid(a_linspace, b_linspace, c_linspace)
        test_points = np.column_stack((a.ravel(), b.ravel(), c.ravel()))
        # keep only points where alpha + beta + gamme = 1
        test_points = [
            [round(point[0], 4), round(point[1], 4), round(point[2], 4)]
            for point in test_points
            if round(sum(point), 3) == 1
        ]

        bary_coords = np.empty(labeled_array.shape, dtype=object)
        real_coords = np.empty(labeled_array.shape, dtype=object)
        # Create the array of the image in barycentric space and an array for the values of A,B and C for these
        for y in range(labeled_array.shape[0]):
            for x in range(labeled_array.shape[1]):
                # If the pixel is in barycentric space
                if labeled_array[y, x] > 1:
                    bary = cart_to_bary(A, B, C, (x, y), area_ABC)
                    bary_coords[y, x] = bary
                    real_coords[y, x] = bary_to_real(bary, axis_lengths, axis_log)
                else:
                    bary_coords[y, x] = None
                    real_coords[y, x] = None
        pprint(f"{MSG_COLOR}Created all barycentric coordinates{RESET}")

        # detemine the maximum change in rows and cols position to obtain a vaild probability
        max_d = prob_to_dist_fun(truncate)
        max_b = max([max_d/abs(axis_lengths[i][1]-axis_lengths[i][0]) for i in [0,1,2]])
        #max_b = max_b / 2**0.5
        # test AB, AC and BC for largest change in i and j
        di = []
        dj = []
        # AB
        p1 = bary_to_cart(A, B, C, 1, 0, 0)
        p2 = bary_to_cart(A, B, C, 1-max_b, max_b, 0)
        di.append(abs(p1[1]-p2[1]))
        dj.append(abs(p1[0]-p2[0]))
        # AC
        p1 = bary_to_cart(A, B, C, 1, 0, 0)
        p2 = bary_to_cart(A, B, C, 1-max_b, 0, max_b)
        di.append(abs(p1[1]-p2[1]))
        dj.append(abs(p1[0]-p2[0]))
        # BC
        p1 = bary_to_cart(A, B, C, 0, 1, 0)
        p2 = bary_to_cart(A, B, C, 0, 1-max_b, max_b)
        di.append(abs(p1[1]-p2[1]))
        dj.append(abs(p1[0]-p2[0]))
        # maximum change in rows and cols
        di = max(di)+1
        dj = max(dj)+1
        if di > rows:
            di = rows
        if dj > columns:
            dj = columns
        pprint(f"""{MSG_COLOR}Determined max distance: {VAR_COLOR}{round(max_d,2)}{RESET}
        Determined the maxiumum axis fraction as: {round(max_b,2)}
        giving di={VAR_COLOR}{di}{RESET} and dj={VAR_COLOR}{dj}{RESET}
        """)

        # Create a matrix containing distance information for each test_points coordinate
        (_, distances) = distance_matrix(
            test_points,
            labeled_array,
            num_labels,
            bary_coords,
            real_coords,
            axis_lengths,
            axis_log,
            A,
            B,
            C,
            di,
            dj
        )
        pprint(f"{MSG_COLOR}Created distance matrix{RESET}")

        # Create an array to store the probability to each phase
        probabilities = np.zeros((len(distances), num_labels - 1))
        # Iterate through the array to obtain the probability of each point to be in a phase
        for idx_1, d_vec in enumerate(distances):
            for idx_2, entry in enumerate(d_vec):
                prob = dist_to_prob_fun(entry)
                if prob < truncate:  # Check the threshold
                    probabilities[idx_1, idx_2] = 0
                else:
                    probabilities[idx_1, idx_2] = prob

        pprint(f"{MSG_COLOR}Created probability matrix{RESET}")

        # Normalising each row to 1
        for i in range(probabilities.shape[0]):
            S = np.sum(probabilities[i, :])
            N = 1 / S
            for j in range(probabilities.shape[1]):
                probabilities[i, j] = round(probabilities[i, j] * N, 4)
        pprint(f"{MSG_COLOR}Normalised output{RESET}")

        # Create the name array
        name_array = np.full((probabilities.shape[0], 1), filename)

        coords = [  # noqa
            tuple((item[0], item[1], item[2])) for item in test_points
        ]  # add coordinates in that order

        real_coords = [bary_to_real(item, axis_lengths, axis_log) for item in test_points]
        real_coords = [tuple((round(item[0],2), round(item[1],2), round(item[2],2))) for item in real_coords]

        combined_array = np.hstack((name_array, np.array(real_coords)))

        # Combine point and Probability array
        combined_array = np.hstack((combined_array, probabilities))

        # List of headers for each column
        headers = ["surfactant", "X", "Y", "Z"]
        for col in range(probabilities.shape[1]):
            headers.append(f"Area_{col + 1}")
        headers.append(" ")

        # Delete previous phase pictures
        delete_files(output_dir, ["area_*.png"])

        # Save the output
        out_name = filename + ".txt"
        comment_text = (
            f"#Name of original image: {filename} \n"
            f"#X axis defined as: {axis_lengths[0][0]} to {axis_lengths[0][1]} \n"
            f"#Y axis defined as: {axis_lengths[1][0]} to {axis_lengths[1][1]} \n"
            f"#Z axis defined as: {axis_lengths[2][0]} to {axis_lengths[2][1]} \n"
            f"#X grid set to: {step_size[0]} \n"
            f"#Y grid set to: {step_size[1]} \n"
            f"#Z grid set to: {step_size[2]} \n"
            f"#X axis log property is: {axis_log[0]} \n"
            f"#Y axis log property is: {axis_log[1]} \n"
            f"#Z axis log property is: {axis_log[2]} \n"
            f"#Triangle corners A, B, C found at [row, col] {A}, {B}, {C} \n"
        )
        np.savetxt(
            output_dir.joinpath(out_name),
            combined_array,
            fmt="%s",
            delimiter=" ",
            header=" ".join(headers),
            comments=comment_text,
        )
        pprint(
            f"{MSG_COLOR}Finished extraction, output saved in output folder as:{RESET} {FILE_COLOR}{out_name}{RESET}"
        )

        # Visualise
        # Calculate intermediate values
        shape_ratio = ((labeled_array.shape[0] + labeled_array.shape[1]) / (2 * sum(step_size) / 3)) / 2
        min_radius = min(shape_ratio, 10)  # Cap the value at 10
        radius = min_radius / 4  # Final radius calculation
        visualise(probabilities, test_points, labeled_array, A, B, C, radius, output_dir)

        # Create an image with the labeled areas and also save it.
        create_ternary_image_from_array(labeled_array, output_dir.joinpath(f"{filename}.png"), A, B, C)
    else:
        pprint(f"{WARN_COLOR}No triangle found in the image.{RESET}")


def visualise(probabilities, test_points, labeled_array, A, B, C, radius, output_dir):
    def value_to_color(value):
        if np.isnan(value):
            return (0, 0, 0)  # Default to black for NaN values
        # Interpolate between red (255, 0, 0) and blue (0, 0, 255) based on the input value
        r = int(value * 255)  # Red component decreases as value increases
        b = int((1 - value) * 255)  # Blue component increases as value increases
        return (r, 0, b)  # Green component is kept at 0 to maintain the red/blue scale

    # Plot the probability heatmaps of each phase.
    for phs in range(probabilities.shape[1]):
        phs_array = Image.new("RGB", (labeled_array.shape[1], labeled_array.shape[0]), (255, 255, 255))
        draw = ImageDraw.Draw(phs_array)  # Create a drawing object
        for idx, (alpha, beta, gamma) in enumerate(test_points):
            (col, row) = bary_to_cart(A, B, C, alpha, beta, gamma)

            if 0 <= col <= labeled_array.shape[1] and 0 <= row <= labeled_array.shape[0]:
                colour = value_to_color(probabilities[idx][phs])

                # Draw a filled circle
                left_up_point = (col - radius * 5, row - radius * 5)
                right_down_point = (col + radius * 5, row + radius * 5)
                draw.ellipse([left_up_point, right_down_point], fill=colour)
            else:
                pprint(f"{WARN_COLOR}Skipping pixel at ({col}, {row}) - out of bounds{RESET}")
        # Save the image in the output path
        save_path = f"{output_dir}/area_{phs + 1}.png"
        phs_array.save(save_path)
        pprint(f"{MSG_COLOR}Image saved to:{RESET} {FILE_COLOR}{save_path}{RESET}")


def real_distance(p1, p2):
    return math.sqrt((p2[0] - p1[0]) ** 2 + (p2[1] - p1[1]) ** 2 + (p2[2] - p1[2]) ** 2)


def area_of_triangle(A, B, C):
    # calculates the area of a triangle defined by its corners A-C which are an array with the x and y coordinate
    return 0.5 * abs(A[0] * (B[1] - C[1]) + B[0] * (C[1] - A[1]) + C[0] * (A[1] - B[1]))


def cart_to_bary(A, B, C, P, area_ABC):
    # Calculate sub triangles
    area_PBC = area_of_triangle(P, B, C)
    area_APC = area_of_triangle(A, P, C)
    area_ABP = area_of_triangle(A, B, P)
    # Calculate barycentric coordinates
    alpha = area_PBC / area_ABC
    beta = area_APC / area_ABC
    gamma = area_ABP / area_ABC
    # Assume this is always in the triangle ABC therefore normalise
    sum_coords = alpha + beta + gamma
    if sum_coords != 0:  # Prevent division by zero
        alpha /= sum_coords
        beta /= sum_coords
        gamma /= sum_coords
    if not abs(alpha + beta + gamma - 1) < 1e-6:
        return None
    else:
        return [alpha, beta, gamma]


def distance_matrix(
    test_points,
    labeled_array,
    num_labels,
    bary_coords,
    real_coords,
    axis_lengths,
    axis_log,
    A,
    B,
    C,
    di,
    dj
):
    area_ABC = area_of_triangle(A, B, C)
    points = []  # store the real coordinates of valid test points
    # Create the matrix to hold all distances
    distances = np.zeros((len(test_points), num_labels - 1))

    for idx, (alpha, beta, gamma) in track(
        enumerate(test_points),
        description=f"{MSG_COLOR}Processing barycentric points...{RESET}",
        total=len(test_points),
    ):
        if idx % 1000 == 0:  # Print every 1000 iterations
            pprint(f"{MSG_COLOR}Iteration {VAR_COLOR}{idx + 1}{RESET} / {VAR_COLOR}{len(test_points)}{RESET}")

        # Determine the col and row of the current point
        (col, row) = bary_to_cart(A, B, C, alpha, beta, gamma)

        # If no real coordinate exists, find the closest non-zero pixel and update
        if real_coords[row, col] is None:
            (row_n, col_n) = find_closest_nonzero_pixel(labeled_array, row, col)

            # Calculate barycentric coordinates for the closest non-zero pixel
            bary = cart_to_bary(A, B, C, (col_n, row_n), area_ABC)
            bary_coords[row, col] = bary
            real_coords[row, col] = bary_to_real(bary, axis_lengths, axis_log)

        logger.debug(f"Point {alpha}, {beta}, {gamma} is located at pixel col: {col}, row: {row}")
        logger.debug(f"Area is {labeled_array[row, col]}")

        points.append(real_coords[row, col])
        # create a partial array to search
        row_range = (max(0, row - di), min(labeled_array.shape[0], row + di))
        col_range = (max(0, col - dj), min(labeled_array.shape[1], col + dj))
        new_array= labeled_array[row_range[0]:row_range[1]+1, col_range[0]:col_range[1]+1]

        for phs in range(1, num_labels):
            target_indices = np.argwhere(new_array == (phs + 1))
            if target_indices.size == 0:
                # If no matching pixels are found, return a very large number
                md = 1e20
            else:
                p1 = real_coords[row, col]
                d = np.zeros((len(target_indices), 1))
                for x, ind in enumerate(target_indices):
                    p2 = real_coords[ind[0] + row_range[0], ind[1] + col_range[0]]
                    if p2 is not None:
                        d[x] = real_distance(p1, p2)
                    else:
                        d[x] = 1e20
                md = np.min(d)
            logger.debug(f"Minimum distance to phase {phs - 1} is {md}")

            distances[idx, phs - 1] = md
    return points, distances
