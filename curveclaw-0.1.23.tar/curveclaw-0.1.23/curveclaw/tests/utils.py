import tempfile
from tkinter import Tk
from unittest.mock import patch

import pytest
from PIL import Image, ImageDraw

from curveclaw.curveclaw import CurveClaw
from curveclaw.settings import get_settings


class TestParent:
    def create_test_image(self, path: str, rgb: tuple[int, int, int] = (256, 0, 0)) -> str:
        self.test_image_size = (50, 50)
        image = Image.new("RGB", size=self.test_image_size, color=rgb)

        # Draw some text on the image so we can test for image manipulation
        d = ImageDraw.Draw(image)
        d.text((10, 10), "Hello World", fill=(255, 255, 0))
        image.save(path, "PNG")
        return path

    @pytest.fixture(autouse=True)
    # @patch("curveclaw.curveclaw.tk.Tk")
    def setup(self, monkeypatch):
        with patch("curveclaw.curveclaw.tk.Tk") as _:
            self.mock_tk = Tk()

            self.temp_dir = tempfile.TemporaryDirectory()
            self.test_image_filename = "test-image.png"

            self.test_image_path = self.create_test_image(f"{self.temp_dir.name}/{self.test_image_filename}")
            monkeypatch.setenv("DATA_DIR", self.temp_dir.name)

            self.expected_curves_folder = f"{self.temp_dir.name}/curves"
            self.expected_preview_folder = f"{self.temp_dir.name}/preview"
            self.expected_output_folder = f"{self.temp_dir.name}/output"

            get_settings.cache_clear()
            self.main_app = CurveClaw()
            yield

            self.main_app.destroy()
            self.temp_dir.cleanup()
