
from functools import cache
from pathlib import Path

from appdirs import user_data_dir
from pydantic_settings import BaseSettings

from .utils import package

# Rich style tags
VAR_COLOR = "[bright_yellow]"
MSG_COLOR = "[bold cyan]"
FILE_COLOR = "[bright_green]"
WARN_COLOR = "[bold red]"
RESET = "[/]"

class Settings(BaseSettings):
    default_data_dir: Path = Path(user_data_dir(appname=package(), appauthor="Felix"))
    working_dir_file: str = "working_dir.txt"

    # Page names
    draw_lines_page: str = "PaintApp"
    extract_graph_page: str = "FigureExtractionApp"
    image_cleaner_page: str = "AutoCleaner"
    hash_connector_page: str = "HashCon"
    curve_claw_page: str = "CurveSelection"
    data_extraction_page: str = "DataExtractor"
    controller_page: str = "Controller"

    @property
    def data_dir(self) -> Path:
        """Returns the working directory, falling back to default if needed."""
        working_path_file = self.default_data_dir / self.working_dir_file

        try:
            content = working_path_file.read_text(encoding="utf-8").strip()
            path = Path(content)
        except FileNotFoundError:
            # Save default path to file
            working_path_file.write_text(str(self.default_data_dir), encoding="utf-8")
            path = self.default_data_dir

        # Validate path
        if path.exists():
            return path
        else:
            print(f"{WARN_COLOR}Warning: Path does not exist:{RESET} {path}")
            return self.default_data_dir

@cache
def get_settings():
    return Settings()
