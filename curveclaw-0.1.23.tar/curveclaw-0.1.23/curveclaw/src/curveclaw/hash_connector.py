import math
import tkinter as tk
from pathlib import Path
from tkinter import ttk

import numpy as np
from PIL import Image, ImageDraw, ImageTk
from rich import print as pprint
from scipy.ndimage import label
from tktooltip import ToolTip

from .base import BaseFrame
from .settings import MSG_COLOR, RESET, VAR_COLOR, get_settings
from .utils import build_frame, logger

"""
COPYRIGHT
2-clause BSD License
Copyright 2024 STFC
Author: Dr. Felix Rummel
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501


#########################################################
##DEFINE APP
#########################################################
class HashCon(BaseFrame):
    #########################################################
    ##DEFINE MAIN WINDOW HERE
    #########################################################
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.data_dir = Path(get_settings().data_dir)

        self.setup_ui()

    def setup_ui(self):
        # Determine the layout based on screen orientation and image size
        if self.controller.orientation == "landscape":  # Landscape orientation
            max_width = self.controller.width * 2 / 3 - 100
            max_height = self.controller.height - 100
        else:
            max_width = self.controller.width - 100
            max_height = self.controller.height * 2 / 3 - 100

        # Create the frame
        self.image_frame = ttk.LabelFrame(self, width=max_width, height=max_height, text="Working Image")

        if self.controller.orientation == "landscape":
            self.image_frame.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=(20, 10), pady=(20, 10))
        else:
            self.image_frame.grid(row=0, column=0, columnspan=2, sticky="nsew", padx=(20, 10), pady=(20, 10))
        self.image_frame.grid_propagate(False)  # This is key - prevents the frame from shrinking to fit content

        # Similar approach for control frame
        if self.controller.orientation == "landscape":
            control_frame_width = self.controller.width / 3 + 20
            # Calculate a more appropriate height based on content
            control_frame_height = 200  # Estimate based on content height
            coords = (0, 1)
        else:
            control_frame_width = self.controller.width + 20
            control_frame_height = 200  # Estimate based on content height
            coords = (1, 0)

        self.control_frame = build_frame(
            parent=self, height=control_frame_height, width=control_frame_width, text="Hash Selection", coords=coords
        )
        self.control_frame.grid_propagate(False)  # Prevent automatic resizing

        self.last_point = None
        self.point_set = []

        self.parent_frames = [self.image_frame, self.control_frame]

    def on_show_page(self):
        # Load the image
        self.input_image_path = self.controller.preview_image_path
        self.image = Image.open(self.input_image_path).convert("RGB")

        # Store original dimensions
        original_width, original_height = self.image.size

        # Calculate available space
        available_width = self.image_frame.winfo_width() - 100
        available_height = self.image_frame.winfo_height() - 100

        # Calculate aspect ratios
        original_ratio = original_width / original_height
        available_ratio = available_width / available_height

        # Resize the image to fit within this available space
        if original_ratio > available_ratio:
            self.resize_width = available_width
            self.resize_height = int(self.resize_width / original_ratio)
        else:
            self.resize_height = available_height
            self.resize_width = int(self.resize_height * original_ratio)

        # Load input image
        self.image = self.image.resize((self.resize_width, self.resize_height), Image.LANCZOS)
        self.display_image(self.image)

        # Fetch image data
        # Load the original image as a grayscale array
        self.original_array = np.asarray(Image.open(self.input_image_path).convert("L"))

        # Create the inverse binary array based on the threshold
        threshold = 127
        self.inv_original_array = np.where(self.original_array > threshold, 0, 1)

        # Label the inverse array
        self.labeled_original_array, self.num_labels = label(self.inv_original_array)

        # Check and save the image scaling
        self.scale_factor_x = original_width / (self.resize_width)
        self.scale_factor_y = original_height / (self.resize_height)

        self.create_widgets()

    #########################################################
    ##DEFINE ALL WIDGETS HERE
    #########################################################
    def create_widgets(self):
        # Top row - buttons
        button_frame = ttk.Frame(self.control_frame)
        button_frame.pack(fill="x", padx=10, pady=(10, 5))

        # Define New Hash Sequence button
        self.hash_seq = ttk.Button(
            button_frame,
            text="Define New Hash Sequence",
            command=self.hash_con_fun,
        )
        self.hash_seq.pack(side=tk.LEFT, padx=(0, 10), expand=True, fill="x")
        ToolTip(self.hash_seq, msg="Set the start point for connecting a set of hashes", delay=0.5)

        # Delete Last Point/Set button
        self.del_last = ttk.Button(
            button_frame,
            text="Delete Last Point/Set",
            command=self.del_last_fun,
        )
        self.del_last.pack(side=tk.RIGHT, expand=True, fill="x")
        ToolTip(self.del_last, msg="Deletes the previous addition", delay=0.5)

        # Middle row - thickness controls
        thickness_frame = ttk.Frame(self.control_frame)
        thickness_frame.pack(fill="x", padx=10, pady=5)

        # Thickness label
        self.line_thick_lbl = ttk.Label(thickness_frame, text="Line Thickness:")
        self.line_thick_lbl.pack(side=tk.LEFT, padx=(0, 10))

        # Thickness entry
        self.line_thick_entry = ttk.Entry(thickness_frame, width=5)
        self.line_thick_entry.insert(0, "3")
        self.line_thick_entry.pack(side=tk.LEFT, padx=(0, 10))

        # Thickness slider - with proper sizing
        self.thickness_slider = ttk.Scale(
            thickness_frame,
            from_=1,
            to=20,
            orient=tk.HORIZONTAL,
        )
        self.thickness_slider.set(3)
        self.thickness_slider.configure(command=self.update_thickness)
        self.thickness_slider.pack(side=tk.LEFT, fill="x", expand=True)

        # Bottom row - exit buttons
        exit_frame = ttk.Frame(self.control_frame)
        exit_frame.pack(fill="x", padx=10, pady=(5, 10))

        # Exit button
        self.exit_discard = ttk.Button(
            exit_frame,
            text="Exit",
            command=self.exit_application,
        )
        self.exit_discard.pack(side=tk.LEFT, padx=(0, 10), expand=True, fill="x")

        # Save and Exit button
        self.exit_save = ttk.Button(
            exit_frame,
            text="Save and Exit",
            command=self.exit_save_fun,
        )
        self.exit_save.pack(side=tk.RIGHT, expand=True, fill="x")

    #########################################################
    ##WIDGET FUNCTIONS
    #########################################################
    def hash_con_fun(self):
        # keep track of where the user clicks
        self.last_point = None
        # Unbind as necessary
        self.image_frame.image_label.unbind("<ButtonPress-1>")
        self.image_frame.image_label.unbind("<ButtonRelease-1>")
        # Bind LMB to select_pts event
        self.image_frame.image_label.bind("<Button-1>", self.on_left_click)

    def update_thickness(self, value):
        """
        Update entry when slider moves
        """
        rounded = int(round(float(value)))
        self.line_thick_entry.delete(0, tk.END)
        self.line_thick_entry.insert(0, str(rounded))
        self.connect_areas(save=False)

    def del_last_fun(self):
        # if there is a last selected point delete it else delete the last set
        if self.last_point is not None:
            self.last_point = None
        elif len(self.point_set) > 0:
            self.point_set.pop()
        else:
            pprint(f"{MSG_COLOR}⚠️ No points to delete{RESET}")

        # Update image
        self.connect_areas(save=False)

    def thin_fun(self):
        current_thickness = int(self.line_thick_entry.get())
        if current_thickness > 1:
            current_thickness -= 1
        self.line_thick_entry.delete(0, tk.END)
        self.line_thick_entry.insert(0, str(current_thickness))
        # Update image
        self.connect_areas(save=False)

    def exit_save_fun(self):
        self.connect_areas(save=True)
        self.destroy_widgets()
        filename = self.data_dir.joinpath("preview", "hold.png")

        pprint(f"{MSG_COLOR}Saving to:{RESET} {VAR_COLOR}{filename}{RESET}")

        # delete old file:
        if filename.exists():
            filename.unlink()
        self.controller.show_page(get_settings().controller_page)

    #########################################################
    ##OTHER FUNCTIONS
    #########################################################
    def display_image(self, image):
        tkimage = ImageTk.PhotoImage(image)
        self.image_frame.image_label = ttk.Label(self.image_frame, image=tkimage)
        self.image_frame.image_label.image = tkimage

        # Calculate padding to center the image in the frame
        pad_x = (self.image_frame.winfo_width() - self.resize_width) // 2
        pad_y = (self.image_frame.winfo_height() - self.resize_height) // 2

        # Place the label with explicit width and height
        self.image_frame.image_label.place(x=pad_x, y=pad_y, width=self.resize_width, height=self.resize_height)

    def clear_image(self):
        # Destroy the existing image label if it exists
        if hasattr(self.image_frame, "image_label"):
            self.image_frame.image_label.destroy()

    def on_left_click(self, event):
        # Get the coordinates of the clicked point on the scaled image
        x_raw, y_raw = event.x, event.y

        # Convert the coordinates to the unscaled image
        x = int(x_raw * self.scale_factor_x)
        y = int(y_raw * self.scale_factor_y)

        # Find the closest black pixel to the clicked point in the unscaled image
        closest_pixel = self.find_closest_black_pixel(x, y)

        # Process the closest black pixel
        if closest_pixel:
            # Check which area the pixel falls into
            area = self.labeled_original_array[closest_pixel[0], closest_pixel[1]]
            logger.debug(f"area is {area} for pixel at {closest_pixel}")

            # Set the current point
            current_point = (area, closest_pixel)

            # If there are at least two points in the list
            if self.last_point is not None:
                logger.debug(
                    f"start point ({self.last_point[1][0]} {self.last_point[1][1]})is in area {self.last_point[0]}"
                )

                logger.debug(f"end point ({current_point[1][0]} {current_point[1][1]}) is in area {area}")

                # Add the pair of points to points set as a tuple
                self.point_set.append((self.last_point, current_point))
                self.last_point = current_point
            else:
                self.last_point = current_point

        else:
            pprint(f"{MSG_COLOR}No closest black pixel found{RESET} {VAR_COLOR}(clicked on {x}, {y}){RESET}")

        # Call function to update the image from the point_set
        self.connect_areas(save=False)

    def draw_path(self, save):
        # Create a copy of the resized image to draw on
        output_image = self.image.copy()
        draw_output = ImageDraw.Draw(output_image)

        # Set the color and thickness
        draw_colour = 0  # black
        draw_thickness = int(self.line_thick_entry.get())

        # Draw on the resized image by scaling the coordinates
        for pair in self.to_connect:
            # Extract points and scale them to the resized dimensions
            p1_row = int(pair[0][0] / self.scale_factor_y)
            p1_col = int(pair[0][1] / self.scale_factor_x)
            p2_row = int(pair[1][0] / self.scale_factor_y)
            p2_col = int(pair[1][1] / self.scale_factor_x)

            # Draw line with the scaled coordinates
            draw_output.line(
                [(p1_col, p1_row), (p2_col, p2_row)],
                fill=draw_colour,
                width=draw_thickness,
            )

        # Clear current image and display new image
        self.clear_image()

        # Save the output image if needed
        output_image_name = "preview.png" if save else "hold.png"
        output_image_path = self.data_dir.joinpath("preview", output_image_name)
        output_image.save(output_image_path)

        # Display the new image
        self.display_image(output_image)
        self.image_frame.image_label.bind("<Button-1>", self.on_left_click)

    # Connect the areas as defined in the point_set list of tuples of tuples of area and tuple of coordinates
    def connect_areas(self, save):
        # List of coordinates to connect
        self.to_connect = []
        # Need to ensure we have some points to connect
        if len(self.point_set) > 0:
            for points in self.point_set:  # grab a tuple
                # Extract area and coordinates
                start_area = points[0][0]
                end_area = points[1][0]
                start_coordinate = points[0][1]
                end_coordinate = points[1][1]
                if start_area == end_area:
                    self.to_connect.append((start_coordinate, end_coordinate))
                else:
                    # Need to find the two closest pixels in the two different areas
                    closest_pair = self.closest_area_pixels(start_area, end_area)
                    self.to_connect.append(closest_pair)

            # Call function to draw a new image
            self.draw_path(save)
        else:
            self.clear_image()
            self.display_image(self.image)
            self.image_frame.image_label.bind("<Button-1>", self.on_left_click)

    # Given two areas a1 and a2 in the form for an image array find the two closest pixels in that area
    def closest_area_pixels(self, a1, a2):
        # Get the indices of elements that match the value
        result = np.where(self.labeled_original_array == a1)

        # Convert the result to a list of (row, column) tuples
        a1_pixels = list(zip(result[0], result[1]))

        # Get the indices of elements that match the value
        result = np.where(self.labeled_original_array == a2)

        # Convert the result to a list of (row, column) tuples
        a2_pixels = list(zip(result[0], result[1]))

        # Find the two closest pixels
        min_distance = float("inf")
        closest_pair = (None, None)

        for x1, y1 in a1_pixels:
            for x2, y2 in a2_pixels:
                distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
                if distance < min_distance:
                    min_distance = distance
                    closest_pair = ((x1, y1), (x2, y2))
        return closest_pair

    def find_closest_black_pixel(self, x, y):
        # Iterate through the image array to find the closest black pixel
        min_distance = float("inf")
        closest_pixel = None
        for i in range(self.original_array.shape[0]):
            for j in range(self.original_array.shape[1]):
                if self.original_array[i, j] == 0:  # Black pixel
                    distance = np.sqrt((i - y) ** 2 + (j - x) ** 2)
                    if distance < min_distance:
                        min_distance = distance
                        closest_pixel = (i, j)
        return closest_pixel
