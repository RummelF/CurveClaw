import tkinter as tk
from pathlib import Path
from tkinter import ttk

from rich import print as pprint

from .settings import FILE_COLOR, MSG_COLOR, RESET, VAR_COLOR, get_settings


class AxisApp:
    def __init__(self, master, file_name):
        self.master = master
        self.master.title("Meta Data Entry")
        self.file_name = file_name

        # Initialize options
        self.main_options = ["Condition", "Substance"]
        self.sub_options = ["Other", "Solvent", "Oil", "Salt", "Mixed", "Surfactant"]

        self.initialize_string_vars()
        pprint(f"{MSG_COLOR}Initialized StringVars:{RESET}")
        pprint(f"{MSG_COLOR}Selected Main X: {VAR_COLOR}{self.selected_main_x.get()}{RESET}")
        pprint(f"{MSG_COLOR}Selected Main Y: {VAR_COLOR}{self.selected_main_y.get()}{RESET}")
        pprint(f"{MSG_COLOR}Selected Main Z: {VAR_COLOR}{self.selected_main_z.get()}{RESET}")

        # GUI components
        self.condition_entries = [None, None, None]

        self.axis_frame = ttk.Frame(self.master)
        self.axis_frame.grid(row=1, column=0, padx=10, pady=10)

        self.other_frame = ttk.Frame(self.master)
        self.other_frame.grid(row=2, column=0, padx=10, pady=10)

        self.button_frame = ttk.Frame(self.master)
        self.button_frame.grid(row=3, column=0, padx=10, pady=10)

        self.create_axis_controls()
        self.create_print_button()
        self.create_other_fields()

    def initialize_string_vars(self):
        """Initialize StringVar instances with main options"""
        self.selected_main_x = tk.StringVar(value=self.main_options[0])
        self.selected_main_y = tk.StringVar(value=self.main_options[0])
        self.selected_main_z = tk.StringVar(value=self.main_options[0])
        self.selected_sub_x = tk.StringVar()
        self.selected_sub_y = tk.StringVar()
        self.selected_sub_z = tk.StringVar()

        # Trace callbacks
        self.selected_main_x.trace_add(
            "write",
            lambda *args: self.update_sub_options(self.selected_main_x, self.sub_frame_x, 0, self.selected_sub_x),
        )
        self.selected_main_y.trace_add(
            "write",
            lambda *args: self.update_sub_options(self.selected_main_y, self.sub_frame_y, 1, self.selected_sub_y),
        )
        self.selected_main_z.trace_add(
            "write",
            lambda *args: self.update_sub_options(self.selected_main_z, self.sub_frame_z, 2, self.selected_sub_z),
        )

    def create_other_fields(self):
        pprint(f"{MSG_COLOR}Creating other fields...{RESET}")
        ttk.Label(
            self.other_frame,
            text="""
            Use commas to separate between multiple items in a field if needed.
            Note that the substances defined above will be referred to in that order.
            """,
        ).grid(row=0, column=0, padx=10, pady=10, columnspan=2)
        ttk.Label(self.other_frame, text="Method of Measurement:").grid(row=1, column=0, padx=10, pady=10)
        ttk.Label(self.other_frame, text="Purity of Compounds:").grid(row=2, column=0, padx=10, pady=10)
        ttk.Label(self.other_frame, text="Reference or Source:").grid(row=3, column=0, padx=10, pady=10)
        ttk.Label(self.other_frame, text="Origin of Compounds:").grid(row=4, column=0, padx=10, pady=10)
        ttk.Label(self.other_frame, text="SMILES of Compounds:").grid(row=5, column=0, padx=10, pady=10)
        ttk.Label(self.other_frame, text="Solvent:").grid(row=6, column=0, padx=10, pady=10)
        ttk.Label(self.other_frame, text="Other Comments:").grid(row=7, column=0, padx=10, pady=10)
        self.measurement_entry = ttk.Entry(self.other_frame)
        self.measurement_entry.grid(row=1, column=1, padx=10, pady=10)
        self.purity_entry = ttk.Entry(self.other_frame)
        self.purity_entry.grid(row=2, column=1, padx=10, pady=10)
        self.reference_entry = ttk.Entry(self.other_frame)
        self.reference_entry.grid(row=3, column=1, padx=10, pady=10)
        self.origin_entry = ttk.Entry(self.other_frame)
        self.origin_entry.grid(row=4, column=1, padx=10, pady=10)
        self.smiles_entry = ttk.Entry(self.other_frame)
        self.smiles_entry.grid(row=5, column=1, padx=10, pady=10)
        self.solvent_entry = ttk.Entry(self.other_frame)
        self.solvent_entry.grid(row=6, column=1, padx=10, pady=10)
        self.comment_entry = ttk.Entry(self.other_frame)
        self.comment_entry.grid(row=7, column=1, padx=10, pady=10)

    def create_axis_controls(self):
        pprint(f"{MSG_COLOR}Creating axis controls...{RESET}")
        axis_labels = ["X Axis", "Y Axis", "Z Axis"]
        main_vars = [self.selected_main_x, self.selected_main_y, self.selected_main_z]
        sub_vars = [self.selected_sub_x, self.selected_sub_y, self.selected_sub_z]

        self.sub_frame_x = ttk.Frame(self.axis_frame)
        self.sub_frame_x.grid(row=0, column=2, padx=5, pady=5)
        self.sub_frame_y = ttk.Frame(self.axis_frame)
        self.sub_frame_y.grid(row=1, column=2, padx=5, pady=5)
        self.sub_frame_z = ttk.Frame(self.axis_frame)
        self.sub_frame_z.grid(row=2, column=2, padx=5, pady=5)

        for i, label in enumerate(axis_labels):
            ttk.Label(self.axis_frame, text=f"{label} Identity:").grid(row=i, column=0, padx=5, pady=5)

            # Main option dropdown
            pprint(
                f"{MSG_COLOR}Creating OptionMenu for {VAR_COLOR}{label}{RESET} "
                f"with initial value {VAR_COLOR}{main_vars[i].get()}{RESET}"
            )

            main_menu = ttk.OptionMenu(self.axis_frame, main_vars[i], main_vars[i].get(), *self.main_options)
            main_menu.grid(row=i, column=1, padx=5, pady=5)

            # Sub option frame (dynamic content area)
            sub_frame = [self.sub_frame_x, self.sub_frame_y, self.sub_frame_z][i]
            self.update_sub_options(main_vars[i], sub_frame, i, sub_vars[i])

    def create_print_button(self):
        pprint(f"{MSG_COLOR}Creating print button...{RESET}")
        # Button to print the current state of all axis selections
        print_button = ttk.Button(self.button_frame, text="Save Meta Data", command=self.print_axis_state)
        print_button.grid(row=0, column=0, padx=5, pady=5)

    def update_sub_options(self, selected_main, sub_frame, index, selected_sub):
        pprint(
            f"{MSG_COLOR}Updating sub-options for axis {VAR_COLOR}{index}{RESET} "
            f"with main option {VAR_COLOR}{selected_main.get()}{RESET}"
        )

        current_main = selected_main.get()

        # Clear previous widgets in sub_frame
        for widget in sub_frame.winfo_children():
            widget.destroy()

        if current_main == "Condition":
            # Create an entry field for "Condition"
            entry = ttk.Entry(sub_frame)
            entry.grid(row=0, column=0, padx=5, pady=5)
            self.condition_entries[index] = entry
        else:
            # Create dropdown for "Substance" options
            selected_sub.set(self.sub_options[0])  # Set default to the first option
            pprint(
                f"{MSG_COLOR}Creating OptionMenu for 'Substance' "
                f"with default value {VAR_COLOR}{selected_sub.get()}{RESET}"
            )

            sub_menu = ttk.OptionMenu(sub_frame, selected_sub, self.sub_options[0], *self.sub_options)
            sub_menu.grid(row=0, column=0, padx=5, pady=5)

    def print_axis_state(self):
        pprint(f"{MSG_COLOR}Printing axis state...{RESET}")
        meta_data = "#User Entered Meta Data\n"
        meta_data += f"#File Name: {self.file_name}\n"
        state = self.get_axis_state()
        meta_data += state
        entries = self.get_entries()
        meta_data += entries
        self.save_string_to_file(meta_data)
        self.master.destroy()

    def save_string_to_file(self, content):
        file_path = Path(get_settings().data_dir).joinpath("preview", "meta_data.txt")
        # Check if the file exists
        if file_path.exists():
            # If it exists, remove the file
            file_path.unlink()
            pprint(f"{MSG_COLOR}Deleted existing file: {FILE_COLOR}{file_path}{RESET}")

        # Write the content to the file
        with open(file_path, "w") as file:
            file.write(content)
        pprint(
            f"{MSG_COLOR}Saved string:\n"
            f"{VAR_COLOR}{content}{RESET} "
            f"{MSG_COLOR}To file:{RESET} "
            f"{FILE_COLOR}{file_path}{RESET}"
        )

    def get_axis_state(self):
        pprint(f"{MSG_COLOR}Getting axis state...{RESET}")

        def get_state(main_var, entry, sub_var):
            if main_var.get() == "Condition":
                return f"{entry.get()}" if entry else ""
            else:
                return f"{main_var.get()}->{sub_var.get()}"

        def state_to_list(state):
            if "Substance" in state:
                return state.split("->")[1]
            else:
                return None

        string = "#Axis Data:\n"
        list_of_states = []
        self.defined_substances = []  # Store the substances which have been defined in their order
        if len(get_state(self.selected_main_x, self.condition_entries[0], self.selected_sub_x)) > 0:
            x_state = get_state(self.selected_main_x, self.condition_entries[0], self.selected_sub_x)
            string += f"#X Axis: {x_state}\n"
            list_of_states.append(("X Axis", x_state))
        if len(get_state(self.selected_main_y, self.condition_entries[1], self.selected_sub_y)) > 0:
            y_state = get_state(self.selected_main_y, self.condition_entries[1], self.selected_sub_y)
            string += f"#Y Axis: {y_state}\n"
            list_of_states.append(("Y Axis", y_state))
        if len(get_state(self.selected_main_z, self.condition_entries[2], self.selected_sub_z)) > 0:
            z_state = get_state(self.selected_main_z, self.condition_entries[2], self.selected_sub_z)
            string += f"#Z Axis: {z_state}\n"
            list_of_states.append(("Z Axis", z_state))

        # Record which substances have been defined for what axis as a list of tuple (axis, substance)
        self.defined_substances = []
        for axis, state in list_of_states:
            check = state_to_list(state)
            if check is not None:
                self.defined_substances.append((axis, check))

        pprint(f"{MSG_COLOR}Defined substances: {VAR_COLOR}{self.defined_substances}{RESET}")
        return string

    def get_entries(self):
        pprint(f"{MSG_COLOR}Getting entries...{RESET}")
        output = ""
        m_str = self.measurement_entry.get()
        p_str = self.purity_entry.get()
        r_str = self.reference_entry.get()
        o_str = self.origin_entry.get()
        s_str = self.smiles_entry.get()
        sol_str = self.solvent_entry.get()
        c_str = self.comment_entry.get()

        titles = [
            "Method of Measurement:",
            "Purity:",
            "Reference or Source:",
            "Origin of Compound:",
            "SMILES of Compound:",
            "Solvent:",
            "Other Comments:",
        ]
        values = [m_str, p_str, r_str, o_str, s_str, sol_str, c_str]
        list_for_substance_idx = [1, 3, 4]

        # Iterate through the entries
        for idx, title in enumerate(titles):
            if len(values[idx]) > 0:  # If there is an entry
                if idx not in list_for_substance_idx:  # Must be a single entry
                    output += f"#{title} {values[idx].strip()}\n"
                else:  # Potentially could enter multiple substances
                    split_string = values[idx].split(",")  # comma separated
                    processed_strings = [item.strip() for item in split_string]  # strip whitespace
                    for idx_2, processed_string in enumerate(processed_strings):  # enumerate entries
                        if len(self.defined_substances) == len(
                            processed_strings
                        ):  # check if we have the right number of defined substances
                            output += (
                                f"#{title} for {self.defined_substances[idx_2][0]} "
                                f"Substance {self.defined_substances[idx_2][1]}: "
                                f"{processed_string}\n"
                            )
                        else:  # generic entries if not
                            output += f"#{title} for Entry {idx_2}: {processed_string}\n"
        pprint(f"{MSG_COLOR}Generated entries output:\n{VAR_COLOR}{output}{RESET}")
        return output


def setup(file_name):
    root = tk.Toplevel()  # Use Toplevel if Tk instance already exists
    AxisApp(root, file_name)
    root.mainloop()


# Example usage
if __name__ == "__main__":
    root = tk.Tk()  # Use Tk if no Tk instance exists
    app = AxisApp(root, "TEST_CASE")
    root.mainloop()
