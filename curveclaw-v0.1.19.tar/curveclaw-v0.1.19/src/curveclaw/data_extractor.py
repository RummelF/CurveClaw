import json
import re
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, ttk
from typing import Any

import cv2
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageTk
from rich import print as pprint
from scipy.ndimage import label
from tktooltip import ToolTip

from curveclaw.settings import FILE_COLOR, MSG_COLOR, RESET, VAR_COLOR, WARN_COLOR

from . import meta_entry
from .base import BaseFrame
from .method_validation import (
    BinaryPhaseAssignInput,
    BinaryProbabilityInput,
    LineDataInput,
    TernaryPhaseAssignInput,
    TernaryProbabilityInput,
    process_input,
)
from .methods.binary_phase_assign import assign_phases_fun as binary_assign_phases_fun
from .methods.binary_probability import probability_fun as binary_probability_fun
from .methods.line_data import extract_line_data
from .methods.ternary_phase_assign import area_assign_fun as ternary_assign_phases_fun
from .methods.ternary_probability import probability_fun as ternary_probability_fun
from .settings import get_settings

"""
COPYRIGHT
2-clause BSD License
Copyright 2024 STFC
Author: Dr. Felix Rummel
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""  # noqa: E501

# The Method Data Classes are used to execute methods. They require a data extraction class,
# a method to execute and a list of fields that are required. A new class must be created for
# method file written by the user, this should be added to the method_dict in the main class.


class MethodData:
    def __init__(self):
        self.data_extraction_class = None
        self.method_handler = None
        self.required_fields = []

    def execute(self, parameters: dict[str, Any]) -> bool:
        # Extract only the required parameters
        validated_parameters = process_input(self.data_extraction_class, parameters)

        if validated_parameters.get("status") == "error":
            error = validated_parameters.get("errors")
            pprint(f"{WARN_COLOR}Error:{RESET} {VAR_COLOR}{error}{RESET}")
            return False

        # Get cleaned data and only select required parameters to execute function
        required_parameters = {
            key: value for key, value in validated_parameters.items() if key in self.required_fields
        }

        self.method_handler(**required_parameters)
        return True


class LineData(MethodData):
    def __init__(self):
        self.data_extraction_class = LineDataInput
        self.method_handler = extract_line_data
        self.required_fields = ["filename", "filepaths", "axis_lengths", "step_size", "log_scales"]


class BinaryPhaseAssignData(MethodData):
    def __init__(self):
        self.data_extraction_class = BinaryPhaseAssignInput
        self.method_handler = binary_assign_phases_fun
        self.required_fields = ["filename", "axis_lengths", "step_size", "log_scales"]


class BinaryProbabilityData(MethodData):
    def __init__(self):
        self.data_extraction_class = BinaryProbabilityInput
        self.method_handler = binary_probability_fun
        self.required_fields = ["filename", "axis_lengths", "step_size", "log_scales"]


class TernaryPhaseAssignData(MethodData):
    def __init__(self):
        self.data_extraction_class = TernaryPhaseAssignInput
        self.method_handler = ternary_assign_phases_fun
        self.required_fields = ["filename", "axis_lengths", "step_size", "log_scales"]


class TernaryProbabilityData(MethodData):
    def __init__(self):
        self.data_extraction_class = TernaryProbabilityInput
        self.method_handler = ternary_probability_fun
        self.required_fields = ["filename", "axis_lengths", "step_size", "log_scales"]


#########################################################
##DEFINE APP
#########################################################
class DataExtractor(BaseFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.data_dir = Path(get_settings().data_dir)
        self.method_dict = {
            "Binary Phase Assign": BinaryPhaseAssignData,
            "Binary Probability": BinaryProbabilityData,
            "Line Data": LineData,
            "Ternary Phase Assign": TernaryPhaseAssignData,
            "Ternary Probability": TernaryProbabilityData,
        }
        self.setup_ui()

    def setup_ui(self):
        frame_width = self.controller.width / 2 - 100
        frame_height = self.controller.height / 2 - 100

        # Initialise window depending on screen
        if self.controller.orientation == "landscape":  # Landscape orientation
            # Create the frame for the various control widgets
            self.control_frame = ttk.LabelFrame(
                self, width=frame_width, height=frame_height, text="Control Options", padding=(20, 10)
            )
            self.control_frame.grid(row=0, column=0, rowspan=2, padx=20, pady=20, sticky="nsew")
            # Create the frame to display output image
            self.out_img_frame = ttk.LabelFrame(
                self, width=frame_width, height=frame_height, text="Output Image", padding=(20, 10)
            )
            self.out_img_frame.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")
            # Create the frame to display any output data / text
            self.out_txt_frame = ttk.LabelFrame(
                self, width=frame_width, height=frame_height, text="Output Text", padding=(20, 10)
            )
            self.out_txt_frame.grid(row=1, column=1, padx=20, pady=20, sticky="nsew")
        else:  # Portrait orientation
            # Create the frame for the various control widgets
            self.control_frame = ttk.LabelFrame(
                self, width=frame_width, height=frame_height, text="Control Options", padding=(20, 10)
            )
            self.control_frame.grid(row=0, column=0, columnspan=2, padx=20, pady=20, sticky="nsew")
            # Create the frame to display output image
            self.out_img_frame = ttk.LabelFrame(
                self, width=frame_width, height=frame_height, text="Output Image", padding=(20, 10)
            )
            self.out_img_frame.grid(row=1, column=1, padx=20, pady=20, sticky="nsew")
            # Create the frame to display any output data / text
            self.out_txt_frame = ttk.LabelFrame(
                self, width=frame_width, height=frame_height, text="Output Text", padding=(20, 10)
            )
            self.out_txt_frame.grid(row=1, column=0, padx=20, pady=20, sticky="nsew")

        # Store overlayed curves
        self.overlayed_curves_image = None
        self.file_paths = []
        self.parent_frames = [self.control_frame, self.out_img_frame, self.out_txt_frame]

    def on_show_page(self):
        # Set output name
        self.output_name = self.controller.input_name

        # Add all the widgets
        self.create_widgets()

    #########################################################
    ##DEFINE ALL BUTTON POSITIONS HERE
    #########################################################
    def create_widgets(self):
        # File selection section
        self.select_files = ttk.Button(
            self.control_frame,
            text="Select specific File/s",
            command=self.select_files_fun,
            padding=(20, 10),
        )
        ToolTip(self.select_files, msg="Select specific file/s", delay=0.5)

        self.auto_select = ttk.Button(
            self.control_frame,
            text="Auto select File/s",
            command=self.auto_select_fun,
            padding=(20, 10),
        )
        ToolTip(self.select_files, msg="Automatically select file/s", delay=0.5)

        # Overlay section
        self.overlay_curves = ttk.Button(
            self.control_frame,
            text="Overlay Curves",
            command=self.overlay_curves_fun,
            state=tk.DISABLED,
            padding=(20, 10),
        )
        ToolTip(self.select_files, msg="Overlay selected file/s", delay=0.5)

        self.overlay_curves_lbl = ttk.Label(self.control_frame, text="Specify Curves:", padding=(10, 10))
        self.overlay_curves_entry = ttk.Entry(self.control_frame, width=5)
        self.overlay_curves_entry.insert(0, "all")

        # Edit Overlay section
        self.overlay_edit_lbl = ttk.Label(self.control_frame, text="Edit Overlay Options:", padding=(10, 10))

        self.draw_on_overlay = ttk.Button(
            self.control_frame,
            text="Draw Lines",
            command=self.draw_on_overlay_fun,
            state=tk.DISABLED,
            padding=(20, 10),
        )
        ToolTip(self.draw_on_overlay, msg="Drawing Tool", delay=0.5)

        self.fill_small_areas = ttk.Button(
            self.control_frame,
            text="Fill Small Areas",
            command=self.fill_small_areas_fun,
            state=tk.DISABLED,
            padding=(20, 10),
        )
        ToolTip(
            self.fill_small_areas,
            msg="Fills all areas in the output image which are of a size below the specified area size. Area size is "
            + "the number of pixels in the area relative to the total number of pixels in the image.",
            delay=0.5,
        )

        self.thin_lines = ttk.Button(
            self.control_frame,
            text="Thin Lines",
            command=self.thin_lines_fun,
            state=tk.DISABLED,
            padding=(20, 10),
        )
        ToolTip(self.thin_lines, msg="Thin lines without changing the number of areas within the image.", delay=0.5)

        self.area_cutoff_lbl = ttk.Label(self.control_frame, text="Area Size% cutoff", padding=(10, 10))
        self.area_cutoff_entry = ttk.Entry(self.control_frame, width=5)
        self.area_cutoff_entry.insert(0, "0.1")

        self.area_count_lbl = ttk.Label(
            self.control_frame,
            text="Current area count is: N/A",
            padding=(10, 10),
        )

        # Data Extraction section
        self.data_extr_lbl = ttk.Label(self.control_frame, text="Data Extraction Mode:", padding=(10, 10))
        self.selected_mode = tk.StringVar()
        self.mode_options = ["Select an option", "Binary", "Ternary", "Line"]
        self.dropdown = ttk.OptionMenu(self.control_frame, self.selected_mode, *self.mode_options)
        self.selected_mode.set(self.mode_options[0])
        self.selected_mode.trace_add("write", self.mode_change_function)

        self.data_range_lbl = ttk.Label(self.control_frame, text="X, Y, Z Dimensions:", padding=(10, 10))
        self.data_range_entry = ttk.Entry(self.control_frame, width=15)
        self.data_range_entry.insert(0, "(0,100), (0,100)")

        self.step_lbl = ttk.Label(self.control_frame, text="X, Y, Z Grid Control:", padding=(10, 10))
        self.step_entry = ttk.Entry(self.control_frame, width=10)
        self.step_entry.insert(0, "101,101")

        self.log_scale_lbl = ttk.Label(self.control_frame, text="Log Scale:", padding=(10, 10))
        self.log_scale_entry = ttk.Entry(self.control_frame, width=10)

        self.method_lbl = ttk.Label(self.control_frame, text="Method Selection:", padding=(10, 10))
        self.selected_method = tk.StringVar()
        self.method_dropdown = ttk.OptionMenu(self.control_frame, self.selected_method, *self.method_dict.keys())

        # Action buttons section
        self.extract_data = ttk.Button(
            self.control_frame,
            text="Extract Data",
            command=self.extract_data_fun,
            padding=(20, 10),
        )

        self.meta_data = ttk.Button(
            self.control_frame,
            text="Enter Meta Data",
            command=self.meta_data_fun,
            state=tk.DISABLED,
            padding=(20, 10),
        )

        self.save_exit = ttk.Button(
            self.control_frame,
            text="Exit",
            command=self.exit_application,
            padding=(20, 10),
        )

        # Layout with improved spacing
        if self.controller.orientation == "landscape":
            # File section - Row 0-1
            self.select_files.grid(row=0, column=0, padx=5, pady=10, sticky="ew")
            self.auto_select.grid(row=0, column=1, padx=5, pady=10, sticky="ew")

            # Separator
            ttk.Separator(self.control_frame, orient="horizontal").grid(
                row=1, column=0, columnspan=3, sticky="ew", pady=5
            )

            # Overlay section - Row 2-3
            self.overlay_curves.grid(row=2, column=0, padx=5, pady=5, sticky="ew")
            self.overlay_curves_lbl.grid(row=2, column=1, padx=5, pady=5, sticky="w")
            self.overlay_curves_entry.grid(row=2, column=2, padx=5, pady=5, sticky="w")

            # Edit Overlay section - Row 4-6
            self.overlay_edit_lbl.grid(row=4, column=0, columnspan=3, padx=5, pady=(10, 5), sticky="w")
            self.draw_on_overlay.grid(row=5, column=0, padx=5, pady=5, sticky="ew")
            self.fill_small_areas.grid(row=5, column=1, padx=5, pady=5, sticky="ew")
            self.thin_lines.grid(row=5, column=2, padx=5, pady=5, sticky="ew")
            self.area_count_lbl.grid(row=6, column=0, padx=5, pady=5, sticky="w")
            self.area_cutoff_lbl.grid(row=6, column=1, padx=5, pady=5, sticky="e")
            self.area_cutoff_entry.grid(row=6, column=2, padx=5, pady=5, sticky="w")

            # Separator
            ttk.Separator(self.control_frame, orient="horizontal").grid(
                row=7, column=0, columnspan=3, sticky="ew", pady=5
            )

            # Data Extraction section - Row 8-13
            self.data_extr_lbl.grid(row=8, column=0, padx=5, pady=5, sticky="w")
            self.dropdown.grid(row=8, column=1, columnspan=2, padx=5, pady=5, sticky="ew")
            self.data_range_lbl.grid(row=9, column=0, padx=5, pady=5, sticky="w")
            self.data_range_entry.grid(row=9, column=1, columnspan=2, padx=5, pady=5, sticky="ew")
            self.step_lbl.grid(row=10, column=0, padx=5, pady=5, sticky="w")
            self.step_entry.grid(row=10, column=1, columnspan=2, padx=5, pady=5, sticky="ew")
            self.log_scale_lbl.grid(row=11, column=0, padx=5, pady=5, sticky="w")
            self.log_scale_entry.grid(row=11, column=1, columnspan=2, padx=5, pady=5, sticky="ew")
            self.method_lbl.grid(row=12, column=0, padx=5, pady=5, sticky="w")
            self.method_dropdown.grid(row=12, column=1, columnspan=2, padx=5, pady=5, sticky="ew")

            # Separator
            ttk.Separator(self.control_frame, orient="horizontal").grid(
                row=13, column=0, columnspan=3, sticky="ew", pady=5
            )

            # Action buttons - Row 14
            self.extract_data.grid(row=14, column=0, padx=5, pady=10, sticky="ew")
            self.meta_data.grid(row=14, column=1, padx=5, pady=10, sticky="ew")
            self.save_exit.grid(row=14, column=2, padx=5, pady=10, sticky="ew")

        else:  # Portrait orientation
            # Left column for file and overlay controls
            # File section
            self.select_files.grid(row=0, column=0, padx=5, pady=10, sticky="ew")
            self.auto_select.grid(row=0, column=1, padx=5, pady=10, sticky="ew")

            # Overlay section
            self.overlay_curves.grid(row=1, column=0, padx=5, pady=5, sticky="ew")
            self.overlay_curves_lbl.grid(row=1, column=1, padx=5, pady=5, sticky="w")
            self.overlay_curves_entry.grid(row=1, column=2, padx=5, pady=5, sticky="w")

            # Edit Overlay section
            self.overlay_edit_lbl.grid(row=2, column=0, columnspan=3, padx=5, pady=(10, 5), sticky="w")
            self.draw_on_overlay.grid(row=3, column=0, padx=5, pady=5, sticky="ew")
            self.fill_small_areas.grid(row=3, column=1, padx=5, pady=5, sticky="ew")
            self.thin_lines.grid(row=3, column=2, padx=5, pady=5, sticky="ew")
            self.area_count_lbl.grid(row=4, column=0, padx=5, pady=5, sticky="w")
            self.area_cutoff_lbl.grid(row=4, column=1, padx=5, pady=5, sticky="e")
            self.area_cutoff_entry.grid(row=4, column=2, padx=5, pady=5, sticky="w")

            # Right column for data extraction
            # Data Extraction section
            self.data_extr_lbl.grid(row=0, column=3, padx=5, pady=5, sticky="w")
            self.dropdown.grid(row=0, column=4, padx=5, pady=5, sticky="ew")
            self.data_range_lbl.grid(row=1, column=3, padx=5, pady=5, sticky="w")
            self.data_range_entry.grid(row=1, column=4, padx=5, pady=5, sticky="ew")
            self.step_lbl.grid(row=2, column=3, padx=5, pady=5, sticky="w")
            self.step_entry.grid(row=2, column=4, padx=5, pady=5, sticky="ew")
            self.log_scale_lbl.grid(row=3, column=3, padx=5, pady=5, sticky="w")
            self.log_scale_entry.grid(row=3, column=4, padx=5, pady=5, sticky="ew")
            self.method_lbl.grid(row=4, column=3, padx=5, pady=5, sticky="w")
            self.method_dropdown.grid(row=4, column=4, padx=5, pady=5, sticky="ew")

            # Action buttons at bottom
            ttk.Separator(self.control_frame, orient="horizontal").grid(
                row=5, column=0, columnspan=5, sticky="ew", pady=5
            )
            self.extract_data.grid(row=6, column=0, padx=5, pady=10, sticky="ew")
            self.meta_data.grid(row=6, column=2, padx=5, pady=10, sticky="ew")
            self.save_exit.grid(row=6, column=4, padx=5, pady=10, sticky="ew")

        # try to update the overlay
        try:
            self.close_function_draw()
        except Exception as e:
            print(e)

    #########################################################
    ##DEFINE ALL BUTTON FUNCTIONS HERE
    #########################################################
    def assign_phases_left_fun(self):
        self.save_area_label()
        if self.current_area > 1:
            self.current_area -= 1
        self.display_and_assign()

    def assign_phases_right_fun(self):
        self.save_area_label()
        if self.current_area < self.num_areas:
            self.current_area += 1
        self.display_and_assign()

    def assign_curve_left_fun(self):
        self.save_curve_label()
        if self.current_curve_index > 0:
            self.current_curve_index -= 1
        self.current_curve = self.available_curves[self.current_curve_index]
        self.display_and_assign_curve()

    def assign_curve_right_fun(self):
        self.save_curve_label()
        if self.current_curve_index < len(self.available_curves) - 1:
            self.current_curve_index += 1
        self.current_curve = self.available_curves[self.current_curve_index]
        self.display_and_assign_curve()

    def revert_view_fun(self):
        try:
            self.display_output(self.overlayed_curves_image)
        except:  # noqa
            pprint(f"{WARN_COLOR}Error:{RESET} The overlayed image is not defined")

    def meta_data_fun(self):
        if self.overlayed_curves_image is not None:
            # call meta module
            meta_entry.setup(self.output_name)

    def extract_data_fun(self):
        if not self.selected_mode.get() or self.selected_mode.get() == self.mode_options[0]:
            pprint(f"{WARN_COLOR}Error:{RESET} Select a Data Extraction Mode")
            return

        is_mode_line = self.selected_mode.get() == "Line"

        if is_mode_line:
            if self.curve_dictionary is None:
                pprint(f"{WARN_COLOR}Error:{RESET} No curves available")
                return

            self.assign_curve_left_fun()
            self.assign_curve_right_fun()
            self.save_curve_dictionary()
        else:
            self.assign_phases_left_fun()
            self.assign_phases_right_fun()
            self.save_area_dictionary()

        parameters = {
            "filename": self.output_name,
            "filepaths": self.file_paths,
            "axis_lengths": self.data_range_entry.get(),
            "step_size": self.step_entry.get(),
            "log_scales": self.log_scale_entry.get(),
            "extraction_mode": self.selected_mode.get(),
        }

        method_class = self.method_dict[self.selected_method.get()]
        success = method_class().execute(parameters)

        if not success:
            pprint(f"{WARN_COLOR}Error:{RESET} Method execution failed")
            return

        try:
            if is_mode_line:
                self.add_meta_line_data()
            else:
                self.add_meta_area_data()
        except Exception as e:
            pprint(f"{WARN_COLOR}Exception:{RESET} {VAR_COLOR}{e}{RESET}")

    def select_files_fun(self):  # function to select any file
        initial_dir = self.data_dir.joinpath("curves")
        image_file_types = [
            ("Image files", "*.jpg"),
            ("Image files", "*.jpeg"),
            ("Image files", "*.png"),
            ("Image files", "*.gif"),
        ]

        files = filedialog.askopenfilenames(
            initialdir=str(initial_dir),
            filetypes=image_file_types,
        )
        self.file_paths = []
        for item in files:
            if len(item) > 0:
                self.file_paths.append(item)
        self.file_paths_img = [Path(path).stem for path in self.file_paths]
        self.overlay_curves.config(state=tk.NORMAL)
        self.meta_data.config(state=tk.NORMAL)
        if self.selected_mode.get() == "Binary" or self.selected_mode.get() == "Ternary":
            self.assign_phases_left.config(state=tk.NORMAL)
            self.assign_phases_right.config(state=tk.NORMAL)
            self.revert_view.config(state=tk.NORMAL)
        elif self.selected_mode.get() == "Line":
            self.assign_curves_left.config(state=tk.NORMAL)
            self.assign_curves_right.config(state=tk.NORMAL)
            self.revert_view.config(state=tk.NORMAL)

        # Show the selected file names
        self.display_strings(self.file_paths_img)

        # Show the image
        self.overlay_curves_fun()

        # update the curves selector variable accordingly
        self.update_available_curves()

    def update_available_curves(self):
        try:
            self.available_curves = [
                int(item.split("curve_")[-1].split(".png")[0]) for item in self.file_paths_img if "curve" in item
            ]
            if len(self.available_curves) == 0:
                self.available_curves = None
        except Exception:
            self.available_curves = None
        if self.available_curves is not None:
            self.current_curve = min(self.available_curves)
            self.current_curve_index = self.available_curves.index(self.current_curve)
            # create the dictionary to store data
            self.curve_dictionary = {i: "not_given" for i in range(1, len(self.available_curves) + 1)}
        else:
            self.curve_dictionary = None

    def auto_select_fun(
        self,
    ):  # function to select all curve_n.png files in the curves folder
        initial_dir = self.data_dir.joinpath("curves")
        # Regular expression to match filenames like "curves_1.png", "curves_2.png", etc.
        pattern = re.compile(r"curve_\d+\.png$")
        self.file_paths = []
        # Iterate through files in the directory
        for filename in initial_dir.iterdir():
            # Check if the filename matches the pattern
            if pattern.match(filename.name):
                self.file_paths.append(initial_dir.joinpath(filename))

        if len(self.file_paths) == 0:
            initial_dir = self.data_dir.joinpath("preview")
            pattern = re.compile(r"preview.png$")
            for filename in initial_dir.iterdir():
                # Check if the filename matches the pattern
                if pattern.match(filename.name):
                    self.file_paths.append(initial_dir.joinpath(filename))
        if len(self.file_paths) > 0:
            self.file_paths_img = [path.stem for path in self.file_paths]
            self.overlay_curves.config(state=tk.NORMAL)
            self.meta_data.config(state=tk.NORMAL)
            if self.selected_mode.get() == "Binary" or self.selected_mode.get() == "Ternary":
                self.assign_phases_left.config(state=tk.NORMAL)
                self.assign_phases_right.config(state=tk.NORMAL)
                self.revert_view.config(state=tk.NORMAL)
            elif self.selected_mode.get() == "Line":
                self.assign_curves_left.config(state=tk.NORMAL)
                self.assign_curves_right.config(state=tk.NORMAL)
                self.revert_view.config(state=tk.NORMAL)

            # Show the selected file names and show images
            self.display_strings(self.file_paths_img)
            self.overlay_curves_fun()

        # update the curves selector variable accordingly
        self.update_available_curves()

    def overlay_curves_fun(
        self,
    ):  # function to overlay all selected or some of the selected curves
        # Get the value from the entry field
        Entry_str = self.overlay_curves_entry.get()
        # Store paths of files to combine
        to_combine = []
        if Entry_str == "all":
            to_combine = self.file_paths
        else:
            Entry_list = [x for x in Entry_str.split(",")]
            for idx, paths in enumerate(self.file_paths_img):
                if any(x in paths for x in Entry_list):
                    to_combine.append(self.file_paths[idx])

        # Save the list of paths for passing to method
        self.selected_curves = to_combine

        # Load the first image to determine its dimensions
        # Load the image
        input_image = Image.open(to_combine[0]).convert("L")

        # Save the width and height
        input_height = input_image.height
        input_width = input_image.width

        # Create an output image of equal size
        self.overlayed_curves_image = Image.new("L", (input_width, input_height), color="white")
        pixels_output = self.overlayed_curves_image.load()

        for file_name in to_combine:
            # Open each image
            input_image = Image.open(file_name).convert("L")
            pixels_input = input_image.load()

            # Iterate through each pixel
            for x in range(input_width):
                for y in range(input_height):
                    # If the pixel is black, set the equivalent pixel in the output image to black
                    if pixels_input[x, y] == (0):
                        pixels_output[x, y] = 0

        # Display the output image
        self.display_output(self.overlayed_curves_image)
        self.update_overlay_areas_label()

        # Enable edit buttons
        self.draw_on_overlay.config(state=tk.NORMAL)
        self.fill_small_areas.config(state=tk.NORMAL)
        self.thin_lines.config(state=tk.NORMAL)
        if self.selected_mode.get() == "Binary" or self.selected_mode.get() == "Ternary":
            self.assign_phases_left.config(state=tk.NORMAL)
            self.assign_phases_right.config(state=tk.NORMAL)
            self.revert_view.config(state=tk.NORMAL)
        elif self.selected_mode.get() == "Line":
            self.assign_curves_left.config(state=tk.NORMAL)
            self.assign_curves_right.config(state=tk.NORMAL)
            self.revert_view.config(state=tk.NORMAL)

    def draw_on_overlay_fun(self):
        output_path = self.data_dir.joinpath("curves", "overlayed_curves.png")
        opt_args={
            "input": output_path,
            "output": output_path,
            "origin": "data_extractor"}
        self.overlayed_curves_image.save(output_path)
        self.draw_on_image = output_path

        self.controller.show_page("PaintApp",opt_args)

    def close_function_draw(self):
        output_path = self.data_dir.joinpath("curves", "overlayed_curves.png")

        self.overlayed_curves_image = Image.open(output_path).convert("L")
        self.display_output(self.overlayed_curves_image)
        self.update_overlay_areas_label()

    def fill_small_areas_fun(self):
        # Label the overlayed curves to identify all white areas
        labeled_array, num_labels = label(self.overlayed_curves_image)

        # Determine the size (no of Pixels) for each area
        area_counts = np.bincount(labeled_array.ravel())

        # Determine the size of the images
        (cols, rows) = labeled_array.shape
        img_size = cols * rows

        # Create a new array to store the filled image
        filled_array = labeled_array

        # Get the value from the entry field
        Entry_float = float(self.area_cutoff_entry.get())

        # Check each area size
        no_filled = 0
        for idx, area_count in enumerate(area_counts):
            if area_count < Entry_float / 100 * img_size:
                no_filled += 1
                # Fill that area
                filled_array = self.fill_area(labeled_array, filled_array, idx)

                # Convert the array to a black/white image
                self.overlayed_curves_image = Image.fromarray((filled_array * 255).astype("uint8"), mode="L")

                # Update the image
                self.display_output(self.overlayed_curves_image)
                self.update_overlay_areas_label()

    def thin_lines_fun(self):
        binary_image_array = np.asarray(self.overlayed_curves_image)
        binary_array = (binary_image_array > 0).astype(np.uint8)
        self.overlayed_curves_image = self.thinning_fun(binary_array)
        # Update the image
        self.display_output(self.overlayed_curves_image)
        self.update_overlay_areas_label()

    #########################################################
    ##DEFINE ALL OTHER FUNCTIONS HERE
    #########################################################
    def add_meta_area_data(self):
        def create_area_dict(area):
            area_dict = {}
            for line in area[1:]:
                parts = line.strip().split()
                if len(parts) == 2:
                    key = int(parts[0].split("_")[1])  # Get the number after "Area_"
                    value = parts[1]
                    area_dict[key] = value
            return area_dict

        def extract_axis_labels(input_string):
            # Split the multiline string into individual lines
            lines = input_string.splitlines()

            # Define the keys
            keys = ["A", "B", "C", "X_axis", "Y_axis", "Z_axis"]

            # Create the dictionary with each key having the value "not_given"
            dictionary = {key: "not_given" for key in keys}

            # Initialize headers and header_idx
            headers = ""
            header_idx = -1

            # Iterate through each line in the lines list
            for idx, line in enumerate(lines):
                # Check if the line starts with "X Axis:", "Y Axis:", or "Z Axis:"
                if line.startswith("#X Axis:"):
                    if "->" in line:
                        value = line.split("->")[1].strip()
                        dictionary["A"] = f"X_{value}"
                        dictionary["X_axis"] = f"X_{value}"
                    else:
                        value = line.split(":")[1].strip()
                        dictionary["X_axis"] = value
                        dictionary["A"] = value
                elif line.startswith("#Y Axis:"):
                    if "->" in line:
                        value = line.split("->")[1].strip()
                        dictionary["B"] = f"Y_{value}"
                        dictionary["Y_axis"] = f"Y_{value}"
                    else:
                        value = line.split(":")[1].strip()
                        dictionary["Y_axis"] = value
                        dictionary["B"] = value
                elif line.startswith("#Z Axis:"):
                    if "->" in line:
                        value = line.split("->")[1].strip()
                        dictionary["C"] = f"Z_{value}"
                        dictionary["Z_axis"] = f"Z_{value}"
                    else:
                        value = line.split(":")[1].strip()
                        dictionary["Z_axis"] = value
                        dictionary["C"] = value
                elif line.startswith("Name") or line.startswith("surfactant"):
                    headers = line
                    header_idx = idx

            # Make new headers line by replacing keys with their corresponding values
            for key, value in dictionary.items():
                if value != "not_given":
                    headers = headers.replace(f" {key} ", f" {value} ")

            # Replace the line at the specified index with the new headers
            if 0 <= header_idx < len(lines):
                lines[header_idx] = headers
            else:
                pprint(f"{WARN_COLOR}Index {header_idx} is out of bounds for the given multiline{RESET}")

            # Join the lines back into a single string
            updated_string = "\n".join(lines)
            return updated_string

        def txt_to_json(string):
            def add_to_json_list(json, key, add):
                if key in json.keys():
                    json[key].append(add)
                else:
                    json[key]=[add]
                return json
            json_entry = {}
            header_line = False
            f = string.split("\n")
            json_entry["other_data"] = []
            for line in f:
                line = line.strip()
                if line.startswith("#"):
                    if "SMILES" in line:
                        json_entry = add_to_json_list(json_entry,
                                                      "SMILES",
                                                      [item.strip() for item in line.split(":")[-2:]]
                                                      )
                    elif "Reference or Source" in line:
                        json_entry["Source"] = line.split(":")[-1].strip()
                    elif "File Name" in line:
                        json_entry["Name"] = line.split(":")[-1].strip()
                    elif "Solvent" in line:
                        json_entry["Solvent"] = line.split(":")[-1].strip()
                    elif "Purity" in line:
                        json_entry["Purity"] = line.split(":")[-1].strip()
                    elif "Method" in line:
                        json_entry["Method"] = line.split(":")[-1].strip()
                    elif "Origin" in line:
                        json_entry["Origin"] = line.split(":")[-1].strip()
                    elif "Comments" in line:
                        json_entry["Comments"] = line.split(":")[-1].strip()
                    else:
                        json_entry["other_data"].append(line.split("#")[-1].strip())

                elif not header_line:
                    header_line = True
                    headers = line.split()[1:]
                    json_entry["headers"] = [item.strip() for item in headers]
                elif header_line and len(line.split()) > 0:
                    if "Data" not in json_entry.keys():
                        json_entry["Data"] = {}
                        n = len(line.split())
                    for column in range(1, n):
                        if headers[column - 1] in json_entry["Data"].keys():
                            try:
                                json_entry["Data"][headers[column - 1]].append(float(line.split()[column]))
                            except Exception:
                                json_entry["Data"][headers[column - 1]].append(line.split()[column])
                        else:
                            json_entry["Data"][headers[column - 1]] = []
                            try:
                                json_entry["Data"][headers[column - 1]].append(float(line.split()[column]))
                            except Exception:
                                json_entry["Data"][headers[column - 1]].append(line.split()[column])
                else:
                    continue
            #for key in json_entry["Data"].keys():
             #   data_list = json_entry["Data"][key]
              #  json_entry["Data"][key] = str(data_list)
            return json_entry

        meta_path = self.data_dir.joinpath("preview", "meta_data.txt")
        area_path = self.data_dir.joinpath("preview", "area_data.txt")
        output_path = self.data_dir.joinpath("output", f"{self.output_name}.txt")

        # read in data
        try:
            with open(str(output_path)) as file:
                output = file.read()
        except FileNotFoundError:
            pprint(f"{WARN_COLOR}Error:{RESET} No output found, did you select the right script and parameters?")
            return
        except Exception as e:
            pprint(f"{WARN_COLOR}An unexpected error occurred:{RESET} {VAR_COLOR}{e}{RESET}")
            return

        # read in meta data
        try:
            with open(meta_path) as file:
                meta = file.read()
            # check if the meta data file is for the same file as the output file
            if self.output_name in meta:
                output = self.combine_strings(meta, output)
        except FileNotFoundError:
            pprint(f"{WARN_COLOR}Error:{RESET} No Meta Data file found, did you define one?")
        except Exception as e:
            pprint(f"{WARN_COLOR}An unexpected error occurred:{RESET} {VAR_COLOR}{e}{RESET}")

        # TODO: The conditional below this checking is area_dict is a dict throws an
        #  Unbounded access error - refactor in the future
        area_dict = None
        # assign areas to output
        try:
            with open(area_path) as file:
                area = file.readlines()
            if self.output_name in area[0]:
                area_dict = create_area_dict(area)
        except FileNotFoundError:
            area_dict = None
            pprint(f"{WARN_COLOR}Error:{RESET} No Area Data file found")
        except Exception as e:
            area_dict = None
            pprint(f"{WARN_COLOR}An unexpected error occurred:{RESET} {VAR_COLOR}{e}{RESET}")

        if isinstance(area_dict, dict):
            if self.selected_mode.get() == "Binary":
                # Replace the areas with the dictionary if they have been specified
                for key in area_dict.keys():
                    value = " " + area_dict[key] + " "
                    key = f" area_{key} "
                    if value.strip() != "not_given":
                        output = output.replace(key, value)
            if self.selected_mode.get() == "Ternary":
                # Replace the areas with the dictionary if they have been specified
                for key in area_dict.keys():
                    value = " " + area_dict[key] + " "
                    key -= 1
                    if key > 0:
                        key = f" area_{key} "
                        if value.strip() != "not_given":
                            output = output.replace(key, value)

        # Update the headers line
        output = extract_axis_labels(output)

        # Save the new file
        output_path.unlink()
        with open(output_path, "w") as file:
            file.write(output)
        pprint(f"{MSG_COLOR}Updated output with any meta data which was specified.{RESET}")
        try:
            output = txt_to_json(output)
            output_path = Path(str(output_path).replace(".txt", ".json"))
            with open(output_path, "w") as json_file:
                json.dump(output, json_file, indent=4)
        except Exception as e2:
            pprint(f"{WARN_COLOR}Exception:{RESET} {VAR_COLOR}{e2}{RESET}")

    def add_meta_line_data(self):
        def create_curve_dict(area):
            area_dict = {}
            for line in area[1:]:
                parts = line.strip().split()
                if len(parts) == 2:
                    key = int(parts[0].split("_")[1])  # Get the number after "Curve_"
                    value = parts[1].strip()
                    area_dict[key] = value
            return area_dict

        files = [f"partial_curve_data_{self.output_name}.txt", f"full_curve_data_{self.output_name}.txt"]
        for file in files:
            meta_path = self.data_dir.joinpath("preview", "meta_data.txt")
            curve_path = self.data_dir.joinpath("preview", "curve_data.txt")
            output_path = self.data_dir.joinpath("output", file)

            # read in data
            try:
                with open(output_path) as file:
                    output = file.read()
            except FileNotFoundError:
                pprint(f"{WARN_COLOR}Error:{RESET} No output found, did you select the right script and parameters?")
                return
            except Exception as e2:
                pprint(f"{WARN_COLOR}An unexpected error occurred:{RESET} {VAR_COLOR}{e2}{RESET}")
                return

            # read in meta data
            try:
                with open(meta_path) as file:
                    meta = file.read()
                # check if the meta data file is for the same file as the output file
                if self.output_name in meta:
                    output = self.combine_strings(meta, output)
            except FileNotFoundError:
                pprint(f"{WARN_COLOR}Error:{RESET} No Meta Data file found, did you define one?")
            except Exception as e2:
                pprint(f"{WARN_COLOR}An unexpected error occurred:{RESET} {VAR_COLOR}{e2}{RESET}")

            # assign areas to output
            try:
                with open(curve_path) as file:
                    curves = file.readlines()
                if self.output_name in curves[0]:
                    curve_dict = create_curve_dict(curves)
            except FileNotFoundError:
                curve_dict = None
                pprint(f"{WARN_COLOR}Error:{RESET} No Area Data file found")
            except Exception as e2:
                curve_dict = None
                pprint(f"{WARN_COLOR}An unexpected error occurred:{RESET} {VAR_COLOR}{e2}{RESET}")

            if isinstance(curve_dict, dict):
                for key in curve_dict.keys():
                    value = curve_dict[key]
                    key = f"#curve_{key}.png"
                    if value.strip() != "not_given":
                        value = key + f" : {value}"
                        output = output.replace(key, value)

            # save the text file
            pprint(f"{MSG_COLOR}Output path is:{RESET} {VAR_COLOR}{output_path}{RESET}")
            with open(output_path, "w") as file:
                file.write(output)
            pprint(f"{MSG_COLOR}Updated output with any meta data which was specified.{RESET}")

    def combine_strings(self, string1, string2):
        # Split each string into lines
        lines1 = string1.splitlines()
        lines2 = string2.splitlines()

        # Remove empty lines from both lists
        non_empty_lines1 = [line for line in lines1 if line.strip()]
        non_empty_lines2 = [line for line in lines2 if line.strip()]

        # Combine the non-empty lines
        combined_lines = non_empty_lines1 + non_empty_lines2

        # Join the combined lines into a single string with newline characters
        combined_string = "\n".join(combined_lines)

        return combined_string

    def save_area_dictionary(self):
        file_path = self.data_dir.joinpath("preview", "area_data.txt")

        # Check if the file exists
        if file_path.exists():
            # If it exists, remove the file
            file_path.unlink()
            pprint(f"{MSG_COLOR}Deleted existing file:{RESET} {FILE_COLOR}{file_path}{RESET}")

        # Convert dictionary to a string with each pair on a new line
        result_string = f"Areas for file: {self.output_name}\n"
        result_string += "\n".join(f"area_{key} {value}" for key, value in self.area_dictionary.items())
        # Write the content to the file
        with open(file_path, "w") as file:
            file.write(result_string)
        pprint(
            f"{MSG_COLOR}Saved Dictionary:\n{VAR_COLOR}{result_string}{RESET}\n"
            f"{MSG_COLOR}To file:{RESET} {FILE_COLOR}{file_path}{RESET}"
        )

    def save_curve_dictionary(self):
        file_path = self.data_dir.joinpath("preview", "curve_data.txt")
        # Check if the file exists
        if file_path.exists():
            # If it exists, remove the file
            file_path.unlink()
            pprint(f"{MSG_COLOR}Deleted existing file:{RESET} {FILE_COLOR}{file_path}{RESET}")

        # Convert dictionary to a string with each pair on a new line
        result_string = f"Curves for file: {self.output_name}\n"
        result_string += "\n".join(f"Curve_{key} {value}" for key, value in self.curve_dictionary.items())
        # Write the content to the file
        with open(file_path, "w") as file:
            file.write(result_string)
        pprint(
            f"{MSG_COLOR}Saved Dictionary:\n{VAR_COLOR}{result_string}{RESET}\n"
            f"{MSG_COLOR}To file:{RESET} {FILE_COLOR}{file_path}{RESET}"
        )

    def save_area_label(self):
        string = self.assign_phases_entry.get()
        if len(string.strip()) == 0:
            string = "not_given"
        self.area_dictionary[self.current_area] = string

    def save_curve_label(self):
        string = self.assign_curve_entry.get()
        if len(string.strip()) == 0:
            string = "not_given"
        self.curve_dictionary[self.current_curve] = string

    def display_and_assign(self):
        # Check if the current phase is already assigned and then fill in the field as needed
        value_for_key = self.area_dictionary[self.current_area]
        # Retrieve any assigned value
        if value_for_key == "not_given":
            self.assign_phases_entry.delete(0, tk.END)
        else:
            self.assign_phases_entry.delete(0, tk.END)
            self.assign_phases_entry.insert(0, value_for_key)  # Set new content
        # Update label of current phase
        self.current_area_label.config(text=f"Current Area is: {self.current_area}")

        # Call function to show the current phase
        self.display_phase(self.overlayed_curves_image, self.current_area)

    def display_and_assign_curve(self):
        # Check if the current curve is already assigned and then fill in the field as needed
        value_for_key = self.curve_dictionary[self.current_curve]
        # Retrieve any assigned value
        if value_for_key == "not_given":
            self.assign_curve_entry.delete(0, tk.END)
        else:
            self.assign_curve_entry.delete(0, tk.END)
            self.assign_curve_entry.insert(0, value_for_key)  # Set new content

        # Update label of current phase
        self.current_curve_label.config(text=f"Current Curve is: {self.current_curve}")

        # Display the current curve
        self.display_curve(self.current_curve)

    def display_curve(self, curve):
        # Get the dimensions
        path_to_curve = self.data_dir.joinpath("curves", f"curve_{curve}.png")

        image = Image.open(path_to_curve).convert("L")

        original_width, original_height = image.size
        # Calculate the aspect ratio of the original image
        aspect_ratio = original_width / original_height

        # Calculate the new width and height based on the aspect ratio and the maximum dimensions
        new_width = min(original_width, int(self.controller.width / 2))
        new_height = min(original_height, int(self.controller.height / 2))
        if aspect_ratio > 1:  # Landscape orientation
            new_height = int(new_width / aspect_ratio)
        else:  # Portrait orientation
            new_width = int(new_height * aspect_ratio)

        # Resize the image while preserving its aspect ratio
        resized_image = image.resize((new_width, new_height), Image.LANCZOS)

        # Clear current output
        if hasattr(self, "output_image_label"):
            self.output_image_label.destroy()

        # Show the new image
        tk_image = ImageTk.PhotoImage(resized_image)
        self.output_image_label = ttk.Label(self.out_img_frame, image=tk_image)
        self.output_image_label.image = tk_image  # Keep a reference to prevent garbage collection
        self.output_image_label.pack()

    def display_phase(self, image, area):
        # Function to display area in image

        # Get the dimensions
        original_width, original_height = image.size

        binary_array = np.array(image)

        # Binarize the image: white pixels (255) become 1, black pixels (0) remain 0
        binary_array_bin = np.where(binary_array > 128, 1, 0)

        # Label the connected white areas
        labeled_array, num_labels = label(binary_array_bin)

        # Map area code to a shade of green
        colored_image = np.ones((*labeled_array.shape, 3), dtype=np.uint8) * 255

        # Create a mask of the relevant area
        mask = labeled_array == area
        mask2 = labeled_array == 0
        colored_image[mask] = [0, 255, 0]
        colored_image[mask2] = [0, 0, 0]

        # Convert the NumPy array to a PIL image
        pil_colored_image = Image.fromarray(colored_image)

        # Calculate the aspect ratio of the original image
        aspect_ratio = original_width / original_height

        # Calculate the new width and height based on the aspect ratio and the maximum dimensions
        new_width = min(original_width, int(self.controller.width / 2))
        new_height = min(original_height, int(self.controller.height / 2))
        if aspect_ratio > 1:  # Landscape orientation
            new_height = int(new_width / aspect_ratio)
        else:  # Portrait orientation
            new_width = int(new_height * aspect_ratio)

        # Resize the image while preserving its aspect ratio
        resized_image = pil_colored_image.resize((new_width, new_height), Image.LANCZOS)

        # Clear current output
        if hasattr(self, "output_image_label"):
            self.output_image_label.destroy()

        # Show the new image
        tk_image = ImageTk.PhotoImage(resized_image)
        self.output_image_label = ttk.Label(self.out_img_frame, image=tk_image)
        self.output_image_label.image = tk_image  # Keep a reference to prevent garbage collection
        self.output_image_label.pack()

    def bary_to_cart(self, A, B, C, alpha, beta, gamma):
        col = alpha * A[0] + beta * B[0] + gamma * C[0]
        row = alpha * A[1] + beta * B[1] + gamma * C[1]
        return (int(col), int(row))

    # Add this at the beginning of your mode_change_function
    def mode_change_function(self, *args):
        # Clear any previously created mode-specific widgets
        self._clear_mode_specific_widgets()

        if self.selected_mode.get() == "Binary" or self.selected_mode.get() == "Ternary":
            if self.overlayed_curves_image is not None:
                success = self.display_output(self.overlayed_curves_image)
                if not success:
                    pprint(f"{WARN_COLOR}Error:{RESET} Could not change mode, function display failed.")
                    return

            # Create a container frame for the area assignment controls
            self.assign_phase_frame = ttk.Frame(self.control_frame)

            # Create the label outside of the frame
            self.assign_phases_label = ttk.Label(self.control_frame, text="Area Assignment", padding=(10, 10))

            # Create navigation controls in the frame with minimal padding
            self.assign_phases_left = ttk.Button(
                self.assign_phase_frame,
                text="<",
                command=self.assign_phases_left_fun,
                state=tk.DISABLED,
                padding=(5, 5),  # Reduced padding
            )
            self.assign_phases_entry = ttk.Entry(
                self.assign_phase_frame,
                width=10,  # Slightly smaller width
            )
            self.assign_phases_right = ttk.Button(
                self.assign_phase_frame,
                text=">",
                command=self.assign_phases_right_fun,
                state=tk.DISABLED,
                padding=(5, 5),  # Reduced padding
            )

            self.current_area = 1
            self.current_area_label = ttk.Label(
                self.control_frame,
                text=f"Current Area is: {self.current_area}",
                padding=(10, 5),  # Reduced vertical padding
            )

            self.revert_view = ttk.Button(
                self.control_frame,
                text="Revert View",
                command=self.revert_view_fun,
                state=tk.DISABLED,
                padding=(10, 5),  # Reduced padding
            )

            # Layout the controls
            row_start = 20

            # Place the label and frame side by side
            self.assign_phases_label.grid(row=row_start, column=0, padx=5, pady=5, sticky="w")
            self.assign_phase_frame.grid(row=row_start, column=1, columnspan=2, padx=0, pady=5, sticky="w")

            # Inside the frame, place the controls in a single row with minimal spacing
            self.assign_phases_left.grid(row=0, column=0, padx=(0, 2), pady=0)
            self.assign_phases_entry.grid(row=0, column=1, padx=2, pady=0)
            self.assign_phases_right.grid(row=0, column=2, padx=(2, 0), pady=0)

            # Place the current area label and revert button in the next row
            self.current_area_label.grid(row=row_start + 1, column=0, columnspan=2, padx=5, pady=5, sticky="w")
            self.revert_view.grid(row=row_start + 1, column=2, padx=5, pady=5, sticky="e")

            # Save references to widgets for cleanup - include the frame
            self.mode_specific_widgets = [
                self.assign_phases_label,
                self.assign_phase_frame,
                self.assign_phases_left,
                self.assign_phases_entry,
                self.assign_phases_right,
                self.current_area_label,
                self.revert_view,
            ]

        elif self.selected_mode.get() == "Line":
            # Create a container frame for curve assignment controls
            self.assign_curve_frame = ttk.Frame(self.control_frame)

            # Create the label outside of the frame
            self.assign_curve_label = ttk.Label(self.control_frame, text="Curve Assignment", padding=(10, 10))

            # Create navigation controls in the frame with minimal padding
            self.assign_curves_left = ttk.Button(
                self.assign_curve_frame,
                text="<",
                command=self.assign_curve_left_fun,
                state=tk.DISABLED,
                padding=(5, 5),  # Reduced padding
            )
            self.assign_curve_entry = ttk.Entry(
                self.assign_curve_frame,
                width=10,  # Slightly smaller width
            )
            self.assign_curves_right = ttk.Button(
                self.assign_curve_frame,
                text=">",
                command=self.assign_curve_right_fun,
                state=tk.DISABLED,
                padding=(5, 5),  # Reduced padding
            )

            self.current_curve = 1
            self.current_curve_label = ttk.Label(
                self.control_frame,
                text=f"Current Curve is: {self.current_curve}",
                padding=(10, 5),  # Reduced vertical padding
            )

            self.revert_view = ttk.Button(
                self.control_frame,
                text="Revert View",
                command=self.revert_view_fun,
                state=tk.DISABLED,
                padding=(10, 5),  # Reduced padding
            )

            # Layout the controls
            row_start = 20

            # Place the label and frame side by side
            self.assign_curve_label.grid(row=row_start, column=0, padx=5, pady=5, sticky="w")
            self.assign_curve_frame.grid(row=row_start, column=1, columnspan=2, padx=0, pady=5, sticky="w")

            # Inside the frame, place the controls in a single row with minimal spacing
            self.assign_curves_left.grid(row=0, column=0, padx=(0, 2), pady=0)
            self.assign_curve_entry.grid(row=0, column=1, padx=2, pady=0)
            self.assign_curves_right.grid(row=0, column=2, padx=(2, 0), pady=0)

            # Place the current curve label and revert button in the next row
            self.current_curve_label.grid(row=row_start + 1, column=0, columnspan=2, padx=5, pady=5, sticky="w")
            self.revert_view.grid(row=row_start + 1, column=2, padx=5, pady=5, sticky="e")

            # Save references to widgets for cleanup - include the frame
            self.mode_specific_widgets = [
                self.assign_curve_label,
                self.assign_curve_frame,
                self.assign_curves_left,
                self.assign_curve_entry,
                self.assign_curves_right,
                self.current_curve_label,
                self.revert_view,
            ]

        # enable buttons if files are already selected
        if len(self.file_paths) > 0:
            if self.selected_mode.get() != "Line":
                self.assign_phases_left.config(state=tk.NORMAL)
                self.assign_phases_right.config(state=tk.NORMAL)
            else:
                self.assign_curves_left.config(state=tk.NORMAL)
                self.assign_curves_right.config(state=tk.NORMAL)
            self.revert_view.config(state=tk.NORMAL)

    def _clear_mode_specific_widgets(self):
        for widget in getattr(self, "mode_specific_widgets", []):
            if widget:
                widget.destroy()
        self.mode_specific_widgets = []
        self.revert_view = None
        self.assign_phases_left = None
        self.assign_phases_right = None
        self.assign_curves_left = None
        self.assign_curves_right = None

    def display_strings(self, strings):
        # Concatenate all strings with newlines
        text_content = "\n".join(strings)
        # Add a summary line
        text_content += f"\n\nThere are {len(strings)} curves selected."

        # Calculate the number of lines and characters in the text content
        num_lines = len(text_content.split("\n"))
        max_line_length = max(len(line) for line in text_content.split("\n"))

        # Calculate the width and height of the Text widget based on the content
        width = max_line_length + 2  # Add a small buffer
        height = num_lines

        if hasattr(self, "output_text") and self.output_text.winfo_exists():
            # If the Tkinter window already exists, clear the existing text
            self.output_text.delete("1.0", tk.END)

        # Create a Text widget and add the concatenated string
        self.output_text = tk.Text(self.out_txt_frame, width=width, height=height)
        self.output_text.insert(tk.END, text_content)
        self.output_text.grid(row=0, column=0, padx=1, pady=1)

    def thinning_fun(self, inp_arr):
        def neighbours(img, x, y):
            # Returns the 8 neighbor values at position [x, y] for an image as well as the value at [x,y]
            neighbors = []
            for i in range(x - 1, x + 2):
                for j in range(y - 1, y + 2):
                    # Check if indices are within bounds
                    if 0 <= i < img.shape[0] and 0 <= j < img.shape[1]:
                        neighbors.append(img[i][j])
                    else:
                        # Indices are out of bounds, set neighbor value to 0
                        neighbors.append(0)
            return neighbors

        # Function which will thin all black features to a minimum while ensuring the area count remains constant
        # Label the overlayed curves to identify all white areas
        labeled_array, num_labels = label(self.overlayed_curves_image)

        # Flag to determine if the thinning process is done
        finish_flag = False

        # Create a new array to store the thinned image
        out_arr = inp_arr

        while not finish_flag:
            changes = 0
            for i in range(inp_arr.shape[0]):
                for j in range(inp_arr.shape[1]):  # For each pixel
                    if inp_arr[i, j] == 0:  # If the pixel is black
                        nbrs = neighbours(labeled_array, i, j)  # Fetch neighbours of the i, j pixel
                        # If a pixel is sourrounded by exactly 2 areas, it can be removed
                        if len(set(nbrs)) == 2:
                            out_arr[i, j] = 1  # Set the pixel to be white
                            changes += 1
                            # Update the input
                            inp_arr = out_arr
                            labeled_array[i, j] = max(
                                set(nbrs)
                            )  # Sets the adjacency matrix of the removed pixel to be that of the adjacent area

            if changes == 0:
                finish_flag = True

        # Convert the array to a black/white image
        binary_image = Image.fromarray((inp_arr * 255).astype("uint8"), mode="L")

        return binary_image

    def fill_area(self, array_in, array_out, idx):
        # Iterate through the rows and columns of labeled_array
        for i in range(array_in.shape[0]):
            for j in range(array_in.shape[1]):
                # Check if the label of the current pixel is area index
                if array_in[i, j] == idx:
                    # Set the corresponding pixel in the cleaned array to be black
                    array_out[i, j] = 0
        return array_out

    def display_output(self, image):
        if self.selected_mode.get() != "Line":
            # Get the dimensions
            original_width, original_height = image.size

            binary_array = np.array(image)

            # Binarize the image: white pixels (255) become 1, black pixels (0) remain 0
            binary_array_bin = np.where(binary_array > 128, 1, 0)

            # Label the connected white areas
            labeled_array, num_labels = label(binary_array_bin)

            # Create a colormap with num_labels+1 colors
            colormap = plt.cm.get_cmap("Greens", num_labels + 1)

            # Map each label to a shade of green
            colored_image = np.zeros((*labeled_array.shape, 3), dtype=np.uint8)
            for label_idx in range(1, num_labels + 1):
                mask = labeled_array == label_idx
                # Convert colormap value to RGB values scaled to 0-255
                rgb_color = np.array(colormap(label_idx)[:3]) * 255
                colored_image[mask] = rgb_color

            # Convert the NumPy array to a PIL image
            pil_colored_image = Image.fromarray(colored_image)

            # Calculate the aspect ratio of the original image
            aspect_ratio = original_width / original_height

            # Calculate the new width and height based on the aspect ratio and the maximum dimensions
            new_width = min(original_width, int(self.controller.width / 2))
            new_height = min(original_height, int(self.controller.height / 2))
            if aspect_ratio > 1:  # Landscape orientation
                new_height = int(new_width / aspect_ratio)
            else:  # Portrait orientation
                new_width = int(new_height * aspect_ratio)

            if self.selected_mode.get() == "Ternary":
                # Invert the image if the triangle is black on a white background
                inverted_image = cv2.bitwise_not(binary_array)

                # Ensure the image is binary (black and white)
                _, binary_image = cv2.threshold(inverted_image, 127, 255, cv2.THRESH_BINARY)

                # Find contours of shapes in the binary image
                contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                # Filter out the largest triangle based on its shape
                largest_triangle = None
                largest_area = 0
                for contour in contours:
                    perimeter = cv2.arcLength(contour, True)
                    approx = cv2.approxPolyDP(contour, 0.04 * perimeter, True)  # Approximate the polygon

                    if len(approx) == 3:  # Check if the contour is a triangle
                        area = cv2.contourArea(contour)
                        if area > largest_area:  # Find the largest triangle by area
                            largest_triangle = approx
                            largest_area = area

                # Check if a triangle was found
                if largest_triangle is not None:
                    labels = ["X", "Y", "Z"]
                    line_labels = [["0.7 X", "0.7 Z", "0.7 Y"],["0.3 X", "0.3 Z", "0.3 Y"]]
                    bary = [[(0.7, 0.3, 0), (0.3, 0, 0.7), (0, 0.7, 0.3)],
                            [(0.3, 0.7, 0), (0.7, 0, 0.3), (0, 0.3, 0.7)]]
                    pprint(f"""
                        {MSG_COLOR}Debugging Coordinates:{RESET}
                        {VAR_COLOR}{largest_triangle[0][0]}, {largest_triangle[1][0]}, {largest_triangle[2][0]},
                        {labels[0]}, {labels[1]}, {labels[2]}{RESET}
                        """)
                    # Create a copy of the original image to overlay the points
                    image_with_points = colored_image

                    # Save the vertices of the triangles
                    for idx, vertex in enumerate(largest_triangle):
                        x, y = vertex[0]
                        cv2.circle(image_with_points, (x, y), 5, (255, 0, 0), -1)  # Draw a green circle
                        cv2.putText(
                            image_with_points,
                            labels[idx],
                            (x, y - 10),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            1,
                            (255, 0, 0),
                            2,
                        )
                        # Add labels to define the axis

                        for i in [0,1]:
                            cv2.circle(
                                image_with_points,
                                self.bary_to_cart(
                                    largest_triangle[0][0],
                                    largest_triangle[1][0],
                                    largest_triangle[2][0],
                                    bary[i][idx][0],
                                    bary[i][idx][1],
                                    bary[i][idx][2],
                                ),
                                3,
                                (255, 0, 0),
                                -1,
                            )
                            cv2.putText(
                                image_with_points,
                                line_labels[i][idx],
                                self.bary_to_cart(
                                    largest_triangle[0][0],
                                    largest_triangle[1][0],
                                    largest_triangle[2][0],
                                    bary[i][idx][0],
                                    bary[i][idx][1],
                                    bary[i][idx][2],
                                ),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                0.5,
                                (255, 0, 0),
                                2,
                            )

                        corner_labeled_image = Image.fromarray(image_with_points)
                else:
                    pprint(f"{WARN_COLOR}Error:{RESET} Attempted to pick Ternary with no triangle present")
                    self.selected_mode.set("Select an Option")
                    return False

            else:
                corner_labeled_image = pil_colored_image

            # Resize the image while preserving its aspect ratio
            resized_image = corner_labeled_image.resize((new_width, new_height), Image.LANCZOS)

            # Clear current output
            if hasattr(self, "output_image_label"):
                self.output_image_label.destroy()

            # Show the new image
            tk_image = ImageTk.PhotoImage(resized_image)
            self.output_image_label = tk.Label(self.out_img_frame, image=tk_image)
            self.output_image_label.image = tk_image  # Keep a reference to prevent garbage collection
            self.output_image_label.pack()

            # Save the image
            output_image_name = f"{self.output_name}_out.png"
            output_image_path = self.data_dir.joinpath("output", output_image_name)

            output_array = np.array(image.convert("L"))  # Convert to grayscale
            cv2.imwrite(output_image_path, output_array)

            return True
        else:
            # Get the dimensions
            original_width, original_height = image.size
            # Calculate the aspect ratio of the original image
            aspect_ratio = original_width / original_height

            # Calculate the new width and height based on the aspect ratio and the maximum dimensions
            new_width = min(original_width, int(self.controller.width / 2))
            new_height = min(original_height, int(self.controller.height / 2))
            if aspect_ratio > 1:  # Landscape orientation
                new_height = int(new_width / aspect_ratio)
            else:  # Portrait orientation
                new_width = int(new_height * aspect_ratio)

            # Resize the image while preserving its aspect ratio
            resized_image = image.resize((new_width, new_height), Image.LANCZOS)

            # Clear current output
            if hasattr(self, "output_image_label"):
                self.output_image_label.destroy()

            # Show the new image
            tk_image = ImageTk.PhotoImage(resized_image)
            self.output_image_label = ttk.Label(self.out_img_frame, image=tk_image)
            self.output_image_label.image = tk_image  # Keep a reference to prevent garbage collection
            self.output_image_label.pack()

            # Save the image
            output_image_name = f"{self.output_name}_out.png"
            output_image_path = self.data_dir.joinpath("output", output_image_name)

            output_array = np.array(image.convert("L"))  # Convert to grayscale
            cv2.imwrite(output_image_path, output_array)

            return True

    def update_overlay_areas_label(self):
        # Determine the number of areas
        labeled_array, num_labels = label(self.overlayed_curves_image)

        # Update the label text with the new value
        self.area_count_lbl.config(text=f"Current area count is: {num_labels}")
        self.num_areas = num_labels
        self.area_dictionary = {i: "not_given" for i in range(1, num_labels + 1)}
