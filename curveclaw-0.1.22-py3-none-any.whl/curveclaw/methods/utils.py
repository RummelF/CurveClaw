import random

import numpy as np
from PIL import Image, ImageDraw
from rich import print as pprint

from curveclaw.settings import FILE_COLOR, MSG_COLOR, RESET

# COMMON FUNCTIONS


def interpret_string(s):
    true_values = {"true", "yes", "y", "1"}
    false_values = {"false", "no", "n", "0"}

    s_lower = s.strip().lower()

    if s_lower in true_values:
        return True
    elif s_lower in false_values:
        return False
    else:
        return None


# BINARY FUNCTIONS


def create_binary_image_from_array(array, output_filename):
    # Normalize the array values to the range [0, 255] for green scale image
    normalized_array = (255 * (array - np.min(array)) / np.ptp(array)).astype(np.uint8)

    # Create a new image with RGB mode
    height, width = array.shape
    image = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(image)

    # Apply the green scale and set 0 values to black
    for y in range(height):
        for x in range(width):
            value = normalized_array[y, x]
            if array[y, x] == 0:
                image.putpixel((x, y), (0, 0, 0))  # Black for 0 values
            else:
                image.putpixel((x, y), (255, 255, 255))

    # Get the unique values in the array (excluding 0)
    unique_values = np.unique(array)
    unique_values = unique_values[unique_values != 0]

    # Label the middle of each group
    for value in unique_values:
        # Get the coordinates of all pixels with the current value
        coords = np.argwhere(array == value)

        # Calculate the middle coordinate
        if coords.size > 0:
            y = 0
            x = 0
            for coord in coords:
                y += coord[0]
                x += coord[1]
            y = int(y / len(coords))
            x = int(x / len(coords))

        # Ensure the middle falls into the correct area
        if array[y, x] != value:
            y = coords[random.randint(0, len(coords) - 1)][0]
            x = coords[random.randint(0, len(coords) - 1)][1]

        # Draw the label in red
        text = str(value)
        draw.text((x, y), text, fill="red")

    # Save the image as a PNG file
    image.save(output_filename, "PNG")

    pprint(f"{MSG_COLOR}Image saved as {FILE_COLOR}{output_filename}{RESET}")


# TERNARY FUNCTIONS


def bary_to_cart(A, B, C, alpha, beta, gamma):
    col = alpha * A[0] + beta * B[0] + gamma * C[0]
    row = alpha * A[1] + beta * B[1] + gamma * C[1]
    return (int(col), int(row))


def bary_to_real(coord, axis_lengths, axis_log):
    # convert a barycentric coordinate in a triangle to the value this
    # corresponds to given the length of the sides and the presence of log scales
    alpha = coord[0]
    beta = coord[1]
    gamma = coord[2]
    min_x, max_x = axis_lengths[0]
    min_y, max_y = axis_lengths[1]
    min_z, max_z = axis_lengths[2]

    if axis_log[0] is False:
        X = alpha * (max_x - min_x) + min_x
    else:
        if min_x == 0:
            min_x = 0.001
        X = alpha * (np.log10(max_x) - np.log10(min_x)) + np.log10(min_x)
        X = 10**X
    if axis_log[1] is False:
        Y = beta * (max_y - min_y) + min_y
    else:
        if max_y == 0:
            max_y = 0.001
        Y = beta * (np.log10(max_y) - np.log10(min_y)) + np.log10(min_y)
        Y = 10**Y
    if axis_log[2] is False:
        Z = gamma * (max_z - min_z) + min_z
    else:
        if min_z == 0:
            min_z = 0.001
        Z = gamma * (np.log10(max_z) - np.log10(min_z)) + np.log10(min_z)
        Z = 10**Z
    return [X, Y, Z]


def find_closest_nonzero_pixel(array, start_row, start_col):
    # Iterate through the image array to find the closest black pixel
    min_distance = float("inf")
    closest_pixel = None
    for i in range(array.shape[0]):
        for j in range(array.shape[1]):
            if array[i, j] > 1:  # Black pixel and outside triangle is ignored
                distance = np.sqrt((i - start_row) ** 2 + (j - start_col) ** 2)
                if distance < min_distance:
                    min_distance = distance
                    closest_pixel = (i, j)
    return closest_pixel


def create_ternary_image_from_array(array, output_filename, A, B, C):
    corners = [A, B, C]
    # Normalize the array values to the range [0, 255] for green scale image
    normalized_array = (255 * (array - np.min(array)) / np.ptp(array)).astype(np.uint8)

    # Create a new image with RGB mode
    height, width = array.shape
    image = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(image)

    # Apply the green scale and set 0 values to black
    for y in range(height):
        for x in range(width):
            value = normalized_array[y, x]
            if array[y, x] == 0:
                image.putpixel((x, y), (0, 0, 0))  # Black for 0 values
            else:
                image.putpixel((x, y), (255, 255, 255))

    # Get the unique values in the array (excluding 0)
    unique_values = np.unique(array)
    unique_values = unique_values[unique_values != 0]

    # Label the middle of each group
    for value in unique_values:
        if value > 1:
            # Get the coordinates of all pixels with the current value
            coords = np.argwhere(array == value)

            # Calculate the middle coordinate
            if coords.size > 0:
                y = 0
                x = 0
                for coord in coords:
                    y += coord[0]
                    x += coord[1]
                y = int(y / len(coords))
                x = int(x / len(coords))

            # Ensure the middle falls into the correct area
            if array[y, x] != value:
                y = coords[random.randint(0, len(coords) - 1)][0]
                x = coords[random.randint(0, len(coords) - 1)][1]

            # Draw the label in red
            text = str(value - 1)
            draw.text((x, y), text, fill="red")

    text_labels = ["X", "Y", "Z"]
    for idx, text_label in enumerate(text_labels):
        y = corners[idx][1]
        x = corners[idx][0]
        draw.text((x, y), text_label, fill="red")

    # Save the image as a PNG file
    image.save(output_filename, "PNG")

    pprint(f"{MSG_COLOR}Image saved as {FILE_COLOR}{output_filename}{RESET}")


# PROBABILITY FUNCTIONS


def dist_to_prob_fun(distance):
    # input is a distance output is the probability
    a = 2  # defining constant in function
    p = 1  # defining power in function
    prob = np.exp((-(distance**p)) / a)
    return prob


def prob_to_dist_fun(prob):
    # input is a probability, returns the equivalent distance
    a = 2
    p = 1
    d = (-a * np.log(prob)) ** (1 / p)
    return d
